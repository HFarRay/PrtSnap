#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
source "$ROOT/toolchain-env.sh"
WORK="$(cd "$ROOT/../../work" && pwd)"
mkdir -p "$WORK/PrtSnap-build"
"$SWIFTC" -parse-as-library -swift-version 6 -O -sdk "$MACOS_SDKROOT" \
  -target arm64-apple-macosx14.0 -module-cache-path "$WORK/PrtSnap-build/module-cache-v2" \
  "$ROOT/Sources/PrtSnap/Shortcut.swift" "$ROOT/Sources/PrtSnap/HotkeyEventMatcher.swift" \
  "$ROOT/Tests/HotkeyEventMatcherProbe.swift" -o "$WORK/PrtSnap-build/HotkeyEventMatcherProbe"
"$WORK/PrtSnap-build/HotkeyEventMatcherProbe"
