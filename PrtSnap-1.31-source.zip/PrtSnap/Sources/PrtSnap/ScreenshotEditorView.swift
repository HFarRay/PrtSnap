import AppKit
import CoreImage
import SwiftUI
import UniformTypeIdentifiers

private enum EditorTool: String, CaseIterable, Identifiable {
    case select = "选择"
    case brush = "画笔"
    case mosaic = "马赛克"
    case rectangle = "方框"
    case ellipse = "圆形"
    case arrow = "箭头"
    case emoji = "贴纸"
    case text = "文字"

    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .select: "cursorarrow"
        case .brush: "pencil.tip"
        case .mosaic: "square.grid.3x3"
        case .rectangle: "rectangle"
        case .ellipse: "circle"
        case .arrow: "arrow.up.right"
        case .emoji: "face.smiling"
        case .text: "textformat"
        }
    }
}

private struct EditorMark: Identifiable, Equatable {
    let id: UUID
    var tool: EditorTool
    var points: [CGPoint] = []
    var value: String = ""
    var color: Color = .red
    var lineWidth: CGFloat = 5
    var fontSize: CGFloat = 24
    var bold = false
    var italic = false
    var underline = false
    var strikethrough = false
    var letterSpacing: CGFloat = 0
    var lineSpacing: CGFloat = 0
    var fontFamily = "System"
    var rotation: Angle = .zero
    var scale: CGSize = CGSize(width: 1, height: 1)
    var imageData: Data?

    init(id: UUID = UUID(), tool: EditorTool, points: [CGPoint] = [], value: String = "") {
        self.id = id
        self.tool = tool
        self.points = points
        self.value = value
    }
}

struct ScreenshotEditorView: View {
    let item: HistoryItem

    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var prefs = Preferences.shared
    @State private var tool: EditorTool = .brush
    @State private var marks: [EditorMark] = []
    @State private var draft: EditorMark?
    @State private var selectedID: UUID?
    @State private var history = EditorUndoHistory<[EditorMark]>(limit: 100)
    @State private var selectedColor = Color.red
    @State private var lineWidth: CGFloat = 5
    @State private var selectedEmoji = "✨"
    @State private var emojiQuery = ""
    @State private var textValue = ""
    @State private var fontSize: CGFloat = 24
    @State private var bold = false
    @State private var italic = false
    @State private var underline = false
    @State private var strikethrough = false
    @State private var letterSpacing: CGFloat = 0
    @State private var lineSpacing: CGFloat = 0
    @State private var fontFamily = "System"
    @State private var message: String?
    @State private var stickerData: [Data] = []
    @State private var selectedStickerData: Data?
    @State private var pixelatedImage: NSImage?
    @State private var editingText = false
    @FocusState private var textEditorFocused: Bool
    @State private var transformOriginal: [EditorMark]?

    private let emojiChoices = ["😀", "😃", "😂", "🥹", "😍", "🤔", "😎", "😭", "😡", "👍", "👎", "👏", "🙏", "❤️", "💔", "⭐️", "✨", "🎉", "🔥", "📌", "✅", "❌", "💡", "🚀"]
    private var filteredEmoji: [String] {
        let query = emojiQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        return query.isEmpty ? emojiChoices : emojiChoices.filter { emojiName[$0, default: ""].localizedCaseInsensitiveContains(query) }
    }
    private let emojiName: [String: String] = ["😀": "笑脸 happy", "😃": "开心 smile", "😂": "大笑 laugh", "🥹": "感动", "😍": "喜欢 love", "🤔": "思考", "😎": "酷 cool", "😭": "哭 cry", "😡": "生气 angry", "👍": "赞 like", "👎": "踩 dislike", "👏": "鼓掌", "🙏": "感谢", "❤️": "爱 heart", "💔": "心碎", "⭐️": "星星 star", "✨": "闪耀 sparkle", "🎉": "庆祝", "🔥": "火 fire", "📌": "图钉", "✅": "完成", "❌": "错误", "💡": "想法", "🚀": "火箭"]

    private var baseImage: NSImage? { item.image }

    var body: some View {
        VStack(spacing: 0) {
            toolbar
            if let message {
                Text(message).font(.caption).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 14).padding(.bottom, 6)
            }
            HStack(spacing: 0) {
                if tool == .emoji { emojiPanel }
                if tool == .text { textPanel }
                canvas
            }
        }
        .background(.regularMaterial)
        .onAppear {
            if let first = emojiChoices.first { selectedEmoji = first }
            refreshPixelatedImage()
        }
        .onDisappear { draft = nil }
        .onChange(of: prefs.mosaicStrength) { _, _ in refreshPixelatedImage() }
        .onChange(of: fontSize) { _, _ in syncDraftStyle() }
        .onChange(of: selectedColor) { _, _ in syncDraftStyle() }
        .onChange(of: bold) { _, _ in syncDraftStyle() }
        .onChange(of: italic) { _, _ in syncDraftStyle() }
        .onChange(of: underline) { _, _ in syncDraftStyle() }
        .onChange(of: strikethrough) { _, _ in syncDraftStyle() }
        .onChange(of: letterSpacing) { _, _ in syncDraftStyle() }
        .onChange(of: lineSpacing) { _, _ in syncDraftStyle() }
        .onChange(of: fontFamily) { _, _ in syncDraftStyle() }
    }

    private var toolbar: some View {
        HStack(spacing: 6) {
            ForEach(EditorTool.allCases) { option in
                Button { tool = option } label: {
                    Image(systemName: option.symbol).frame(width: 31, height: 30)
                }
                .buttonStyle(.borderless)
                .background(tool == option ? Color.accentColor.opacity(0.18) : .clear, in: RoundedRectangle(cornerRadius: 6))
                .help(option.rawValue)
            }
            Divider().frame(height: 22)
            ColorPicker("", selection: $selectedColor, supportsOpacity: true).labelsHidden().help("颜色")
            Slider(value: $lineWidth, in: 1...40, step: 1).frame(width: 90).help("线宽")
            Text("\(Int(lineWidth))").font(.caption.monospacedDigit()).frame(width: 22)
            if tool == .mosaic { Slider(value: $prefs.mosaicStrength, in: 6...48, step: 2).frame(width: 90).help("马赛克颗粒") }
            Spacer(minLength: 4)
            Button { undo() } label: { Image(systemName: "arrow.uturn.backward").frame(width: 30, height: 30) }.buttonStyle(.borderless).disabled(history.undoStack.isEmpty).keyboardShortcut("z", modifiers: [.command]).help("撤销 (⌘Z)")
            Button { redo() } label: { Image(systemName: "arrow.uturn.forward").frame(width: 30, height: 30) }.buttonStyle(.borderless).disabled(history.redoStack.isEmpty).keyboardShortcut("z", modifiers: [.command, .shift]).help("重做 (⌘⇧Z)")
            Divider().frame(height: 22)
            Button { dismiss() } label: { Image(systemName: "xmark").frame(width: 30, height: 30) }.buttonStyle(.borderless).help("取消")
            Button { saveEditedImage() } label: { Image(systemName: "checkmark").frame(width: 30, height: 30) }.buttonStyle(.borderedProminent).help("保存")
        }
        .padding(.horizontal, 10).padding(.vertical, 8)
        .background(.thinMaterial)
    }

    private var emojiPanel: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("贴纸").font(.headline)
            TextField("搜索 Emoji", text: $emojiQuery).textFieldStyle(.roundedBorder)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 34), spacing: 5)], spacing: 5) {
                ForEach(filteredEmoji, id: \.self) { emoji in
                    Button { selectedEmoji = emoji; selectedStickerData = nil } label: { Text(emoji).font(.system(size: 25)).frame(width: 34, height: 34) }.buttonStyle(.borderless)
                }
            }
            Button { importSticker() } label: { Label("导入图片贴纸", systemImage: "plus.square.on.square") }.buttonStyle(.bordered)
            Button { importWeChatStickers() } label: { Label("扫描微信表情文件夹", systemImage: "face.smiling.inverse") }.buttonStyle(.bordered)
            if !stickerData.isEmpty {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 34), spacing: 5)], spacing: 5) {
                    ForEach(Array(stickerData.enumerated()), id: \.offset) { _, data in
                        if let image = NSImage(data: data) {
                            Button { selectedStickerData = data; selectedEmoji = "🖼️" } label: {
                                Image(nsImage: image).resizable().scaledToFit().frame(width: 32, height: 32)
                            }.buttonStyle(.borderless).help("选用导入的贴纸")
                        }
                    }
                }
            }
            Text("选择贴纸后在图片上拖动定位，可在选择工具中移动、缩放、旋转。") .font(.caption).foregroundStyle(.secondary)
            Spacer()
        }
        .padding(12).frame(width: 190).background(.thinMaterial)
    }

    private var textPanel: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("文字").font(.headline)
            TextEditor(text: $textValue).frame(height: 75).overlay(RoundedRectangle(cornerRadius: 6).stroke(.quaternary))
            HStack { Text("大小").font(.caption); Slider(value: $fontSize, in: 8...120, step: 1); Text("\(Int(fontSize))").font(.caption.monospacedDigit()) }
            HStack(spacing: 5) {
                Toggle("B", isOn: $bold).toggleStyle(.button).help("加粗")
                Toggle("I", isOn: $italic).toggleStyle(.button).help("斜体")
                Toggle("U", isOn: $underline).toggleStyle(.button).help("下划线")
                Toggle("S", isOn: $strikethrough).toggleStyle(.button).help("删除线")
            }
            Picker("字体", selection: $fontFamily) {
                Text("系统").tag("System")
                Text("衬线").tag("Serif")
                Text("圆体").tag("Rounded")
                Text("等宽").tag("Monospaced")
            }
            .labelsHidden()
            HStack { Text("字距").font(.caption); Slider(value: $letterSpacing, in: -5...20, step: 1) }
            HStack { Text("行距").font(.caption); Slider(value: $lineSpacing, in: 0...30, step: 1) }
            Text("在画布中拖动出文本框，松开后即可继续编辑。") .font(.caption).foregroundStyle(.secondary)
            Spacer()
        }
        .padding(12).frame(width: 230).background(.thinMaterial)
    }

    private var canvas: some View {
        Group {
            if let baseImage {
                GeometryReader { proxy in
                    let rect = fittedRect(imageSize: baseImage.size, in: proxy.size)
                    ZStack {
                        Color(nsColor: .windowBackgroundColor)
                        Image(nsImage: baseImage).resizable().frame(width: rect.width, height: rect.height).position(x: rect.midX, y: rect.midY)
                        if let pixelatedImage {
                            Image(nsImage: pixelatedImage).resizable().frame(width: rect.width, height: rect.height).position(x: rect.midX, y: rect.midY)
                                .mask {
                                    Canvas { context, _ in
                                        for mark in marks + (draft.map { [$0] } ?? []) where mark.tool == .mosaic {
                                            context.fill(mosaicPath(mark, imageRect: rect), with: .color(.white))
                                        }
                                    }
                                }
                        }
                        Canvas { context, _ in
                            for mark in marks + (draft.map { [$0] } ?? []) { draw(mark, in: &context, imageRect: rect) }
                        }
                        .contentShape(Rectangle())
                        .gesture(drawingGesture(imageRect: rect))
                        if let draft, editingText {
                            textInputOverlay(mark: draft, imageRect: rect)
                        }
                        if tool == .select, let selectedID, let mark = marks.first(where: { $0.id == selectedID }), isTransformable(mark) {
                            selectionOverlay(mark, imageRect: rect)
                        }
                    }
                }
                .padding(12)
            } else { ContentUnavailableView("无法读取截图", systemImage: "photo") }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func textInputOverlay(mark: EditorMark, imageRect: CGRect) -> some View {
        let rect = textBounds(mark, imageRect: imageRect)
        return VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 3) {
                ColorPicker("", selection: $selectedColor, supportsOpacity: true).labelsHidden()
                Stepper("字号 \(Int(fontSize))", value: $fontSize, in: 8...120).labelsHidden().frame(width: 90)
                Toggle("B", isOn: $bold).toggleStyle(.button)
                Toggle("I", isOn: $italic).toggleStyle(.button)
                Toggle("U", isOn: $underline).toggleStyle(.button)
                Toggle("S", isOn: $strikethrough).toggleStyle(.button)
                Menu {
                    Picker("字体", selection: $fontFamily) {
                        Text("系统").tag("System")
                        Text("衬线").tag("Serif")
                        Text("圆体").tag("Rounded")
                        Text("等宽").tag("Monospaced")
                    }
                    Divider()
                    Slider(value: $letterSpacing, in: -5...20, step: 1) { Text("字间距") }
                    Slider(value: $lineSpacing, in: 0...30, step: 1) { Text("行间距") }
                } label: { Image(systemName: "textformat.size").frame(width: 25, height: 25) }
                .menuStyle(.borderlessButton)
                .help("字体与间距")
                Button { commitText() } label: { Image(systemName: "checkmark.circle.fill") }.buttonStyle(.plain).help("完成输入")
            }
            .padding(4)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 6))
            TextEditor(text: $textValue)
                .font(.system(size: fontSize, weight: bold ? .bold : .regular))
                .focused($textEditorFocused)
                .frame(minWidth: 110, idealWidth: rect.width, maxWidth: 400, minHeight: 46, idealHeight: rect.height, maxHeight: 240)
                .scrollContentBackground(.hidden)
                .padding(4)
                .background(.white.opacity(0.85), in: RoundedRectangle(cornerRadius: 5))
                .overlay(RoundedRectangle(cornerRadius: 5).stroke(Color.accentColor, lineWidth: 1))
                .onChange(of: textValue) { _, value in
                    guard var current = draft else { return }
                    current.value = value
                    current.color = selectedColor
                    current.fontSize = fontSize
                    current.bold = bold
                    current.italic = italic
                    current.underline = underline
                    current.strikethrough = strikethrough
                    current.letterSpacing = letterSpacing
                    current.lineSpacing = lineSpacing
                    current.fontFamily = fontFamily
                    draft = current
                }
        }
        .fixedSize()
        .position(x: rect.minX + rect.width / 2, y: rect.minY + rect.height / 2)
        .onAppear { textEditorFocused = true }
    }

    private func selectionOverlay(_ mark: EditorMark, imageRect: CGRect) -> some View {
        let bounds = objectBounds(mark, imageRect: imageRect)
        return ZStack {
            RoundedRectangle(cornerRadius: 3).stroke(Color.accentColor, style: StrokeStyle(lineWidth: 1, dash: [5]))
                .frame(width: bounds.width, height: bounds.height)
                .contentShape(Rectangle())
                .gesture(DragGesture().onChanged { value in moveObject(mark, translation: value.translation, imageRect: imageRect) }.onEnded { _ in finishTransform() })
            Circle().fill(Color.white).overlay(Circle().stroke(Color.accentColor, lineWidth: 1.5)).frame(width: 11, height: 11)
                .position(x: bounds.width, y: bounds.height)
                .gesture(DragGesture().onChanged { value in resizeObject(mark, translation: value.translation, imageRect: imageRect) }.onEnded { _ in finishTransform() })
            Circle().fill(Color.accentColor).frame(width: 11, height: 11)
                .position(x: bounds.width / 2, y: -13)
                .gesture(DragGesture().onChanged { value in rotateObject(mark, translation: value.translation) }.onEnded { _ in finishTransform() })
        }
        .frame(width: bounds.width, height: bounds.height)
        .position(x: bounds.midX, y: bounds.midY)
        .rotationEffect(mark.rotation)
        .scaleEffect(mark.scale)
    }

    private func drawingGesture(imageRect: CGRect) -> some Gesture {
        DragGesture(minimumDistance: tool == .select ? 4 : 0, coordinateSpace: .local)
            .onChanged { value in
                guard let point = normalized(value.location, in: imageRect) else { return }
                if tool == .select { return }
                if draft == nil { draft = newMark(at: point) }
                updateDraft(at: point, start: value.startLocation, imageRect: imageRect)
            }
            .onEnded { value in
                guard let point = normalized(value.location, in: imageRect) else { draft = nil; return }
                if tool == .select {
                    selectedID = nearestMark(to: point)
                } else {
                    finishMark(at: point, start: value.startLocation, imageRect: imageRect)
                }
            }
    }

    private func newMark(at point: CGPoint) -> EditorMark {
        switch tool {
        case .emoji: var mark = EditorMark(tool: .emoji, points: [point], value: selectedEmoji); mark.imageData = selectedStickerData; return mark
        case .text: return EditorMark(tool: .text, points: [point, point], value: textValue)
        default: return EditorMark(tool: tool, points: [point])
        }
    }

    private func updateDraft(at point: CGPoint, start: CGPoint, imageRect: CGRect) {
        guard var current = draft else { return }
        switch tool {
        case .brush, .mosaic: current.points.append(point)
        case .rectangle, .ellipse, .arrow: current.points = [normalized(start, in: imageRect) ?? point, point]
        case .emoji: current.points = [point]
        case .text: current.points = [normalized(start, in: imageRect) ?? point, point]
        case .select: break
        }
        draft = current
    }

    private func finishMark(at point: CGPoint, start: CGPoint, imageRect: CGRect) {
        guard var mark = draft else { return }
        mark.color = selectedColor; mark.lineWidth = lineWidth; mark.fontSize = fontSize; mark.bold = bold; mark.italic = italic; mark.underline = underline; mark.strikethrough = strikethrough; mark.letterSpacing = letterSpacing; mark.lineSpacing = lineSpacing; mark.fontFamily = fontFamily
        if (tool == .brush || tool == .mosaic) && mark.points.count < 2 { draft = nil; return }
        if tool == .text {
            if mark.points.count > 1 {
                let first = mark.points[0], last = mark.points[1]
                mark.points = [CGPoint(x: min(first.x, last.x), y: min(first.y, last.y)), CGPoint(x: max(first.x, last.x), y: max(first.y, last.y))]
            }
            textValue = ""
            draft = mark
            editingText = true
        } else {
            pushUndo(); marks.append(mark); selectedID = mark.id; draft = nil
        }
    }

    private func nearestMark(to point: CGPoint) -> UUID? { marks.reversed().first { mark in guard let first = mark.points.first else { return false }; return hypot(first.x - point.x, first.y - point.y) < 0.12 }?.id }

    private func commitText() {
        guard var mark = draft else { return }
        mark.value = textValue; mark.color = selectedColor; mark.fontSize = fontSize; mark.bold = bold; mark.italic = italic; mark.underline = underline; mark.strikethrough = strikethrough; mark.letterSpacing = letterSpacing; mark.lineSpacing = lineSpacing; mark.fontFamily = fontFamily
        if !mark.value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { pushUndo(); marks.append(mark); selectedID = mark.id }
        draft = nil; editingText = false; textEditorFocused = false; tool = .select
    }

    private func syncDraftStyle() {
        guard var mark = draft, tool == .text else { return }
        mark.color = selectedColor; mark.fontSize = fontSize; mark.bold = bold; mark.italic = italic; mark.underline = underline; mark.strikethrough = strikethrough; mark.letterSpacing = letterSpacing; mark.lineSpacing = lineSpacing; mark.fontFamily = fontFamily
        draft = mark
    }

    private func isTransformable(_ mark: EditorMark) -> Bool { mark.tool == .text || mark.tool == .emoji }

    private func textBounds(_ mark: EditorMark, imageRect: CGRect) -> CGRect {
        let start = mark.points.first.map { canvasPoint($0, in: imageRect) } ?? .zero
        if mark.points.count > 1 {
            let end = canvasPoint(mark.points[1], in: imageRect)
            return CGRect(x: min(start.x, end.x), y: min(start.y, end.y), width: max(120, abs(end.x - start.x)), height: max(54, abs(end.y - start.y)))
        }
        return CGRect(x: start.x, y: start.y, width: 180, height: 65)
    }

    private func objectBounds(_ mark: EditorMark, imageRect: CGRect) -> CGRect {
        if mark.tool == .text { return textBounds(mark, imageRect: imageRect) }
        guard let point = mark.points.first.map({ canvasPoint($0, in: imageRect) }) else { return .zero }
        return CGRect(x: point.x - 28, y: point.y - 28, width: 56, height: 56)
    }

    private func moveObject(_ mark: EditorMark, translation: CGSize, imageRect: CGRect) {
        guard let index = marks.firstIndex(where: { $0.id == mark.id }) else { return }
        if transformOriginal == nil { transformOriginal = marks }
        let delta = CGSize(width: translation.width / imageRect.width, height: translation.height / imageRect.height)
        let base = transformOriginal?[index] ?? mark
        marks[index].points = base.points.map { CGPoint(x: min(1, max(0, $0.x + delta.width)), y: min(1, max(0, $0.y + delta.height))) }
    }

    private func resizeObject(_ mark: EditorMark, translation: CGSize, imageRect: CGRect) {
        guard let index = marks.firstIndex(where: { $0.id == mark.id }) else { return }
        if transformOriginal == nil { transformOriginal = marks }
        let base = transformOriginal?[index] ?? mark
        let dx = max(0.15, base.scale.width + translation.width / 120)
        let dy = max(0.15, base.scale.height + translation.height / 120)
        if NSEvent.modifierFlags.contains(.shift) { marks[index].scale = CGSize(width: dx, height: dy) }
        else { let uniform = max(0.15, (dx + dy) / 2); marks[index].scale = CGSize(width: uniform, height: uniform) }
        _ = imageRect
    }

    private func rotateObject(_ mark: EditorMark, translation: CGSize) {
        guard let index = marks.firstIndex(where: { $0.id == mark.id }) else { return }
        if transformOriginal == nil { transformOriginal = marks }
        let base = transformOriginal?[index] ?? mark
        marks[index].rotation = base.rotation + .degrees(Double(translation.width))
    }

    private func finishTransform() {
        guard let transformOriginal, transformOriginal != marks else { self.transformOriginal = nil; return }
        history.record(before: transformOriginal); self.transformOriginal = nil
    }

    private func mosaicPath(_ mark: EditorMark, imageRect: CGRect) -> Path {
        var path = Path()
        let radius = max(4, mark.lineWidth * 1.5)
        for point in mark.points {
            let center = canvasPoint(point, in: imageRect)
            path.addEllipse(in: CGRect(x: center.x - radius, y: center.y - radius, width: radius * 2, height: radius * 2))
        }
        return path
    }

    private func refreshPixelatedImage() {
        guard let source = baseImage, var proposed = Optional(CGRect(origin: .zero, size: source.size)), let cgImage = source.cgImage(forProposedRect: &proposed, context: nil, hints: nil) else { pixelatedImage = nil; return }
        let ci = CIImage(cgImage: cgImage); let filter = CIFilter(name: "CIPixellate"); filter?.setValue(ci, forKey: kCIInputImageKey); filter?.setValue(prefs.mosaicStrength, forKey: kCIInputScaleKey)
        if let output = filter?.outputImage, let result = CIContext().createCGImage(output.cropped(to: ci.extent), from: ci.extent) { pixelatedImage = NSImage(cgImage: result, size: source.size) }
    }

    private func swiftUIFont(_ mark: EditorMark) -> Font {
        let design: Font.Design
        switch mark.fontFamily {
        case "Serif": design = .serif
        case "Rounded": design = .rounded
        case "Monospaced": design = .monospaced
        default: design = .default
        }
        return .system(size: mark.fontSize, weight: mark.bold ? .bold : .regular, design: design)
    }

    private func saveTextAttributes(_ mark: EditorMark, color: NSColor) -> [NSAttributedString.Key: Any] {
        let name: String
        switch mark.fontFamily {
        case "Serif": name = "Georgia"
        case "Rounded": name = "SFProRounded-Regular"
        case "Monospaced": name = "Menlo"
        default: name = NSFont.systemFont(ofSize: mark.fontSize).fontName
        }
        var traits: NSFontDescriptor.SymbolicTraits = []
        if mark.bold { traits.insert(.bold) }
        if mark.italic { traits.insert(.italic) }
        let descriptor = NSFontDescriptor(name: name, size: mark.fontSize).withSymbolicTraits(traits)
        let font = NSFont(descriptor: descriptor, size: mark.fontSize) ?? NSFont.systemFont(ofSize: mark.fontSize, weight: mark.bold ? .bold : .regular)
        let paragraph = NSMutableParagraphStyle()
        paragraph.lineSpacing = mark.lineSpacing
        var attributes: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: color, .kern: mark.letterSpacing, .paragraphStyle: paragraph]
        if mark.underline { attributes[.underlineStyle] = NSUnderlineStyle.single.rawValue }
        if mark.strikethrough { attributes[.strikethroughStyle] = NSUnderlineStyle.single.rawValue }
        return attributes
    }

    private func importSticker() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.image]
        panel.allowsMultipleSelection = false
        panel.begin { response in
            guard response == .OK, let url = panel.url, let data = try? Data(contentsOf: url) else { return }
            selectedEmoji = "🖼️"
            selectedStickerData = data
            stickerData.append(data)
        }
    }

    private func importWeChatStickers() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        panel.message = "选择微信表情包文件夹"
        panel.begin { response in
            guard response == .OK, let root = panel.url,
                  let enumerator = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.fileSizeKey, .isRegularFileKey], options: [.skipsHiddenFiles]) else { return }
            let extensions: Set<String> = ["png", "jpg", "jpeg", "gif", "webp", "bmp"]
            var imported: [Data] = []
            for case let url as URL in enumerator {
                guard extensions.contains(url.pathExtension.lowercased()),
                      let values = try? url.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey]), values.isRegularFile == true,
                      (values.fileSize ?? 0) <= 8_000_000,
                      let data = try? Data(contentsOf: url), NSImage(data: data) != nil else { continue }
                imported.append(data)
                if imported.count == 200 { break }
            }
            stickerData.append(contentsOf: imported)
            message = imported.isEmpty ? "所选文件夹中未找到可用图片表情。" : "已导入 \(imported.count) 张图片表情。"
        }
    }

    private func drawMosaic(_ mark: EditorMark, width: Int, height: Int, scale: CGFloat, canvas: NSRect, graphics: NSGraphicsContext) {
        guard let pixelatedImage else { return }
        let path = NSBezierPath()
        let radius = max(4, mark.lineWidth * 1.5 * scale)
        for item in mark.points {
            let center = imagePoint(item, width: width, height: height)
            path.appendOval(in: NSRect(x: center.x - radius, y: center.y - radius, width: radius * 2, height: radius * 2))
        }
        NSGraphicsContext.saveGraphicsState()
        path.addClip()
        pixelatedImage.draw(in: canvas, from: NSRect(origin: .zero, size: pixelatedImage.size), operation: .sourceOver, fraction: 1)
        graphics.flushGraphics()
        NSGraphicsContext.restoreGraphicsState()
    }

    private func pushUndo() { history.record(before: marks) }
    private func undo() { guard let previous = history.undo(current: marks) else { return }; marks = previous; selectedID = nil }
    private func redo() { guard let next = history.redo(current: marks) else { return }; marks = next; selectedID = nil }

    private func fittedRect(imageSize: CGSize, in container: CGSize) -> CGRect { let scale = min(container.width / max(imageSize.width, 1), container.height / max(imageSize.height, 1)); let size = CGSize(width: imageSize.width * scale, height: imageSize.height * scale); return CGRect(x: (container.width - size.width) / 2, y: (container.height - size.height) / 2, width: size.width, height: size.height) }
    private func normalized(_ point: CGPoint, in rect: CGRect) -> CGPoint? { guard rect.width > 0, rect.height > 0, rect.contains(point) else { return nil }; return CGPoint(x: (point.x - rect.minX) / rect.width, y: (point.y - rect.minY) / rect.height) }
    private func canvasPoint(_ point: CGPoint, in rect: CGRect) -> CGPoint { CGPoint(x: rect.minX + point.x * rect.width, y: rect.minY + point.y * rect.height) }

    private func draw(_ mark: EditorMark, in context: inout GraphicsContext, imageRect: CGRect) {
        func p(_ point: CGPoint) -> CGPoint { canvasPoint(point, in: imageRect) }
        let color = mark.color
        switch mark.tool {
        case .brush, .mosaic:
            guard let first = mark.points.first else { return }
            if mark.tool == .brush {
                var path = Path(); path.move(to: p(first)); for point in mark.points.dropFirst() { path.addLine(to: p(point)) }; context.stroke(path, with: .color(color), style: StrokeStyle(lineWidth: mark.lineWidth, lineCap: .round, lineJoin: .round))
            }
        case .rectangle, .ellipse, .arrow:
            guard mark.points.count >= 2 else { return }; let a = p(mark.points[0]); let b = p(mark.points[1]); let rect = CGRect(x: min(a.x, b.x), y: min(a.y, b.y), width: abs(a.x - b.x), height: abs(a.y - b.y)); var path = Path()
            if mark.tool == .rectangle { path.addRect(rect) } else if mark.tool == .ellipse { path.addEllipse(in: rect) } else { path.move(to: a); path.addLine(to: b); let angle = atan2(b.y - a.y, b.x - a.x); let length: CGFloat = 12 + mark.lineWidth; for sign: CGFloat in [-1, 1] { let theta = angle + CGFloat.pi + sign * CGFloat.pi / 6; path.move(to: b); path.addLine(to: CGPoint(x: b.x + cos(theta) * length, y: b.y + sin(theta) * length)) } }; context.stroke(path, with: .color(color), style: StrokeStyle(lineWidth: mark.lineWidth, lineCap: .round, lineJoin: .round))
        case .emoji:
            if let data = mark.imageData, let nsImage = NSImage(data: data) { let center = p(mark.points[0]); let side = 48 * mark.scale.width; context.draw(Image(nsImage: nsImage).resizable(), in: CGRect(x: center.x - side / 2, y: center.y - side / 2, width: side, height: side)) } else if let point = mark.points.first { context.draw(Text(mark.value).font(.system(size: 42 * mark.scale.width)), at: p(point)) }
        case .text:
            guard !mark.points.isEmpty else { return }
            let anchor = p(mark.points[0])
            var label = Text(mark.value).font(swiftUIFont(mark)).foregroundColor(mark.color).tracking(mark.letterSpacing)
            if mark.italic { label = label.italic() }
            if mark.underline { label = label.underline() }
            if mark.strikethrough { label = label.strikethrough() }
            var transformed = context
            transformed.translateBy(x: anchor.x, y: anchor.y)
            transformed.rotate(by: mark.rotation)
            transformed.scaleBy(x: mark.scale.width, y: mark.scale.height)
            transformed.draw(label, at: .zero, anchor: .topLeading)
        case .select: break
        }
    }

    private func saveEditedImage() {
        guard let source = baseImage, var proposed = Optional(CGRect(origin: .zero, size: source.size)), let sourceCGImage = source.cgImage(forProposedRect: &proposed, context: nil, hints: nil), let rendered = render(source: source, sourceCGImage: sourceCGImage) else { message = "编辑结果生成失败。"; return }
        do {
            let targetSpace = OutputColorSpace(rawValue: prefs.colorSpace) ?? .sRGB
            let mapping = GamutMappingMode(rawValue: prefs.gamutMappingMode) ?? .clip
            let converted = try ImagePipeline.convert(rendered, scale: 1, colorSpace: targetSpace, gamutMapping: mapping)
            let data = try ImagePipeline.encode(converted, format: prefs.format, quality: prefs.quality)
            HistoryManager.shared.saveEdited(data, format: prefs.format)
            dismiss()
        } catch { message = "保存失败：\(error.localizedDescription)" }
    }

    private func render(source: NSImage, sourceCGImage: CGImage) -> CGImage? {
        let width = sourceCGImage.width, height = sourceCGImage.height
        let outputScale = CGFloat(width) / max(source.size.width, 1)
        guard let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: width, pixelsHigh: height, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0), let graphics = NSGraphicsContext(bitmapImageRep: bitmap) else { return nil }
        NSGraphicsContext.saveGraphicsState(); NSGraphicsContext.current = graphics; let canvas = NSRect(x: 0, y: 0, width: width, height: height); source.draw(in: canvas, from: .zero, operation: .copy, fraction: 1)
        for mark in marks {
            guard let first = mark.points.first else { continue }; let point = imagePoint(first, width: width, height: height); let nsColor = NSColor(mark.color)
            switch mark.tool {
            case .brush:
                let path = NSBezierPath(); path.lineWidth = mark.lineWidth * outputScale; path.lineCapStyle = .round; path.move(to: point); for item in mark.points.dropFirst() { path.line(to: imagePoint(item, width: width, height: height)) }; nsColor.setStroke(); path.stroke()
            case .mosaic:
                drawMosaic(mark, width: width, height: height, scale: outputScale, canvas: canvas, graphics: graphics)
            case .rectangle, .ellipse, .arrow:
                guard mark.points.count >= 2 else { continue }; let a = imagePoint(mark.points[0], width: width, height: height), b = imagePoint(mark.points[1], width: width, height: height); let rect = NSRect(x: min(a.x, b.x), y: min(a.y, b.y), width: abs(a.x - b.x), height: abs(a.y - b.y)); let path = NSBezierPath(); if mark.tool == .rectangle { path.appendRect(rect) } else if mark.tool == .ellipse { path.appendOval(in: rect) } else { path.move(to: a); path.line(to: b); let angle = atan2(b.y - a.y, b.x - a.x); let length: CGFloat = (12 + mark.lineWidth) * outputScale; for sign: CGFloat in [-1, 1] { let theta = angle + CGFloat.pi + sign * .pi / 6; path.move(to: b); path.line(to: CGPoint(x: b.x + cos(theta) * length, y: b.y + sin(theta) * length)) } }; path.lineWidth = mark.lineWidth * outputScale; nsColor.setStroke(); path.stroke()
            case .emoji:
                let side = 48 * outputScale * mark.scale.width
                if let data = mark.imageData, let image = NSImage(data: data) { image.draw(in: NSRect(x: point.x, y: point.y, width: side, height: side), from: .zero, operation: .sourceOver, fraction: 1) }
                else { (mark.value as NSString).draw(at: point, withAttributes: [.font: NSFont.systemFont(ofSize: mark.fontSize * outputScale * mark.scale.width), .foregroundColor: nsColor]) }
            case .text:
                let box: NSRect
                if mark.points.count > 1 {
                    let end = imagePoint(mark.points[1], width: width, height: height)
                    box = NSRect(x: min(point.x, end.x), y: min(point.y, end.y), width: max(1, abs(end.x - point.x)), height: max(mark.fontSize, abs(end.y - point.y)))
                } else { box = NSRect(x: point.x, y: point.y, width: CGFloat(width), height: CGFloat(height)) }
                var outputMark = mark
                outputMark.fontSize *= outputScale
                outputMark.letterSpacing *= outputScale
                outputMark.lineSpacing *= outputScale
                let attributed = NSAttributedString(string: mark.value, attributes: saveTextAttributes(outputMark, color: nsColor))
                graphics.cgContext.saveGState()
                graphics.cgContext.translateBy(x: point.x, y: point.y)
                graphics.cgContext.rotate(by: mark.rotation.radians)
                graphics.cgContext.scaleBy(x: mark.scale.width, y: mark.scale.height)
                attributed.draw(in: NSRect(origin: .zero, size: box.size))
                graphics.cgContext.restoreGState()
            case .select: break
            }
        }
        graphics.flushGraphics(); NSGraphicsContext.restoreGraphicsState(); return bitmap.cgImage
    }

    private func imagePoint(_ point: CGPoint, width: Int, height: Int) -> CGPoint { CGPoint(x: point.x * CGFloat(width), y: (1 - point.y) * CGFloat(height)) }
}
