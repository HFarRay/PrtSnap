import SwiftUI

enum SystemAppearanceResolver {
    static func fromInterfaceStyle(_ interfaceStyle: String) -> ColorScheme {
        interfaceStyle.caseInsensitiveCompare("Dark") == .orderedSame ? .dark : .light
    }
}
