import Foundation
import ImageIO
import Vision

@MainActor
final class HistorySearchIndex: ObservableObject {
    static let shared = HistorySearchIndex()

    @Published private(set) var recognizedText: [URL: String] = [:]
    @Published private(set) var pendingCount = 0

    private struct Entry: Codable {
        let fingerprint: String
        let text: String
    }

    private let cacheKey = "historyOCRIndex.v1"
    private var cache: [String: Entry] = [:]
    private var pendingPaths: Set<String> = []

    private init() {
        if let data = UserDefaults.standard.data(forKey: cacheKey),
           let entries = try? JSONDecoder().decode([String: Entry].self, from: data) {
            cache = entries
        }
    }

    func index(_ items: [HistoryItem]) {
        for item in items {
            let path = item.id.path
            let fingerprint = Self.fingerprint(for: item.id)
            if let entry = cache[path], entry.fingerprint == fingerprint {
                recognizedText[item.id] = entry.text
                continue
            }
            guard pendingPaths.insert(path).inserted else { continue }
            recognizedText[item.id] = nil
            pendingCount = pendingPaths.count
            let url = item.id
            Task.detached(priority: .utility) { [weak self] in
                let text = Self.recognizeText(at: path)
                await self?.store(text, for: path, url: url, fingerprint: fingerprint)
            }
        }
    }

    func forget(_ url: URL) {
        cache.removeValue(forKey: url.path)
        recognizedText[url] = nil
        if let data = try? JSONEncoder().encode(cache) {
            UserDefaults.standard.set(data, forKey: cacheKey)
        }
    }

    private func store(_ text: String, for path: String, url: URL, fingerprint: String) {
        pendingPaths.remove(path)
        pendingCount = pendingPaths.count
        guard FileManager.default.fileExists(atPath: path) else { return }
        cache[path] = Entry(fingerprint: fingerprint, text: text)
        recognizedText[url] = text
        if let data = try? JSONEncoder().encode(cache) {
            UserDefaults.standard.set(data, forKey: cacheKey)
        }
    }

    private static func fingerprint(for url: URL) -> String {
        let values = try? url.resourceValues(forKeys: [.contentModificationDateKey, .fileSizeKey])
        let modified = values?.contentModificationDate?.timeIntervalSince1970 ?? 0
        return "\(values?.fileSize ?? 0):\(modified)"
    }

    nonisolated private static func recognizeText(at path: String) -> String {
        let url = URL(fileURLWithPath: path)
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil),
              let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else { return "" }

        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true
        if let languages = try? VNRecognizeTextRequest.supportedRecognitionLanguages(
            for: .accurate, revision: VNRecognizeTextRequest.currentRevision
        ) {
            let preferred = languages.filter { $0.hasPrefix("zh-Hans") || $0.hasPrefix("en") }
            request.recognitionLanguages = preferred.isEmpty ? Array(languages.prefix(4)) : preferred
        }

        do {
            try VNImageRequestHandler(cgImage: image, options: [:]).perform([request])
            return (request.results ?? []).compactMap { $0.topCandidates(1).first?.string }
                .joined(separator: " ")
        } catch {
            return ""
        }
    }
}
