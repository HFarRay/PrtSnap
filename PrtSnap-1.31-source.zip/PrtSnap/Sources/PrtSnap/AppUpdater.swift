import AppKit
import Foundation

struct PreparedAppUpdate: Identifiable, Sendable {
    let stagedAppURL: URL
    let stagingDirectoryURL: URL
    let displayVersion: String

    var id: String { stagedAppURL.path }
}

enum AppUpdateError: LocalizedError {
    case invalidDiskImage
    case mountFailed(String)
    case noApplicationFound
    case wrongApplication
    case invalidSignature
    case stagingFailed(String)
    case invalidCurrentApplication
    case authorizationCancelled
    case launchFailed(String)

    var errorDescription: String? {
        switch self {
        case .invalidDiskImage:
            "请选择 DMG 磁盘映像文件。"
        case .mountFailed(let detail):
            "无法打开 DMG：\(detail)"
        case .noApplicationFound:
            "DMG 中没有找到 PrtSnap.app。"
        case .wrongApplication:
            "此 DMG 不是此应用的兼容更新包。"
        case .invalidSignature:
            "更新包签名与此应用不匹配，已取消更新。"
        case .stagingFailed(let detail):
            "无法暂存更新包：\(detail)"
        case .invalidCurrentApplication:
            "当前应用不在可更新的安装位置，或应用签名身份不匹配。"
        case .authorizationCancelled:
            "更新授权未完成，PrtSnap 仍保持打开。"
        case .launchFailed(let detail):
            "无法启动更新：\(detail)"
        }
    }
}

enum AppUpdater {
    private static let bundleIdentifier = "local.prtsnap.app"
    private static let designatedRequirement = "designated => identifier \"local.prtsnap.app\""

    static func prepareUpdate(from diskImageURL: URL) throws -> PreparedAppUpdate {
        guard diskImageURL.pathExtension.lowercased() == "dmg" else {
            throw AppUpdateError.invalidDiskImage
        }

        let attach = try run("/usr/bin/hdiutil", [
            "attach", "-nobrowse", "-readonly", "-noautoopen", "-plist", diskImageURL.path
        ])
        guard attach.status == 0 else {
            throw AppUpdateError.mountFailed(outputText(attach.stderr.isEmpty ? attach.stdout : attach.stderr))
        }
        let plistValue: Any
        do {
            plistValue = try PropertyListSerialization.propertyList(from: attach.stdout, options: [], format: nil)
        } catch {
            throw AppUpdateError.mountFailed(error.localizedDescription)
        }
        guard let plist = plistValue as? [String: Any],
              let entities = plist["system-entities"] as? [[String: Any]] else {
            throw AppUpdateError.mountFailed("无法读取挂载信息。")
        }

        let mountPoints = entities.compactMap { $0["mount-point"] as? String }
            .map { URL(fileURLWithPath: $0, isDirectory: true) }
        defer {
            for mountPoint in mountPoints {
                _ = try? run("/usr/bin/hdiutil", ["detach", "-quiet", mountPoint.path])
            }
        }

        var appURL: URL?
        for mountPoint in mountPoints {
            let entries = try? FileManager.default.contentsOfDirectory(at: mountPoint, includingPropertiesForKeys: [.isDirectoryKey])
            appURL = entries?.first { $0.pathExtension == "app" && $0.lastPathComponent == "PrtSnap.app" }
            if appURL != nil { break }
        }
        guard let appURL else { throw AppUpdateError.noApplicationFound }

        let info = try validatedBundleInfo(at: appURL)
        let displayVersion = (info["PrtSnapDisplayVersion"] as? String)
            ?? (info["CFBundleShortVersionString"] as? String)
            ?? ""

        let stagingDirectory = FileManager.default.temporaryDirectory
            .appendingPathComponent("PrtSnap-Update-\(UUID().uuidString)", isDirectory: true)
        let stagedApp = stagingDirectory.appendingPathComponent("PrtSnap.app", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: stagingDirectory, withIntermediateDirectories: true)
            try FileManager.default.copyItem(at: appURL, to: stagedApp)
            _ = try validatedBundleInfo(at: stagedApp)
        } catch {
            try? FileManager.default.removeItem(at: stagingDirectory)
            throw AppUpdateError.stagingFailed(error.localizedDescription)
        }

        return PreparedAppUpdate(
            stagedAppURL: stagedApp,
            stagingDirectoryURL: stagingDirectory,
            displayVersion: displayVersion
        )
    }

    static func discard(_ update: PreparedAppUpdate) {
        try? FileManager.default.removeItem(at: update.stagingDirectoryURL)
    }

    static func scheduleInstall(_ update: PreparedAppUpdate, replacing currentAppURL: URL) throws {
        guard currentAppURL.pathExtension == "app",
              currentAppURL.path.hasSuffix(".app"),
              currentAppURL.path.range(of: "/AppTranslocation/", options: .caseInsensitive) == nil else {
            throw AppUpdateError.invalidCurrentApplication
        }

        let currentInfo: [String: Any]
        do {
            currentInfo = try validatedBundleInfo(at: currentAppURL)
        } catch {
            throw AppUpdateError.invalidCurrentApplication
        }
        guard currentInfo["CFBundleIdentifier"] as? String == bundleIdentifier,
              FileManager.default.fileExists(atPath: update.stagedAppURL.path) else {
            throw AppUpdateError.invalidCurrentApplication
        }

        let helperURL = update.stagingDirectoryURL.appendingPathComponent("install-update.sh")
        do {
            try installScript.write(to: helperURL, atomically: true, encoding: .utf8)
            try FileManager.default.setAttributes([.posixPermissions: 0o700], ofItemAtPath: helperURL.path)
        } catch {
            throw AppUpdateError.launchFailed(error.localizedDescription)
        }

        let arguments = [
            "spawn", String(getpid()), update.stagedAppURL.path,
            currentAppURL.path, update.stagingDirectoryURL.path
        ]
        let writable = FileManager.default.isWritableFile(atPath: currentAppURL.deletingLastPathComponent().path)
        let process = Process()
        if writable {
            process.executableURL = URL(fileURLWithPath: "/bin/bash")
            process.arguments = [helperURL.path] + arguments
        } else {
            process.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
            let command = (["/bin/bash", helperURL.path] + arguments).map(shellQuote).joined(separator: " ")
            process.arguments = ["-e", "do shell script \"\(appleScriptEscape(command))\" with administrator privileges"]
        }

        let stdout = Pipe()
        let stderr = Pipe()
        process.standardOutput = stdout
        process.standardError = stderr
        do {
            try process.run()
        } catch {
            throw AppUpdateError.launchFailed(error.localizedDescription)
        }
        let output = stdout.fileHandleForReading.readDataToEndOfFile()
        let errorOutput = stderr.fileHandleForReading.readDataToEndOfFile()
        process.waitUntilExit()
        guard process.terminationStatus == 0 else {
            let message = outputText(errorOutput.isEmpty ? output : errorOutput)
            if !writable && (message.localizedCaseInsensitiveContains("User canceled")
                || message.localizedCaseInsensitiveContains("(-128)")) {
                throw AppUpdateError.authorizationCancelled
            }
            throw AppUpdateError.launchFailed(message)
        }
    }

    private static func validatedBundleInfo(at appURL: URL) throws -> [String: Any] {
        guard let bundle = Bundle(url: appURL),
              let info = bundle.infoDictionary,
              info["CFBundleIdentifier"] as? String == bundleIdentifier,
              let executable = info["CFBundleExecutable"] as? String,
              FileManager.default.isExecutableFile(atPath: appURL.appendingPathComponent("Contents/MacOS/\(executable)").path) else {
            throw AppUpdateError.wrongApplication
        }

        let requirement = try run("/usr/bin/codesign", ["-dr", "-", appURL.path])
        let requirementText = outputText(requirement.stderr) + outputText(requirement.stdout)
        guard requirement.status == 0, requirementText.contains(designatedRequirement) else {
            throw AppUpdateError.invalidSignature
        }

        let verification = try run("/usr/bin/codesign", ["--verify", "--deep", "--strict", appURL.path])
        guard verification.status == 0 else { throw AppUpdateError.invalidSignature }
        return info
    }

    private static func run(_ executable: String, _ arguments: [String]) throws -> (status: Int32, stdout: Data, stderr: Data) {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments
        let stdout = Pipe()
        let stderr = Pipe()
        process.standardOutput = stdout
        process.standardError = stderr
        try process.run()
        let output = stdout.fileHandleForReading.readDataToEndOfFile()
        let errorOutput = stderr.fileHandleForReading.readDataToEndOfFile()
        process.waitUntilExit()
        return (process.terminationStatus, output, errorOutput)
    }

    private static func outputText(_ data: Data) -> String {
        String(data: data, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    }

    private static func shellQuote(_ value: String) -> String {
        "'" + value.replacingOccurrences(of: "'", with: "'\\''") + "'"
    }

    private static func appleScriptEscape(_ value: String) -> String {
        value.replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")
            .replacingOccurrences(of: "\n", with: "\\n")
    }

    private static let installScript = #"""
#!/bin/bash
set -u
MODE="$1"
PARENT_PID="$2"
SOURCE_APP="$3"
TARGET_APP="$4"
STAGING_DIR="$5"

if [[ "$MODE" == "spawn" ]]; then
    "$0" install "$PARENT_PID" "$SOURCE_APP" "$TARGET_APP" "$STAGING_DIR" >/dev/null 2>&1 </dev/null &
    exit 0
fi

while /bin/kill -0 "$PARENT_PID" >/dev/null 2>&1; do /bin/sleep 0.25; done
PARENT_DIR="$(/usr/bin/dirname "$TARGET_APP")"
NEW_APP="$PARENT_DIR/.PrtSnap-update-$$.app"
BACKUP_APP="$PARENT_DIR/.PrtSnap-backup-$$.app"

/usr/bin/ditto --rsrc --extattr "$SOURCE_APP" "$NEW_APP" || exit 20
if [[ -e "$TARGET_APP" ]]; then
    /bin/mv "$TARGET_APP" "$BACKUP_APP" || { /bin/rm -rf "$NEW_APP"; exit 21; }
fi
if /bin/mv "$NEW_APP" "$TARGET_APP"; then
    /bin/rm -rf "$BACKUP_APP"
    CONSOLE_UID="$(/usr/bin/stat -f %u /dev/console)"
    /bin/launchctl asuser "$CONSOLE_UID" /usr/bin/open "$TARGET_APP"
    /bin/rm -rf "$STAGING_DIR"
    exit 0
fi
if [[ -e "$BACKUP_APP" ]]; then /bin/mv "$BACKUP_APP" "$TARGET_APP"; fi
/bin/rm -rf "$NEW_APP"
exit 22
"""#
}
