import AppKit
import ApplicationServices
import CoreGraphics
import IOKit.hidsystem
import ScreenCaptureKit
import UserNotifications

enum PermissionKind: String, CaseIterable, Identifiable {
    case screenRecording
    case accessibility
    case inputMonitoring
    case notifications

    var id: String { rawValue }
    var title: String {
        switch self {
        case .screenRecording: "屏幕与系统音频录制"
        case .accessibility: "辅助功能"
        case .inputMonitoring: "输入监控"
        case .notifications: "通知"
        }
    }
    var detail: String {
        switch self {
        case .screenRecording: "macOS 将屏幕与系统音频录制作为同一项隐私授权管理"
        case .accessibility: "让全局快捷键在其他应用中工作"
        case .inputMonitoring: "监听自定义全局按键所需"
        case .notifications: "显示截图完成或权限提示"
        }
    }
    var settingsURL: URL? {
        let anchor: String
        switch self {
        case .screenRecording: anchor = "Privacy_ScreenCapture"
        case .accessibility: anchor = "Privacy_Accessibility"
        case .inputMonitoring: anchor = "Privacy_ListenEvent"
        case .notifications: return URL(string: "x-apple.systempreferences:com.apple.Notifications-Settings.extension")
        }
        return URL(string: "x-apple.systempreferences:com.apple.preference.security?\(anchor)")
    }
}

@MainActor
final class PermissionCenter: ObservableObject {
    static let shared = PermissionCenter()

    @Published private(set) var screenRecording = false
    @Published private(set) var accessibility = false
    @Published private(set) var inputMonitoring = false
    @Published private(set) var notifications = false
    @Published private(set) var lastUpdated = Date()
    private var refreshGeneration: UInt64 = 0

    private init() { refresh() }

    func isEnabled(_ kind: PermissionKind) -> Bool {
        switch kind {
        case .screenRecording: screenRecording
        case .accessibility: accessibility
        case .inputMonitoring: inputMonitoring
        case .notifications: notifications
        }
    }

    func refresh() {
        refreshGeneration &+= 1
        let generation = refreshGeneration
        accessibility = AXIsProcessTrusted()
        inputMonitoring = PermissionStatusMapping.isInputMonitoringGranted(
            IOHIDCheckAccess(kIOHIDRequestTypeListenEvent)
        )
        screenRecording = CGPreflightScreenCaptureAccess()
        UNUserNotificationCenter.current().getNotificationSettings { [weak self] settings in
            let enabled = settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional
            Task { @MainActor in
                guard self?.refreshGeneration == generation else { return }
                self?.notifications = enabled
                self?.lastUpdated = Date()
            }
        }
        lastUpdated = Date()
    }

    func refreshAfterActivation() {
        refresh()
        for delay in [0.4, 1.4] {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                Task { @MainActor in self?.refresh() }
            }
        }
    }

    func request(_ kind: PermissionKind) {
        switch kind {
        case .screenRecording:
            _ = CGRequestScreenCaptureAccess()
            if let url = kind.settingsURL { NSWorkspace.shared.open(url) }
        case .notifications:
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in
                Task { @MainActor in self.refreshAfterActivation() }
            }
        case .accessibility:
            let options = ["AXTrustedCheckOptionPrompt": true] as CFDictionary
            _ = AXIsProcessTrustedWithOptions(options)
            if let url = kind.settingsURL { NSWorkspace.shared.open(url) }
        case .inputMonitoring:
            _ = IOHIDRequestAccess(kIOHIDRequestTypeListenEvent)
            if let url = kind.settingsURL { NSWorkspace.shared.open(url) }
        }
        refreshAfterActivation()
    }
}
