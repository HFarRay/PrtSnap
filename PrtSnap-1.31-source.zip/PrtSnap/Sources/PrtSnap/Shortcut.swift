import Carbon.HIToolbox
import Foundation

struct ShortcutKey: Codable, Equatable, Identifiable {
    let id: UUID
    var keyCode: UInt32?
    var displayValue: String

    init(keyCode: UInt32?, displayValue: String? = nil) {
        id = UUID()
        self.keyCode = keyCode
        self.displayValue = displayValue ?? keyCode.map(KeyNames.name(for:)) ?? "按下录入"
    }

    private enum CodingKeys: String, CodingKey { case id, keyCode, displayValue }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        keyCode = try values.decodeIfPresent(UInt32.self, forKey: .keyCode)
        displayValue = try values.decodeIfPresent(String.self, forKey: .displayValue)
            ?? keyCode.map(KeyNames.name(for:))
            ?? "按下录入"
    }
}

struct Shortcut: Codable, Equatable {
    var keys: [ShortcutKey]

    var keyCodes: [UInt32] { keys.compactMap(\.keyCode) }
    var isComplete: Bool { !keys.isEmpty && keys.allSatisfy { $0.keyCode != nil } }
    var label: String {
        let values = keys.map(\.displayValue).filter { !$0.isEmpty }
        return values.isEmpty ? "设置快捷键" : values.joined(separator: " + ")
    }

    init(keyCodes: [UInt32]) {
        keys = keyCodes.map { ShortcutKey(keyCode: $0) }
    }

    private enum CodingKeys: String, CodingKey { case keys, keyCode, modifiers }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        if let keys = try values.decodeIfPresent([ShortcutKey].self, forKey: .keys) {
            self.keys = keys
            return
        }

        guard let keyCode = try values.decodeIfPresent(UInt32.self, forKey: .keyCode) else {
            keys = []
            return
        }
        let modifiers = try values.decodeIfPresent(UInt32.self, forKey: .modifiers) ?? 0
        var migrated: [UInt32] = []
        if modifiers & UInt32(controlKey) != 0 { migrated.append(59) }
        if modifiers & UInt32(optionKey) != 0 { migrated.append(58) }
        if modifiers & UInt32(shiftKey) != 0 { migrated.append(56) }
        if modifiers & UInt32(cmdKey) != 0 { migrated.append(55) }
        migrated.append(keyCode)
        keys = migrated.map { ShortcutKey(keyCode: $0) }
    }

    func encode(to encoder: Encoder) throws {
        var values = encoder.container(keyedBy: CodingKeys.self)
        try values.encode(keys, forKey: .keys)
    }
}

enum KeyNames {
    private static let names: [UInt32: String] = [
        0: "A", 1: "S", 2: "D", 3: "F", 4: "H", 5: "G", 6: "Z", 7: "X",
        8: "C", 9: "V", 10: "§", 11: "B", 12: "Q", 13: "W", 14: "E", 15: "R",
        16: "Y", 17: "T", 18: "1", 19: "2", 20: "3", 21: "4", 22: "6", 23: "5",
        24: "=", 25: "9", 26: "7", 27: "-", 28: "8", 29: "0", 30: "]", 31: "O",
        32: "U", 33: "[", 34: "I", 35: "P", 36: "Return", 37: "L", 38: "J", 39: "'",
        40: "K", 41: ";", 42: "\\", 43: ",", 44: "/", 45: "N", 46: "M", 47: ".",
        48: "Tab", 49: "Space", 50: "`", 51: "Delete", 52: "Enter", 53: "Esc",
        54: "⌘", 55: "⌘", 56: "⇧", 57: "Caps Lock", 58: "⌥", 59: "⌃", 60: "⇧",
        61: "⌥", 62: "⌃", 63: "Fn", 64: "F17", 65: "Keypad .", 67: "Keypad *",
        69: "Keypad +", 71: "Num Lock", 75: "Keypad /", 76: "Keypad Enter", 78: "Keypad -",
        79: "F18", 80: "F19", 81: "Keypad =", 82: "Keypad 0", 83: "Keypad 1",
        84: "Keypad 2", 85: "Keypad 3", 86: "Keypad 4", 87: "Keypad 5", 88: "Keypad 6",
        89: "Keypad 7", 91: "Keypad 8", 92: "Keypad 9", 96: "F5", 97: "F6", 98: "F7",
        99: "F3", 100: "F8", 101: "F9", 103: "F11", 105: "F13", 106: "F16",
        107: "F14", 109: "F10", 111: "F12", 113: "F15", 114: "Help", 115: "Home",
        116: "Page Up", 117: "Forward Delete", 118: "F4", 119: "End", 120: "F2",
        121: "Page Down", 122: "F1", 123: "←", 124: "→", 125: "↓", 126: "↑"
    ]

    static func name(for keyCode: UInt32) -> String {
        names[keyCode] ?? "未知按键"
    }

    static func canonicalKeyCode(_ keyCode: UInt32) -> UInt32 {
        switch keyCode {
        case 54, 55: 55
        case 56, 60: 56
        case 58, 61: 58
        case 59, 62: 59
        default: keyCode
        }
    }

    static func recordedKeyCode(
        eventKeyCode: UInt32,
        isModifierEvent: Bool,
        modifiers: ShortcutModifiers
    ) -> UInt32 {
        guard !isModifierEvent else { return eventKeyCode }
        if modifiers.contains(.command) { return 55 }
        if modifiers.contains(.option) { return 58 }
        if modifiers.contains(.shift) { return 56 }
        if modifiers.contains(.control) { return 59 }
        return eventKeyCode
    }

    static func displayValue(for keyCode: UInt32, characters: String?) -> String {
        if let name = names[keyCode] { return name }
        if let characters, let character = characters.first, !character.isWhitespace {
            return String(character).uppercased()
        }
        return "未知按键"
    }
}

struct ShortcutModifiers: OptionSet {
    let rawValue: UInt8

    static let command = Self(rawValue: 1 << 0)
    static let option = Self(rawValue: 1 << 1)
    static let shift = Self(rawValue: 1 << 2)
    static let control = Self(rawValue: 1 << 3)
}
