import AppKit
import CoreGraphics
import Foundation

struct ScreenCompositionSource {
    let frame: CGRect
    let image: CGImage
}

struct ScreenCompositionPlacement {
    let frame: CGRect
    let imageRect: CGRect
}

struct ScreenCompositionLayout {
    let canvasSize: CGSize
    let pixelScale: CGFloat
    let placements: [ScreenCompositionPlacement]
}

enum ScreenCompositionError: LocalizedError {
    case noDisplays
    case invalidDisplayFrame
    case cannotCreateCanvas
    case unavailableColorProfile

    var errorDescription: String? {
        switch self {
        case .noDisplays: "未找到显示器"
        case .invalidDisplayFrame: "无法读取显示器排列"
        case .cannotCreateCanvas: "无法合成多屏幕截图"
        case .unavailableColorProfile: "显示器截图缺少色彩配置文件"
        }
    }
}

enum ScreenComposition {
    static func cursorScreenIndex(at point: CGPoint, frames: [CGRect]) -> Int? {
        let normalizedFrames = frames.map(\.standardized)
        guard !normalizedFrames.isEmpty else { return nil }
        if let index = normalizedFrames.firstIndex(where: { $0.contains(point) }) {
            return index
        }

        return normalizedFrames.enumerated().min { lhs, rhs in
            distanceSquared(from: point, to: lhs.element) < distanceSquared(from: point, to: rhs.element)
        }?.offset
    }

    static func layout(for sources: [ScreenCompositionSource]) throws -> ScreenCompositionLayout {
        guard !sources.isEmpty else { throw ScreenCompositionError.noDisplays }

        var bounds = CGRect.null
        var pixelScale: CGFloat = 0
        for source in sources {
            let frame = source.frame.standardized
            guard frame.width.isFinite, frame.height.isFinite,
                  frame.width > 0, frame.height > 0,
                  source.image.width > 0, source.image.height > 0 else {
                throw ScreenCompositionError.invalidDisplayFrame
            }
            bounds = bounds.union(frame)
            pixelScale = max(pixelScale, max(
                CGFloat(source.image.width) / frame.width,
                CGFloat(source.image.height) / frame.height
            ))
        }
        guard !bounds.isNull, pixelScale.isFinite, pixelScale > 0 else {
            throw ScreenCompositionError.invalidDisplayFrame
        }

        let canvasWidth = ceil(bounds.width * pixelScale)
        let canvasHeight = ceil(bounds.height * pixelScale)
        let placements = sources.map { source -> ScreenCompositionPlacement in
            let frame = source.frame.standardized
            let displayRect = CGRect(
                x: (frame.minX - bounds.minX) * pixelScale,
                y: (frame.minY - bounds.minY) * pixelScale,
                width: frame.width * pixelScale,
                height: frame.height * pixelScale
            )
            let fitScale = min(
                displayRect.width / CGFloat(source.image.width),
                displayRect.height / CGFloat(source.image.height)
            )
            let imageSize = CGSize(
                width: CGFloat(source.image.width) * fitScale,
                height: CGFloat(source.image.height) * fitScale
            )
            let imageRect = CGRect(
                x: displayRect.midX - imageSize.width / 2,
                y: displayRect.midY - imageSize.height / 2,
                width: imageSize.width,
                height: imageSize.height
            )
            return ScreenCompositionPlacement(frame: displayRect, imageRect: imageRect)
        }

        return ScreenCompositionLayout(
            canvasSize: CGSize(width: canvasWidth, height: canvasHeight),
            pixelScale: pixelScale,
            placements: placements
        )
    }

    static func compose(_ sources: [ScreenCompositionSource]) throws -> CGImage {
        let layout = try layout(for: sources)
        let firstImage = sources[0].image
        guard let colorSpace = firstImage.colorSpace else {
            throw ScreenCompositionError.unavailableColorProfile
        }
        let preservesFloatRange = sources.contains { $0.image.bitmapInfo.contains(.floatComponents) }
        let bitsPerComponent = preservesFloatRange ? 16 : max(8, firstImage.bitsPerComponent)
        var bitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue)
        if preservesFloatRange {
            bitmapInfo.formUnion(.floatComponents)
            bitmapInfo.formUnion(.byteOrder16Little)
        }

        guard let context = CGContext(
            data: nil,
            width: Int(layout.canvasSize.width),
            height: Int(layout.canvasSize.height),
            bitsPerComponent: bitsPerComponent,
            bytesPerRow: 0,
            space: colorSpace,
            bitmapInfo: bitmapInfo.rawValue
        ) else {
            throw ScreenCompositionError.cannotCreateCanvas
        }

        context.setFillColor(CGColor(gray: 0, alpha: 1))
        context.fill(CGRect(origin: .zero, size: layout.canvasSize))
        context.interpolationQuality = .high
        context.setRenderingIntent(.relativeColorimetric)
        for (source, placement) in zip(sources, layout.placements) {
            context.draw(source.image, in: placement.imageRect)
        }
        guard var image = context.makeImage() else {
            throw ScreenCompositionError.cannotCreateCanvas
        }

        if #available(macOS 15.0, *) {
            let headroom = sources.map { $0.image.contentHeadroom }.max() ?? 1
            if headroom > 1, let tagged = CGImageCreateCopyWithContentHeadroom(headroom, image) {
                image = tagged
            }
        }
        return image
    }

    private static func distanceSquared(from point: CGPoint, to rect: CGRect) -> CGFloat {
        let dx = point.x < rect.minX ? rect.minX - point.x : point.x > rect.maxX ? point.x - rect.maxX : 0
        let dy = point.y < rect.minY ? rect.minY - point.y : point.y > rect.maxY ? point.y - rect.maxY : 0
        return dx * dx + dy * dy
    }
}
