import AppKit
import Foundation

struct HistoryItem: Identifiable, Equatable {
    let id: URL

    var filename: String { id.lastPathComponent }
    var date: Date { (try? id.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast }
    var image: NSImage? { NSImage(contentsOf: id) }
}

@MainActor
final class HistoryManager: ObservableObject {
    static let shared = HistoryManager()

    @Published private(set) var items: [HistoryItem] = []
    @Published private(set) var directory: URL
    private var cleanupTask: Task<Void, Never>?
    private var hasDirectorySecurityAccess = false

    private static let directoryBookmarkKey = "historyDirectoryBookmark"
    private static let directoryPathKey = "historyDirectoryPath"
    private static let retentionMigrationKey = "historyRetentionRecordsV114Migrated"

    private static var defaultHistoryDirectory: URL {
        FileManager.default.urls(for: .picturesDirectory, in: .userDomainMask).first!
            .appendingPathComponent("PrtSnap History", isDirectory: true)
    }

    private init() {
        directory = Self.restoredDirectory() ?? Self.defaultHistoryDirectory
        hasDirectorySecurityAccess = directory.startAccessingSecurityScopedResource()
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        migrateLegacyRetentionRecords()
        refresh()
        cleanupTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 60_000_000_000)
                guard let self else { return }
                self.refresh()
            }
        }
    }

    func refresh() {
        var urls = (try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.contentModificationDateKey], options: [.skipsHiddenFiles])) ?? []
        let expired = urls.filter { isExpired($0, at: .now) }
        for url in expired {
            try? FileManager.default.removeItem(at: url)
            removeRetentionRecord(for: url)
            HistorySearchIndex.shared.forget(url)
        }
        urls.removeAll { expired.contains($0) }
        items = urls.filter { ["png", "jpg", "jpeg"].contains($0.pathExtension.lowercased()) }
            .map(HistoryItem.init)
            .sorted { $0.date > $1.date }
    }

    func record(data: Data, format: String) {
        let ext = format == "PNG" ? "png" : "jpg"
        let stamp = ISO8601DateFormatter().string(from: Date()).replacingOccurrences(of: ":", with: "-")
        let url = directory.appendingPathComponent("Screenshot-\(stamp).\(ext)")
        do {
            try data.write(to: url, options: .atomic)
            saveRetentionRecord(for: url)
            refresh()
        } catch {
            Preferences.shared.status = "历史截图保存失败：\(error.localizedDescription)"
        }
    }

    func delete(_ item: HistoryItem) {
        try? FileManager.default.removeItem(at: item.id)
        removeRetentionRecord(for: item.id)
        HistorySearchIndex.shared.forget(item.id)
        refresh()
    }

    func delete(_ items: [HistoryItem]) {
        for item in items {
            try? FileManager.default.removeItem(at: item.id)
            removeRetentionRecord(for: item.id)
            HistorySearchIndex.shared.forget(item.id)
        }
        refresh()
    }

    func copyToPasteboard(_ item: HistoryItem) {
        copyToPasteboard([item])
    }

    func copyToPasteboard(_ items: [HistoryItem]) {
        let images = items.compactMap(\.image)
        guard !images.isEmpty else {
            Preferences.shared.status = "无法读取这张截图"
            return
        }
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        guard pasteboard.writeObjects(images) else {
            Preferences.shared.status = "复制历史截图失败"
            return
        }
        Preferences.shared.status = images.count == 1 ? "历史截图已复制到剪贴板" : "已复制 \(images.count) 张截图到剪贴板"
    }

    func saveEdited(_ data: Data, format: String) {
        let ext = format == "PNG" ? "png" : "jpg"
        let stamp = ISO8601DateFormatter().string(from: Date()).replacingOccurrences(of: ":", with: "-")
        let url = directory.appendingPathComponent("Edited-\(stamp).\(ext)")
        do {
            try data.write(to: url, options: .atomic)
            saveRetentionRecord(for: url)
            refresh()
            Preferences.shared.status = "已保存编辑截图 · \(url.lastPathComponent)"
        } catch {
            Preferences.shared.status = "编辑截图保存失败：\(error.localizedDescription)"
        }
    }

    func revealFolder() {
        NSWorkspace.shared.open(directory)
    }

    var isDefaultDirectory: Bool {
        directory.standardizedFileURL == Self.defaultHistoryDirectory.standardizedFileURL
    }

    func setDirectory(_ selectedDirectory: URL) throws {
        let accessStarted = selectedDirectory.startAccessingSecurityScopedResource()
        do {
            try FileManager.default.createDirectory(at: selectedDirectory, withIntermediateDirectories: true)
        } catch {
            if accessStarted { selectedDirectory.stopAccessingSecurityScopedResource() }
            throw error
        }

        let bookmark = try? selectedDirectory.bookmarkData(options: [.withSecurityScope],
                                                            includingResourceValuesForKeys: nil,
                                                            relativeTo: nil)
        UserDefaults.standard.set(selectedDirectory.path, forKey: Self.directoryPathKey)
        if let bookmark {
            UserDefaults.standard.set(bookmark, forKey: Self.directoryBookmarkKey)
        } else {
            UserDefaults.standard.removeObject(forKey: Self.directoryBookmarkKey)
        }

        if hasDirectorySecurityAccess { directory.stopAccessingSecurityScopedResource() }
        directory = selectedDirectory
        hasDirectorySecurityAccess = accessStarted
        refresh()
        Preferences.shared.status = "历史截图保存位置已更新"
    }

    func restoreDefaultDirectory() {
        UserDefaults.standard.removeObject(forKey: Self.directoryBookmarkKey)
        UserDefaults.standard.removeObject(forKey: Self.directoryPathKey)
        if hasDirectorySecurityAccess { directory.stopAccessingSecurityScopedResource() }
        directory = Self.defaultHistoryDirectory
        hasDirectorySecurityAccess = directory.startAccessingSecurityScopedResource()
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        refresh()
        Preferences.shared.status = "已恢复默认历史截图目录"
    }

    private func saveRetentionRecord(for url: URL) {
        let retention = HistoryRetention(rawValue: Preferences.shared.historyRetention) ?? .never
        saveRetentionRecord(for: url, retention: retention, createdAt: .now)
    }

    @discardableResult
    private func saveRetentionRecord(for url: URL, retention: HistoryRetention, createdAt: Date) -> Bool {
        let record = HistoryRetentionRecord(retention: retention, createdAt: createdAt)
        guard let data = try? JSONEncoder().encode(record) else { return false }
        do {
            try data.write(to: retentionRecordURL(for: url), options: .atomic)
            return true
        } catch {
            return false
        }
    }

    private func isExpired(_ url: URL, at date: Date) -> Bool {
        guard let data = try? Data(contentsOf: retentionRecordURL(for: url)),
              let record = try? JSONDecoder().decode(HistoryRetentionRecord.self, from: data) else { return false }
        return record.isExpired(at: date)
    }

    private func retentionRecordURL(for url: URL) -> URL {
        directory.appendingPathComponent(".\(url.lastPathComponent).prtsnap-retention.json")
    }

    private func removeRetentionRecord(for url: URL) {
        try? FileManager.default.removeItem(at: retentionRecordURL(for: url))
    }

    private func migrateLegacyRetentionRecords() {
        let defaults = UserDefaults.standard
        guard !defaults.bool(forKey: Self.retentionMigrationKey) else { return }
        let retention = HistoryRetention(rawValue: Preferences.shared.historyRetention) ?? .never
        let urls = (try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: [.contentModificationDateKey], options: [.skipsHiddenFiles])) ?? []
        var complete = true
        for url in urls where ["png", "jpg", "jpeg"].contains(url.pathExtension.lowercased()) {
            guard !FileManager.default.fileExists(atPath: retentionRecordURL(for: url).path) else { continue }
            let createdAt = (try? url.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .now
            if !saveRetentionRecord(for: url, retention: retention, createdAt: createdAt) {
                complete = false
            }
        }
        if complete { defaults.set(true, forKey: Self.retentionMigrationKey) }
    }

    private static func restoredDirectory() -> URL? {
        let defaults = UserDefaults.standard
        if let bookmark = defaults.data(forKey: directoryBookmarkKey) {
            var isStale = false
            if let url = try? URL(resolvingBookmarkData: bookmark, options: [.withSecurityScope],
                                  relativeTo: nil, bookmarkDataIsStale: &isStale) {
                if isStale, let updated = try? url.bookmarkData(options: [.withSecurityScope],
                                                               includingResourceValuesForKeys: nil,
                                                               relativeTo: nil) {
                    defaults.set(updated, forKey: directoryBookmarkKey)
                }
                return url
            }
        }
        guard let path = defaults.string(forKey: directoryPathKey) else { return nil }
        return URL(fileURLWithPath: path, isDirectory: true)
    }
}
