struct EditorUndoHistory<Value: Equatable> {
    private(set) var undoStack: [Value] = []
    private(set) var redoStack: [Value] = []
    let limit: Int

    init(limit: Int = 100) {
        self.limit = max(1, limit)
    }

    mutating func record(before value: Value) {
        undoStack.append(value)
        if undoStack.count > limit { undoStack.removeFirst(undoStack.count - limit) }
        redoStack.removeAll()
    }

    mutating func undo(current value: Value) -> Value? {
        guard let previous = undoStack.popLast() else { return nil }
        redoStack.append(value)
        return previous
    }

    mutating func redo(current value: Value) -> Value? {
        guard let next = redoStack.popLast() else { return nil }
        undoStack.append(value)
        if undoStack.count > limit { undoStack.removeFirst(undoStack.count - limit) }
        return next
    }
}
