import Foundation

enum HistoryRetention: String, CaseIterable, Identifiable {
    case oneHour = "1 小时后自动删除"
    case oneDay = "1 天后自动删除"
    case sevenDays = "7 天后自动删除"
    case thirtyDays = "30 天后自动删除"
    case oneYear = "365 天后自动删除"
    case never = "永不删除"

    var id: String { rawValue }

    static func migratedRawValue(_ storedValue: String?) -> String {
        guard let storedValue else { return never.rawValue }
        return switch storedValue {
        case "一小时后自动删除": oneHour.rawValue
        case "一天后自动删除": oneDay.rawValue
        case "七天后自动删除": sevenDays.rawValue
        case "三十天后自动删除": thirtyDays.rawValue
        case "365天后自动删除": oneYear.rawValue
        default: allCases.first(where: { $0.rawValue == storedValue })?.rawValue ?? never.rawValue
        }
    }

    var lifetime: TimeInterval? {
        switch self {
        case .oneHour: return 60 * 60
        case .oneDay: return 24 * 60 * 60
        case .sevenDays: return 7 * 24 * 60 * 60
        case .thirtyDays: return 30 * 24 * 60 * 60
        case .oneYear: return 365 * 24 * 60 * 60
        case .never: return nil
        }
    }
}

struct HistoryRetentionRecord: Codable, Equatable {
    let expiresAt: Date?

    init(retention: HistoryRetention, createdAt: Date) {
        expiresAt = retention.lifetime.map { createdAt.addingTimeInterval($0) }
    }

    func isExpired(at date: Date) -> Bool {
        guard let expiresAt else { return false }
        return date >= expiresAt
    }
}
