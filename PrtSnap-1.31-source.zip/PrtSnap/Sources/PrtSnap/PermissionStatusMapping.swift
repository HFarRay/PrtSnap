import IOKit.hidsystem

enum PermissionStatusMapping {
    static func isInputMonitoringGranted(_ status: IOHIDAccessType) -> Bool {
        status == kIOHIDAccessTypeGranted
    }
}
