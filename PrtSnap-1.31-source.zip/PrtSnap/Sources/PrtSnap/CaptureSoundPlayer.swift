import AppKit
import UniformTypeIdentifiers

private enum CaptureSoundError: LocalizedError {
    case unsupportedFormat
    case unsupportedAudio

    var errorDescription: String? {
        switch self {
        case .unsupportedFormat: "请选择音频文件。"
        case .unsupportedAudio: "此音频格式无法由 macOS 播放。"
        }
    }
}

@MainActor
final class CaptureSoundPlayer {
    static let shared = CaptureSoundPlayer()
    static let disabled = "关闭"
    static let defaultScreenSound = "Frog"
    static let defaultWindowSound = "Submarine"

    private static let systemSoundChoices: [String] = {
        let directory = URL(fileURLWithPath: "/System/Library/Sounds", isDirectory: true)
        let files = (try? FileManager.default.contentsOfDirectory(at: directory,
                                                                  includingPropertiesForKeys: nil)) ?? []
        let sounds = files.filter { $0.pathExtension.lowercased() == "aiff" }
            .map { $0.deletingPathExtension().lastPathComponent }
            .sorted { $0.localizedStandardCompare($1) == .orderedAscending }
        return sounds
    }()

    private static let customPrefix = "custom:"
    private static let customSoundsKey = "customCaptureSounds"
    private static let customSoundNamesKey = "customCaptureSoundNames"
    private static let soundDirectory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("PrtSnap/Sounds", isDirectory: true)
    private let defaults = UserDefaults.standard
    private var currentSound: NSSound?

    private init() {}

    static var choices: [String] {
        let custom = customSoundPaths.keys.map { customPrefix + $0 }
            .sorted { title(for: $0).localizedStandardCompare(title(for: $1)) == .orderedAscending }
        return [disabled] + systemSoundChoices + custom
    }

    static func title(for name: String) -> String {
        guard name != disabled else { return "关闭" }
        guard name.hasPrefix(customPrefix) else { return name }
        let identifier = String(name.dropFirst(customPrefix.count))
        return customSoundNames[identifier]
            ?? URL(fileURLWithPath: customSoundPaths[identifier] ?? "").deletingPathExtension().lastPathComponent
    }

    func importSound(from sourceURL: URL) throws -> String {
        let hasAccess = sourceURL.startAccessingSecurityScopedResource()
        defer { if hasAccess { sourceURL.stopAccessingSecurityScopedResource() } }

        let fileExtension = sourceURL.pathExtension.lowercased()
        guard let type = UTType(filenameExtension: fileExtension), type.conforms(to: .audio) else {
            throw CaptureSoundError.unsupportedFormat
        }

        try FileManager.default.createDirectory(at: Self.soundDirectory, withIntermediateDirectories: true)
        let identifier = UUID().uuidString
        let destination = Self.soundDirectory.appendingPathComponent("\(identifier).\(fileExtension)")
        try FileManager.default.copyItem(at: sourceURL, to: destination)
        guard NSSound(contentsOf: destination, byReference: false) != nil else {
            try? FileManager.default.removeItem(at: destination)
            throw CaptureSoundError.unsupportedAudio
        }

        var paths = Self.customSoundPaths
        paths[identifier] = destination.path
        defaults.set(paths, forKey: Self.customSoundsKey)
        var names = Self.customSoundNames
        names[identifier] = sourceURL.deletingPathExtension().lastPathComponent
        defaults.set(names, forKey: Self.customSoundNamesKey)
        return Self.customPrefix + identifier
    }

    func play(_ name: String) {
        guard name != Self.disabled else { return }
        let url: URL
        if name.hasPrefix(Self.customPrefix) {
            let identifier = String(name.dropFirst(Self.customPrefix.count))
            guard let path = Self.customSoundPaths[identifier] else {
                Preferences.shared.status = "找不到已导入的音效"
                return
            }
            url = URL(fileURLWithPath: path)
        } else {
            url = URL(fileURLWithPath: "/System/Library/Sounds/\(name).aiff")
        }
        guard FileManager.default.fileExists(atPath: url.path),
              let sound = NSSound(contentsOf: url, byReference: true) else {
            Preferences.shared.status = "找不到音效：\(Self.title(for: name))"
            return
        }
        currentSound?.stop()
        currentSound = sound
        sound.play()
    }

    private static var customSoundPaths: [String: String] {
        let paths = UserDefaults.standard.dictionary(forKey: customSoundsKey) as? [String: String] ?? [:]
        return paths.filter { FileManager.default.fileExists(atPath: $0.value) }
    }

    private static var customSoundNames: [String: String] {
        UserDefaults.standard.dictionary(forKey: customSoundNamesKey) as? [String: String] ?? [:]
    }
}
