import AppKit

enum CaptureKind: String, Sendable { case screen, window }

struct HotkeyBinding: Sendable {
    let kind: CaptureKind
    let keyCodes: Set<UInt32>
}

final class HotkeyEventMatcher: @unchecked Sendable {
    private let lock = NSLock()
    private let onCapture: @Sendable (CaptureKind) -> Void
    private var bindings: [HotkeyBinding] = []
    private var pressedKeys: Set<UInt32> = []
    private var firedShortcuts: Set<CaptureKind> = []
    private var swallowedKeys: Set<UInt32> = []
    private var eventTap: CFMachPort?

    init(onCapture: @escaping @Sendable (CaptureKind) -> Void) {
        self.onCapture = onCapture
    }

    func setBindings(_ bindings: [HotkeyBinding]) {
        lock.lock()
        self.bindings = bindings
        pressedKeys.removeAll()
        firedShortcuts.removeAll()
        swallowedKeys.removeAll()
        lock.unlock()
    }

    func setEventTap(_ eventTap: CFMachPort) {
        lock.lock()
        self.eventTap = eventTap
        lock.unlock()
    }

    func handle(_ type: CGEventType, event: CGEvent) -> Unmanaged<CGEvent>? {
        if type == .tapDisabledByTimeout || type == .tapDisabledByUserInput {
            lock.lock()
            let eventTap = self.eventTap
            lock.unlock()
            if let eventTap { CGEvent.tapEnable(tap: eventTap, enable: true) }
            return Unmanaged.passUnretained(event)
        }
        guard type == .keyDown || type == .keyUp || type == .flagsChanged else {
            return Unmanaged.passUnretained(event)
        }

        let keyCode = UInt32(event.getIntegerValueField(.keyboardEventKeycode))
        let canonicalKey = KeyNames.canonicalKeyCode(keyCode)
        let flags = NSEvent.ModifierFlags(rawValue: UInt(event.flags.rawValue))
        var captures: [CaptureKind] = []
        var shouldSwallow = false

        lock.lock()
        let wasSwallowed = swallowedKeys.contains(canonicalKey)
        if type == .flagsChanged {
            if let modifier = Self.modifierFlag(for: keyCode) {
                if flags.contains(modifier) { pressedKeys.insert(keyCode) }
                else { pressedKeys.remove(keyCode) }
            }
        } else if type == .keyDown {
            pressedKeys.insert(keyCode)
        } else {
            pressedKeys.remove(keyCode)
        }

        for binding in bindings {
            let pressed = Set(pressedKeys.map(KeyNames.canonicalKeyCode))
            let matches = !binding.keyCodes.isEmpty && binding.keyCodes == pressed
            if matches {
                swallowedKeys.formUnion(binding.keyCodes)
                if firedShortcuts.insert(binding.kind).inserted { captures.append(binding.kind) }
                shouldSwallow = true
            } else {
                firedShortcuts.remove(binding.kind)
            }
        }
        if wasSwallowed {
            shouldSwallow = true
            if type == .keyUp || (type == .flagsChanged && !flags.contains(Self.modifierFlag(for: keyCode) ?? [])) {
                swallowedKeys.remove(canonicalKey)
            }
        }
        lock.unlock()

        captures.forEach(onCapture)
        return shouldSwallow ? nil : Unmanaged.passUnretained(event)
    }

    private static func modifierFlag(for keyCode: UInt32) -> NSEvent.ModifierFlags? {
        switch keyCode {
        case 54, 55: .command
        case 56, 60: .shift
        case 58, 61: .option
        case 59, 62: .control
        case 57: .capsLock
        case 63: .function
        default: nil
        }
    }
}
