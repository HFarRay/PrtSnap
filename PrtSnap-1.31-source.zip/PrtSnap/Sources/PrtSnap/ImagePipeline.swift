import AppKit
import CoreGraphics
import CoreImage
@preconcurrency import ColorSync
import Foundation
import ImageIO
import UniformTypeIdentifiers

enum GamutMappingMode: String, CaseIterable, Identifiable {
    case clip = "clip"
    case perceptual = "perceptual"

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .clip: "超出色域直接裁切"
        case .perceptual: "感知式压缩"
        }
    }

    var renderingIntent: CGColorRenderingIntent {
        switch self {
        case .clip: .relativeColorimetric
        case .perceptual: .perceptual
        }
    }
}

enum OutputColorSpace: String, CaseIterable, Identifiable {
    case sRGB = "sRGB"
    case rec709 = "Rec.709"
    case displayP3 = "Display P3"
    case rec2020 = "Rec.2020"

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .sRGB: "sRGB Gamma 2.4"
        case .rec709: "Rec.709 Gamma 2.2"
        case .displayP3: "Display P3 Gamma 2.4"
        case .rec2020: "Rec.2020 Gamma 2.4"
        }
    }

    var cgColorSpace: CGColorSpace? {
        let name: CFString
        switch self {
        case .sRGB: name = CGColorSpace.sRGB
        case .rec709: name = CGColorSpace.itur_709
        case .displayP3: name = CGColorSpace.displayP3
        case .rec2020: name = CGColorSpace.itur_2020
        }
        return CGColorSpace(name: name)
    }

    /// Color space used by ScreenCaptureKit while retaining HDR headroom.
    /// Rec.709 has no extended-linear CoreGraphics profile, so it uses the
    /// extended-linear sRGB transfer as a non-clipping source container and is
    /// converted to the BT.709 primaries/transfer in the output stage.
    var extendedCaptureColorSpaceName: CFString {
        switch self {
        case .sRGB, .rec709: CGColorSpace.extendedLinearSRGB
        case .displayP3: CGColorSpace.extendedLinearDisplayP3
        case .rec2020: CGColorSpace.extendedLinearITUR_2020
        }
    }
}

enum ImagePipelineError: LocalizedError {
    case unavailableColorProfile
    case cannotCreateBitmap
    case cannotEncode

    var errorDescription: String? {
        switch self {
        case .unavailableColorProfile: "所选色彩空间不可用"
        case .cannotCreateBitmap: "无法执行色彩转换"
        case .cannotEncode: "图像编码失败"
        }
    }
}

enum ImagePipeline {
    static func outputColorSpace(
        format: String,
        convertHDRToSDR: Bool,
        selected: OutputColorSpace
    ) -> OutputColorSpace {
        format == "PNG" && !convertHDRToSDR ? .rec2020 : selected
    }

    /// Selects the source container for ScreenCaptureKit. HDR is always
    /// captured in an extended-linear space so tone mapping can see values
    /// above SDR white; the selected output primaries are still respected.
    static func captureColorSpaceName(
        format: String,
        convertHDRToSDR: Bool,
        selected: OutputColorSpace
    ) -> CFString {
        let output = outputColorSpace(format: format, convertHDRToSDR: convertHDRToSDR, selected: selected)
        return output.extendedCaptureColorSpaceName
    }

    static func isHDR(_ image: CGImage) -> Bool {
        guard let colorSpace = image.colorSpace else { return false }
        if colorSpace.isHDR() { return true }
        if #available(macOS 15.0, *), image.contentHeadroom > 1 { return true }
        let name = (colorSpace.name as String? ?? "").lowercased()
        return name.contains("extended") && (image.bitsPerComponent >= 16 || image.bitmapInfo.contains(.floatComponents))
    }

    static func prepare(
        _ source: CGImage,
        scale: Double,
        colorSpace: OutputColorSpace,
        format: String,
        convertHDRToSDR: Bool,
        gamutMapping: GamutMappingMode = .clip
    ) throws -> CGImage {
        if isHDR(source) {
            if format == "PNG" && !convertHDRToSDR {
                return try preserveHDR(source, scale: scale)
            }
            return try mapHDRToSDR(source, scale: scale, colorSpace: colorSpace, gamutMapping: gamutMapping)
        }
        return try convert(source, scale: scale, colorSpace: colorSpace, gamutMapping: gamutMapping)
    }

    static func convert(
        _ source: CGImage,
        scale: Double,
        colorSpace: OutputColorSpace,
        gamutMapping: GamutMappingMode = .clip
    ) throws -> CGImage {
        guard let target = colorSpace.cgColorSpace else { throw ImagePipelineError.unavailableColorProfile }
        let width = max(1, Int(Double(source.width) * scale))
        let height = max(1, Int(Double(source.height) * scale))
        if gamutMapping == .perceptual,
           let compressed = try perceptualConvert(source, width: width, height: height,
                                                  sourceSpace: source.colorSpace, targetSpace: target) {
            return compressed
        }
        guard let context = CGContext(data: nil, width: width, height: height, bitsPerComponent: 8,
                                      bytesPerRow: 0, space: target,
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            throw ImagePipelineError.cannotCreateBitmap
        }
        context.interpolationQuality = .high
        // Gamut mapping is intentionally hard clipping: out-of-gamut source
        // channels must land on the target-space boundary (for example P3 red
        // becomes sRGB 255,0,0), rather than being perceptually compressed.
        context.setRenderingIntent(gamutMapping.renderingIntent)
        context.draw(source, in: CGRect(x: 0, y: 0, width: width, height: height))
        guard let result = context.makeImage(), result.colorSpace.map({ CFEqual($0.name, target.name) }) == true else {
            throw ImagePipelineError.cannotCreateBitmap
        }
        return result
    }

    private struct RGBModel {
        let toXYZ: (Double, Double, Double) -> (Double, Double, Double)
        let fromXYZ: (Double, Double, Double) -> (Double, Double, Double)
        let decode: (Double) -> Double
        let encode: (Double) -> Double
    }

    private static func perceptualConvert(
        _ source: CGImage,
        width: Int,
        height: Int,
        sourceSpace: CGColorSpace?,
        targetSpace: CGColorSpace
    ) throws -> CGImage? {
        guard let sourceSpace,
              let sourceICC = sourceSpace.copyICCData(),
              let targetICC = targetSpace.copyICCData(),
              let sourceProfile = ColorSyncProfileCreate(sourceICC, nil)?.takeUnretainedValue(),
              let targetProfile = ColorSyncProfileCreate(targetICC, nil)?.takeUnretainedValue(),
              let model = rgbModel(for: targetSpace) else {
            return nil
        }

        let profileKey = kColorSyncProfile!.takeUnretainedValue()
        let intentKey = kColorSyncRenderingIntent!.takeUnretainedValue()
        let tagKey = kColorSyncTransformTag!.takeUnretainedValue()
        let perceptual = kColorSyncRenderingIntentPerceptual!.takeUnretainedValue()
        let sourceTag = kColorSyncTransformDeviceToPCS!.takeUnretainedValue()
        let targetTag = kColorSyncTransformPCSToDevice!.takeUnretainedValue()
        let sequence: [[CFString: Any]] = [
            [profileKey: sourceProfile, intentKey: perceptual, tagKey: sourceTag],
            [profileKey: targetProfile, intentKey: perceptual, tagKey: targetTag]
        ]
        guard let transform = ColorSyncTransformCreate(sequence as CFArray, nil)?.takeUnretainedValue() else {
            return nil
        }

        var sourceBytes = [UInt8](repeating: 0, count: width * height * 4)
        guard let sourceContext = CGContext(data: &sourceBytes, width: width, height: height,
                                            bitsPerComponent: 8, bytesPerRow: width * 4,
                                            space: sourceSpace,
                                            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            return nil
        }
        sourceContext.interpolationQuality = .high
        sourceContext.draw(source, in: CGRect(x: 0, y: 0, width: width, height: height))

        var extended = [Float](repeating: 0, count: width * height * 4)
        let layout = ColorSyncDataLayout(kColorSyncAlphaPremultipliedLast.rawValue)
        let options: [CFString: Any] = [kColorSyncConvertUseExtendedRange!.takeUnretainedValue(): true]
        let converted = sourceBytes.withUnsafeBytes { sourceBuffer in
            extended.withUnsafeMutableBytes { destinationBuffer in
                ColorSyncTransformConvert(transform, width, height, destinationBuffer.baseAddress!,
                                           kColorSync32BitFloat, layout, width * 16,
                                           sourceBuffer.baseAddress!, kColorSync8BitInteger, layout,
                                           width * 4, options as CFDictionary)
            }
        }
        guard converted else {
            return nil
        }

        var output = [UInt8](repeating: 0, count: width * height * 4)
        for index in stride(from: 0, to: extended.count, by: 4) {
            let alpha = min(1, max(0, Double(extended[index + 3])))
            let rgb = alpha > 0
                ? (Double(extended[index]) / alpha, Double(extended[index + 1]) / alpha, Double(extended[index + 2]) / alpha)
                : (0, 0, 0)
            let mapped = compressToGamut(rgb, model: model)
            output[index] = quantize(mapped.0 * alpha)
            output[index + 1] = quantize(mapped.1 * alpha)
            output[index + 2] = quantize(mapped.2 * alpha)
            output[index + 3] = quantize(alpha)
        }
        let provider = CGDataProvider(data: Data(output) as CFData)
        return provider.flatMap {
            CGImage(width: width, height: height, bitsPerComponent: 8, bitsPerPixel: 32,
                    bytesPerRow: width * 4, space: targetSpace,
                    bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
                    provider: $0, decode: nil, shouldInterpolate: false, intent: .perceptual)
        }
    }

    private static func rgbModel(for colorSpace: CGColorSpace) -> RGBModel? {
        guard let name = colorSpace.name as String? else { return nil }
        let normalized = name.lowercased()
        let gamma: (Double) -> Double
        let inverseGamma: (Double) -> Double
        let matrix: [[Double]]
        let inverse: [[Double]]
        if normalized.contains("display p3") || normalized.contains("p3") {
            matrix = [
                [0.4865709486, 0.2656676932, 0.1982172852],
                [0.2289745641, 0.6917385218, 0.0792869141],
                [0.0000000000, 0.0451133819, 1.0439443689]
            ]
            inverse = [
                [2.4934969119, -0.9313836179, -0.4027107845],
                [-0.8294889696, 1.7626640603, 0.0236246858],
                [0.0358458302, -0.0761723893, 0.9568845240]
            ]
            gamma = srgbDecode
            inverseGamma = srgbEncode
        } else if normalized.contains("2020") {
            matrix = [
                [0.6369580483, 0.1446169036, 0.1688809752],
                [0.2627002120, 0.6779980715, 0.0593017165],
                [0.0000000000, 0.0280726930, 1.0609850577]
            ]
            inverse = [
                [1.7166511879, -0.3556707838, -0.2533662814],
                [-0.6666843518, 1.6164812366, 0.0157685458],
                [0.0176398574, -0.0427706133, 0.9421031212]
            ]
            gamma = rec2020Decode
            inverseGamma = rec2020Encode
        } else if normalized.contains("709") || normalized.contains("itur") {
            matrix = [
                [0.4123907993, 0.3575843394, 0.1804807884],
                [0.2126390059, 0.7151686788, 0.0721923154],
                [0.0193308187, 0.1191947798, 0.9505321522]
            ]
            inverse = [
                [3.2409699419, -1.5373831776, -0.4986107603],
                [-0.9692436363, 1.8759675015, 0.0415550574],
                [0.0556300797, -0.2039769589, 1.0569715142]
            ]
            gamma = rec709Decode
            inverseGamma = rec709Encode
        } else {
            matrix = [
                [0.4123907993, 0.3575843394, 0.1804807884],
                [0.2126390059, 0.7151686788, 0.0721923154],
                [0.0193308187, 0.1191947798, 0.9505321522]
            ]
            inverse = [
                [3.2409699419, -1.5373831776, -0.4986107603],
                [-0.9692436363, 1.8759675015, 0.0415550574],
                [0.0556300797, -0.2039769589, 1.0569715142]
            ]
            gamma = srgbDecode
            inverseGamma = srgbEncode
        }
        return RGBModel(
            toXYZ: { r, g, b in
                (matrix[0][0] * gamma(r) + matrix[0][1] * gamma(g) + matrix[0][2] * gamma(b),
                 matrix[1][0] * gamma(r) + matrix[1][1] * gamma(g) + matrix[1][2] * gamma(b),
                 matrix[2][0] * gamma(r) + matrix[2][1] * gamma(g) + matrix[2][2] * gamma(b))
            },
            fromXYZ: { x, y, z in
                (inverseGamma(inverse[0][0] * x + inverse[0][1] * y + inverse[0][2] * z),
                 inverseGamma(inverse[1][0] * x + inverse[1][1] * y + inverse[1][2] * z),
                 inverseGamma(inverse[2][0] * x + inverse[2][1] * y + inverse[2][2] * z))
            },
            decode: gamma,
            encode: inverseGamma
        )
    }

    private static func compressToGamut(_ rgb: (Double, Double, Double), model: RGBModel) -> (Double, Double, Double) {
        let values = [rgb.0, rgb.1, rgb.2]
        guard values.allSatisfy(\.isFinite) else {
            return (min(1, max(0, rgb.0)), min(1, max(0, rgb.1)), min(1, max(0, rgb.2)))
        }
        guard values.allSatisfy({ $0.isFinite && $0 >= 0 && $0 <= 1 }) else {
            let xyz = model.toXYZ(rgb.0, rgb.1, rgb.2)
            let white = (0.95047, 1.0, 1.08883)
            func labF(_ value: Double) -> Double {
                let epsilon = 216.0 / 24389.0
                let kappa = 24389.0 / 27.0
                return value > epsilon ? pow(value, 1.0 / 3.0) : (kappa * value + 16.0) / 116.0
            }
            func labInv(_ value: Double) -> Double {
                let epsilon = 216.0 / 24389.0
                let kappa = 24389.0 / 27.0
                let cube = value * value * value
                return cube > epsilon ? cube : (116.0 * value - 16.0) / kappa
            }
            let fx = labF(xyz.0 / white.0), fy = labF(xyz.1 / white.1), fz = labF(xyz.2 / white.2)
            let lightness = min(100, max(0, 116 * fy - 16))
            let a = 500 * (fx - fy), b = 200 * (fy - fz)
            let chroma = sqrt(a * a + b * b)
            guard chroma > 0.0001 else {
                return model.fromXYZ(white.0 * labInv((lightness + 16) / 116),
                                     white.1 * labInv((lightness + 16) / 116),
                                     white.2 * labInv((lightness + 16) / 116))
            }
            let hueA = a / chroma, hueB = b / chroma
            func candidate(_ factor: Double) -> (Double, Double, Double) {
                let candidateA = chroma * factor * hueA, candidateB = chroma * factor * hueB
                let fY = (lightness + 16) / 116
                let fX = fY + candidateA / 500
                let fZ = fY - candidateB / 200
                return model.fromXYZ(white.0 * labInv(fX), white.1 * labInv(fY), white.2 * labInv(fZ))
            }
            var low = 0.0
            var high = 1.0
            for _ in 0..<10 {
                let mid = (low + high) / 2
                let candidate = candidate(mid)
                if candidate.0.isFinite && candidate.1.isFinite && candidate.2.isFinite &&
                    candidate.0 >= 0 && candidate.0 <= 1 && candidate.1 >= 0 && candidate.1 <= 1 &&
                    candidate.2 >= 0 && candidate.2 <= 1 {
                    low = mid
                } else {
                    high = mid
                }
            }
            return candidate(low)
        }
        return rgb
    }

    private static func quantize(_ value: Double) -> UInt8 {
        UInt8(min(255, max(0, Int((value * 255).rounded()))))
    }

    private static func srgbDecode(_ value: Double) -> Double {
        value <= 0.04045 ? value / 12.92 : pow((value + 0.055) / 1.055, 2.4)
    }

    private static func srgbEncode(_ value: Double) -> Double {
        value <= 0.0031308 ? 12.92 * value : 1.055 * pow(value, 1 / 2.4) - 0.055
    }

    private static func rec709Decode(_ value: Double) -> Double {
        value <= 0.081 ? value / 4.5 : pow((value + 0.099) / 1.099, 1 / 0.45)
    }

    private static func rec709Encode(_ value: Double) -> Double {
        value <= 0.018 ? 4.5 * value : 1.099 * pow(value, 0.45) - 0.099
    }

    private static func rec2020Decode(_ value: Double) -> Double {
        value <= 0.0812428583 ? value / 4.5 : pow((value + 0.0992968268) / 1.0992968268, 1 / 0.45)
    }

    private static func rec2020Encode(_ value: Double) -> Double {
        value <= 0.0180539685 ? 4.5 * value : 1.0992968268 * pow(value, 0.45) - 0.0992968268
    }

    static func encode(_ image: CGImage, format: String, quality: Double, preserveHDR: Bool = false) throws -> Data {
        if format == "PNG" && preserveHDR {
            let pngImage = try makePNGCompatibleHDR(image)
            return try encodeWithImageIO(pngImage, type: UTType.png.identifier, quality: nil)
        }
        let isPNG = format == "PNG"
        return try encodeWithImageIO(
            image,
            type: isPNG ? UTType.png.identifier : UTType.jpeg.identifier,
            quality: isPNG ? nil : quality
        )
    }

    private static func encodeWithImageIO(_ image: CGImage, type: String, quality: Double?) throws -> Data {
        let output = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(output, type as CFString, 1, nil) else {
            throw ImagePipelineError.cannotEncode
        }
        var properties: [CFString: Any] = [:]
        if let quality {
            properties[kCGImageDestinationLossyCompressionQuality] = min(1, max(0, quality))
        }
        // ImageIO takes the profile from image.colorSpace and writes it into
        // the file. This keeps the pixel conversion and the embedded ICC
        // profile in lockstep for both PNG and JPEG.
        CGImageDestinationAddImage(destination, image, properties as CFDictionary)
        guard CGImageDestinationFinalize(destination) else { throw ImagePipelineError.cannotEncode }
        return output as Data
    }

    private static func preserveHDR(_ source: CGImage, scale: Double) throws -> CGImage {
        guard scale > 0 else { throw ImagePipelineError.cannotCreateBitmap }
        if scale == 1 { return source }
        guard let sourceSpace = source.colorSpace else { throw ImagePipelineError.unavailableColorProfile }
        let width = max(1, Int(Double(source.width) * scale))
        let height = max(1, Int(Double(source.height) * scale))
        var bitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue)
        if source.bitmapInfo.contains(.floatComponents) {
            bitmapInfo.formUnion(.floatComponents)
            if source.bitsPerComponent == 16 { bitmapInfo.formUnion(.byteOrder16Little) }
        }
        guard let context = CGContext(data: nil, width: width, height: height,
                                      bitsPerComponent: source.bitsPerComponent,
                                      bytesPerRow: 0, space: sourceSpace,
                                      bitmapInfo: bitmapInfo.rawValue) else {
            throw ImagePipelineError.cannotCreateBitmap
        }
        context.interpolationQuality = .high
        context.setRenderingIntent(.relativeColorimetric)
        context.draw(source, in: CGRect(x: 0, y: 0, width: width, height: height))
        guard let scaled = context.makeImage() else { throw ImagePipelineError.cannotCreateBitmap }
        if #available(macOS 15.0, *) {
            let headroom = source.contentHeadroom
            if headroom > 1, let tagged = CGImageCreateCopyWithContentHeadroom(headroom, scaled) {
                return tagged
            }
        }
        return scaled
    }

    private static func mapHDRToSDR(
        _ source: CGImage,
        scale: Double,
        colorSpace: OutputColorSpace,
        gamutMapping: GamutMappingMode
    ) throws -> CGImage {
        guard let target = colorSpace.cgColorSpace else { throw ImagePipelineError.unavailableColorProfile }
        let width = max(1, Int(Double(source.width) * scale))
        let height = max(1, Int(Double(source.height) * scale))
        guard let context = CGContext(data: nil, width: width, height: height, bitsPerComponent: 8,
                                      bytesPerRow: 0, space: target,
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            throw ImagePipelineError.cannotCreateBitmap
        }
        let rect = CGRect(x: 0, y: 0, width: width, height: height)
        if #available(macOS 15.0, *) {
            if let filter = CIFilter(name: "CIToneMapHeadroom") {
                filter.setValue(CIImage(cgImage: source), forKey: kCIInputImageKey)
                // ScreenCaptureKit's extended-linear CGImages do not always
                // carry contentHeadroom metadata. Estimate it from the actual
                // linear samples so HDR-to-SDR does not become a plain clip.
                filter.setValue(sourceHeadroom(source), forKey: "inputSourceHeadroom")
                filter.setValue(1.0, forKey: "inputTargetHeadroom")
                guard let sourceSpace = source.colorSpace,
                      let output = filter.outputImage,
                      let toneMapped = CIContext(options: [
                        .workingColorSpace: sourceSpace,
                        .outputColorSpace: sourceSpace
                      ]).createCGImage(output, from: output.extent, format: .RGBAh, colorSpace: sourceSpace) else {
                    throw ImagePipelineError.cannotCreateBitmap
                }
                // Apply the selected gamut intent after tone mapping. Keeping
                // the intermediate in the source space prevents Core Image's
                // default perceptual conversion from deciding the result.
                return try convert(toneMapped, scale: scale, colorSpace: colorSpace, gamutMapping: gamutMapping)
            }
        }
        context.interpolationQuality = .high
        context.setRenderingIntent(gamutMapping.renderingIntent)
        context.draw(source, in: rect)
        guard let result = context.makeImage(),
              result.colorSpace.map({ CFEqual($0.name, target.name) }) == true else {
            throw ImagePipelineError.cannotCreateBitmap
        }
        return result
    }

    /// Returns the ratio between the brightest linear sample and SDR white.
    /// Sampling is bounded to keep the HDR conversion responsive on 5K displays.
    private static func sourceHeadroom(_ source: CGImage) -> Double {
        var metadataHeadroom = 1.0
        if #available(macOS 15.0, *) {
            metadataHeadroom = Double(source.contentHeadroom)
        }
        if metadataHeadroom > 1 { return metadataHeadroom }
        guard source.colorSpace?.isHDR() == true ||
                (source.colorSpace?.name as String? ?? "").lowercased().contains("extended") else {
            return 1
        }
        let maxDimension = 512
        let sampleWidth = min(maxDimension, max(1, source.width))
        let sampleHeight = min(maxDimension, max(1, source.height))
        var values = [Float](repeating: 0, count: sampleWidth * sampleHeight * 4)
        let info = CGBitmapInfo.floatComponents
            .union(.byteOrder32Little)
            .union(CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue))
        let sampleSpace = CGColorSpace(name: CGColorSpace.extendedLinearSRGB)
            ?? CGColorSpace(name: CGColorSpace.linearSRGB)
        guard let sampleSpace,
              let context = CGContext(data: &values, width: sampleWidth, height: sampleHeight,
                                      bitsPerComponent: 32, bytesPerRow: sampleWidth * 16,
                                      space: sampleSpace, bitmapInfo: info.rawValue) else {
            return metadataHeadroom
        }
        context.interpolationQuality = .none
        context.draw(source, in: CGRect(x: 0, y: 0, width: sampleWidth, height: sampleHeight))
        var maximum: Float = 1
        for index in stride(from: 0, to: values.count, by: 4) {
            maximum = max(maximum, values[index], values[index + 1], values[index + 2])
        }
        return max(1, min(Double(maximum), 64))
    }

    private static func resizeSDR(_ image: CGImage, width: Int, height: Int, colorSpace: CGColorSpace) throws -> CGImage {
        if image.width == width && image.height == height { return image }
        guard let context = CGContext(data: nil, width: width, height: height, bitsPerComponent: 8,
                                      bytesPerRow: 0, space: colorSpace,
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            throw ImagePipelineError.cannotCreateBitmap
        }
        context.interpolationQuality = .high
        context.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
        guard let result = context.makeImage() else { throw ImagePipelineError.cannotCreateBitmap }
        return result
    }

    private static func makePNGCompatibleHDR(_ source: CGImage) throws -> CGImage {
        guard let sourceSpace = source.colorSpace else { throw ImagePipelineError.unavailableColorProfile }
        let sourceName = (sourceSpace.name as String? ?? "").lowercased()
        guard sourceName.contains("extended") else { return source }
        guard let pqSpace = CGColorSpace(name: CGColorSpace.itur_2100_PQ),
              let context = CGContext(data: nil, width: source.width, height: source.height,
                                      bitsPerComponent: 16, bytesPerRow: 0, space: pqSpace,
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            throw ImagePipelineError.cannotCreateBitmap
        }
        context.draw(source, in: CGRect(x: 0, y: 0, width: source.width, height: source.height))
        guard let converted = context.makeImage() else { throw ImagePipelineError.cannotCreateBitmap }
        if #available(macOS 15.0, *) {
            let headroom = source.contentHeadroom
            if headroom > 1, let tagged = CGImageCreateCopyWithContentHeadroom(headroom, converted) {
                return tagged
            }
        }
        return converted
    }
}
