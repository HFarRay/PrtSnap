import IOKit.hidsystem

@main
struct PermissionStatusProbe {
    static func main() {
        precondition(PermissionStatusMapping.isInputMonitoringGranted(kIOHIDAccessTypeGranted))
        precondition(!PermissionStatusMapping.isInputMonitoringGranted(kIOHIDAccessTypeDenied))
        precondition(!PermissionStatusMapping.isInputMonitoringGranted(kIOHIDAccessTypeUnknown))
        print("Permission status probe passed: granted is enabled; denied and unknown are disabled")
    }
}
