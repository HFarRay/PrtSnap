import Foundation

@main
struct EditorUndoHistoryProbe {
    static func main() {
        var history = EditorUndoHistory<[Int]>(limit: 100)
        var state: [Int] = []
        for value in 1...125 {
            history.record(before: state)
            state.append(value)
        }
        guard history.undoStack.count == 100 else { fatalError("Undo history was not capped at 100") }
        for _ in 0..<100 {
            guard let prior = history.undo(current: state) else { fatalError("Undo ended early") }
            state = prior
        }
        guard state == Array(1...25), history.undoStack.isEmpty else { fatalError("Undo did not preserve the latest 100 operations") }
        for _ in 0..<100 {
            guard let next = history.redo(current: state) else { fatalError("Redo ended early") }
            state = next
        }
        guard state == Array(1...125), history.redoStack.isEmpty else { fatalError("Redo did not restore state") }
        history.record(before: state)
        state.append(126)
        guard history.redoStack.isEmpty else { fatalError("New edits must clear redo") }
        print("Editor undo history probe passed: 100-step cap, undo, redo, and redo invalidation")
    }
}
