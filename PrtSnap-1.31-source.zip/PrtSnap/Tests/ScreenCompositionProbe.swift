import AppKit
import CoreGraphics
import Foundation

@main
struct ScreenCompositionProbe {
    private static func solidImage(width: Int, height: Int, color: CGColor) -> CGImage {
        let colorSpace = CGColorSpace(name: CGColorSpace.sRGB)!
        let context = CGContext(data: nil, width: width, height: height, bitsPerComponent: 8,
                                bytesPerRow: 0, space: colorSpace,
                                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
        context.setFillColor(color)
        context.fill(CGRect(x: 0, y: 0, width: width, height: height))
        return context.makeImage()!
    }

    private static func extendedHighlightImage() -> CGImage {
        let values: [UInt16] = [0x4000, 0x0000, 0x0000, 0x3c00]
        let data = values.withUnsafeBytes { Data($0) }
        let provider = CGDataProvider(data: data as CFData)!
        let colorSpace = CGColorSpace(name: CGColorSpace.extendedLinearITUR_2020)!
        let bitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.last.rawValue)
            .union(.floatComponents)
            .union(.byteOrder16Little)
        return CGImage(width: 1, height: 1, bitsPerComponent: 16, bitsPerPixel: 64,
                       bytesPerRow: 8, space: colorSpace, bitmapInfo: bitmapInfo,
                       provider: provider, decode: nil, shouldInterpolate: false,
                       intent: .defaultIntent)!
    }

    private static func firstPixelLinear(_ image: CGImage, in colorSpace: CGColorSpace) -> [Float] {
        var values = [Float](repeating: 0, count: 4)
        values.withUnsafeMutableBytes { buffer in
            let bitmapInfo = CGBitmapInfo.floatComponents.union(.byteOrder32Little)
                .union(CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue))
            let context = CGContext(data: buffer.baseAddress, width: 1, height: 1,
                                    bitsPerComponent: 32, bytesPerRow: 16,
                                    space: colorSpace, bitmapInfo: bitmapInfo.rawValue)!
            context.draw(image, in: CGRect(x: 0, y: 0, width: 1, height: 1))
        }
        return values
    }

    static func main() throws {
        let leftUpper = ScreenCompositionSource(
            frame: CGRect(x: -2, y: 1, width: 2, height: 1),
            image: solidImage(width: 4, height: 2, color: CGColor(red: 1, green: 0, blue: 0, alpha: 1))
        )
        let primary = ScreenCompositionSource(
            frame: CGRect(x: 0, y: 0, width: 2, height: 2),
            image: solidImage(width: 4, height: 4, color: CGColor(red: 0, green: 0, blue: 1, alpha: 1))
        )
        let layout = try ScreenComposition.layout(for: [leftUpper, primary])
        guard layout.canvasSize == CGSize(width: 8, height: 4), layout.pixelScale == 2 else {
            fatalError("Canvas bounds or shared pixel scale were incorrect: \(layout.canvasSize), \(layout.pixelScale)")
        }

        let left = layout.placements[0]
        let right = layout.placements[1]
        guard left.frame.origin == CGPoint(x: 0, y: 2),
              right.frame.origin == CGPoint(x: 4, y: 0) else {
            fatalError("Display arrangement did not retain negative origins and relative placement")
        }
        let displayFrames = [leftUpper.frame, primary.frame]
        guard ScreenComposition.cursorScreenIndex(at: CGPoint(x: -1, y: 1.5), frames: displayFrames) == 0,
              ScreenComposition.cursorScreenIndex(at: CGPoint(x: 1, y: 1), frames: displayFrames) == 1 else {
            fatalError("Cursor position did not select the display containing it")
        }
        let separatedFrames = [
            CGRect(x: 0, y: 0, width: 10, height: 10),
            CGRect(x: 20, y: 0, width: 10, height: 10)
        ]
        guard ScreenComposition.cursorScreenIndex(at: CGPoint(x: 12, y: 5), frames: separatedFrames) == 0,
              ScreenComposition.cursorScreenIndex(at: CGPoint(x: 18, y: 5), frames: separatedFrames) == 1,
              ScreenComposition.cursorScreenIndex(at: .zero, frames: []) == nil else {
            fatalError("Cursor gaps did not fall back to the nearest display")
        }
        print("PASS cursor display selection handles screen hits, gaps, and empty layouts")

        for (source, placement) in zip([leftUpper, primary], layout.placements) {
            let sourceAspect = CGFloat(source.image.width) / CGFloat(source.image.height)
            let outputAspect = placement.imageRect.width / placement.imageRect.height
            guard abs(sourceAspect - outputAspect) < 0.0001 else {
                fatalError("A display image was stretched: source \(sourceAspect), output \(outputAspect)")
            }
        }

        let composed = try ScreenComposition.compose([leftUpper, primary])
        guard composed.width == 8, composed.height == 4 else {
            fatalError("Composed canvas dimensions did not match its layout")
        }
        print("PASS multi-display layout preserves negative offsets, monitor arrangement, and image aspect ratios")

        let highlight = ScreenCompositionSource(
            frame: CGRect(x: 0, y: 0, width: 1, height: 1),
            image: extendedHighlightImage()
        )
        let hdrCanvas = try ScreenComposition.compose([highlight])
        let hdrSpace = CGColorSpace(name: CGColorSpace.extendedLinearITUR_2020)!
        let linearPixel = firstPixelLinear(hdrCanvas, in: hdrSpace)
        guard hdrCanvas.bitsPerComponent >= 16,
              hdrCanvas.bitmapInfo.contains(.floatComponents),
              linearPixel[0] > 1.8 else {
            fatalError("Multi-display composition clipped extended-linear HDR highlights: \(linearPixel)")
        }
        print("PASS multi-display composition retains extended-linear HDR precision and highlights")
    }
}
