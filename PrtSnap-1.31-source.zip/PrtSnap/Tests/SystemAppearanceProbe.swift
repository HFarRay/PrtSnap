import SwiftUI

@main
struct SystemAppearanceProbe {
    static func main() {
        guard SystemAppearanceResolver.fromInterfaceStyle("Dark") == .dark,
              SystemAppearanceResolver.fromInterfaceStyle("dark") == .dark,
              SystemAppearanceResolver.fromInterfaceStyle("Light") == .light,
              SystemAppearanceResolver.fromInterfaceStyle("") == .light else {
            fatalError("System interface style did not resolve to the expected icon appearance")
        }
        print("System appearance probe passed: dark/light selection is case-insensitive and defaults to light")
    }
}
