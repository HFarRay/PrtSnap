import Foundation

@main
struct AppUpdaterProbe {
    static func main() throws {
        guard let path = CommandLine.arguments.dropFirst().first else {
            fatalError("Pass a PrtSnap DMG path")
        }
        let update = try AppUpdater.prepareUpdate(from: URL(fileURLWithPath: path))
        defer { AppUpdater.discard(update) }
        let expectedVersion = CommandLine.arguments.dropFirst(2).first ?? ""
        guard update.displayVersion == expectedVersion else {
            fatalError("Unexpected update version: \(update.displayVersion)")
        }
        print("DMG update probe passed: \(update.displayVersion), staged app signature verified")
    }
}
