import Foundation

@main
struct ShortcutModelProbe {
    static func main() throws {
        let legacy = Data(#"{"keyCode":20,"modifiers":4608}"#.utf8)
        let migrated = try JSONDecoder().decode(Shortcut.self, from: legacy)
        guard migrated.keyCodes == [59, 56, 20], migrated.label == "⌃ + ⇧ + 3" else {
            fatalError("Legacy shortcut migration failed: \(migrated)")
        }

        let manyKeys = Shortcut(keyCodes: [59, 58, 56, 55, 20, 5])
        guard manyKeys.keys.count == 6, manyKeys.label == "⌃ + ⌥ + ⇧ + ⌘ + 3 + G" else {
            fatalError("Multi-key shortcut formatting failed: \(manyKeys.label)")
        }

        let roundTrip = try JSONDecoder().decode(Shortcut.self, from: JSONEncoder().encode(manyKeys))
        guard roundTrip == manyKeys else {
            fatalError("Shortcut persistence round trip failed")
        }

        guard KeyNames.name(for: 5) == "G", !KeyNames.name(for: 5).hasPrefix("Key ") else {
            fatalError("The actual key name is not displayed")
        }
        guard KeyNames.displayValue(for: 55, characters: nil) == "⌘",
              KeyNames.displayValue(for: 54, characters: nil) == "⌘",
              KeyNames.displayValue(for: 58, characters: nil) == "⌥",
              KeyNames.displayValue(for: 61, characters: nil) == "⌥",
              KeyNames.displayValue(for: 200, characters: "、") == "、" else {
            fatalError("Modifier or punctuation key labels were not preserved")
        }
        guard KeyNames.canonicalKeyCode(54) == 55,
              KeyNames.canonicalKeyCode(61) == 58,
              KeyNames.canonicalKeyCode(60) == 56,
              KeyNames.canonicalKeyCode(62) == 59 else {
            fatalError("Left and right modifier keys did not normalize consistently")
        }
        guard KeyNames.recordedKeyCode(eventKeyCode: 61, isModifierEvent: true, modifiers: []) == 61,
              KeyNames.recordedKeyCode(eventKeyCode: 0, isModifierEvent: false, modifiers: .command) == 55,
              KeyNames.recordedKeyCode(eventKeyCode: 0, isModifierEvent: false, modifiers: .option) == 58 else {
            fatalError("Modifier event capture or chord fallback failed")
        }
        for keyCode: UInt32 in [55, 56, 58, 59] {
            let singleModifier = Shortcut(keyCodes: [keyCode])
            guard singleModifier.isComplete,
                  singleModifier.keyCodes == [keyCode],
                  singleModifier.label == KeyNames.name(for: keyCode) else {
                fatalError("A modifier could not be represented as a standalone shortcut key")
            }
        }
        print("Shortcut model probe passed: migration, six keys, persistence, modifier labels and capture, punctuation, and side normalization")
    }
}
