import Foundation

@main
struct HistoryRetentionProbe {
    static func main() {
        let labels = HistoryRetention.allCases.map(\.rawValue)
        let expected = [
            "1 小时后自动删除",
            "1 天后自动删除",
            "7 天后自动删除",
            "30 天后自动删除",
            "365 天后自动删除",
            "永不删除"
        ]
        guard labels == expected else {
            fatalError("History retention options are not using the expected numeric labels: \(labels)")
        }

        let legacyValues = [
            "一小时后自动删除": "1 小时后自动删除",
            "一天后自动删除": "1 天后自动删除",
            "七天后自动删除": "7 天后自动删除",
            "三十天后自动删除": "30 天后自动删除",
            "365天后自动删除": "365 天后自动删除"
        ]
        for (legacy, current) in legacyValues where HistoryRetention.migratedRawValue(legacy) != current {
            fatalError("Legacy retention value was not migrated: \(legacy)")
        }

        let createdAt = Date(timeIntervalSince1970: 1_800_000_000)
        let existingImage = HistoryRetentionRecord(retention: .oneYear, createdAt: createdAt)
        let settingChangedAt = createdAt.addingTimeInterval(60 * 60)
        let futureImage = HistoryRetentionRecord(retention: .oneHour, createdAt: settingChangedAt)
        guard !existingImage.isExpired(at: settingChangedAt.addingTimeInterval(2 * 24 * 60 * 60)),
              futureImage.isExpired(at: settingChangedAt.addingTimeInterval(60 * 60 + 1)),
              !HistoryRetentionRecord(retention: .never, createdAt: createdAt).isExpired(at: .distantFuture) else {
            fatalError("A new retention setting changed the expiry of an existing screenshot")
        }
        guard let encoded = try? JSONEncoder().encode(existingImage),
              let decoded = try? JSONDecoder().decode(HistoryRetentionRecord.self, from: encoded),
              decoded == existingImage else {
            fatalError("Per-image retention metadata did not round-trip")
        }
        print("History retention probe passed: labels, migration, and per-image expiry snapshots")
    }
}
