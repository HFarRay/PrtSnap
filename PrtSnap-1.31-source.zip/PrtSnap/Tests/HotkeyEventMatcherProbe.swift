import AppKit

private final class CaptureRecorder: @unchecked Sendable {
    private let lock = NSLock()
    private var kinds: [CaptureKind] = []

    func append(_ kind: CaptureKind) {
        lock.lock()
        kinds.append(kind)
        lock.unlock()
    }

    var values: [CaptureKind] {
        lock.lock()
        defer { lock.unlock() }
        return kinds
    }
}

@main
struct HotkeyEventMatcherProbe {
    static func main() {
        let source = CGEventSource(stateID: .hidSystemState)!
        let recorder = CaptureRecorder()
        let matcher = HotkeyEventMatcher(onCapture: recorder.append)
        matcher.setBindings([HotkeyBinding(kind: .screen, keyCodes: [58, 44])])

        let optionDown = event(source, keyCode: 58, type: .flagsChanged, flags: .maskAlternate)
        guard matcher.handle(.flagsChanged, event: optionDown) != nil else {
            fatalError("A modifier-only prefix was swallowed before the shortcut matched")
        }
        let slashDown = event(source, keyCode: 44, type: .keyDown, flags: .maskAlternate)
        guard matcher.handle(.keyDown, event: slashDown) == nil else {
            fatalError("The matching shortcut event was not consumed")
        }
        guard recorder.values == [.screen] else { fatalError("The capture action did not fire exactly once") }

        let slashUp = event(source, keyCode: 44, type: .keyUp, flags: .maskAlternate)
        guard matcher.handle(.keyUp, event: slashUp) == nil else { fatalError("The shortcut key-up event leaked") }
        let optionUp = event(source, keyCode: 58, type: .flagsChanged, flags: [])
        guard matcher.handle(.flagsChanged, event: optionUp) == nil else { fatalError("The modifier release event leaked") }

        let normalKey = event(source, keyCode: 0, type: .keyDown, flags: [])
        guard matcher.handle(.keyDown, event: normalKey) != nil else { fatalError("An unrelated key was swallowed") }
        print("Hotkey event probe passed: Option+/ triggers capture and consumes the matched events only")
    }

    private static func event(_ source: CGEventSource, keyCode: UInt16, type: CGEventType, flags: CGEventFlags) -> CGEvent {
        let event = CGEvent(keyboardEventSource: source, virtualKey: keyCode, keyDown: type != .keyUp)!
        event.type = type
        event.flags = flags
        return event
    }
}
