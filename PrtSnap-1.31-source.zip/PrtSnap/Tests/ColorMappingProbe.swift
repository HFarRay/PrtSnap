import AppKit
import CoreGraphics
import ImageIO

@main
struct ColorMappingProbe {
    static func rgba(_ image: CGImage) -> [UInt8] {
        var bytes = [UInt8](repeating: 0, count: image.width * image.height * 4)
        let target = CGColorSpace(name: CGColorSpace.sRGB)!
        bytes.withUnsafeMutableBytes { buffer in
            guard let context = CGContext(data: buffer.baseAddress, width: image.width, height: image.height,
                                          bitsPerComponent: 8, bytesPerRow: image.width * 4, space: target,
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
                fatalError("Could not create pixel inspection context")
            }
            context.setRenderingIntent(.perceptual)
            context.draw(image, in: CGRect(x: 0, y: 0, width: image.width, height: image.height))
        }
        return bytes
    }

    static func nativeRGBA(_ image: CGImage) -> [UInt8] {
        var bytes = [UInt8](repeating: 0, count: image.width * image.height * 4)
        bytes.withUnsafeMutableBytes { buffer in
            guard let space = image.colorSpace,
                  let context = CGContext(data: buffer.baseAddress, width: image.width, height: image.height,
                                          bitsPerComponent: 8, bytesPerRow: image.width * 4, space: space,
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
                fatalError("Could not create native pixel inspection context")
            }
            context.setRenderingIntent(.relativeColorimetric)
            context.draw(image, in: CGRect(x: 0, y: 0, width: image.width, height: image.height))
        }
        return bytes
    }

    static func firstPixelLinear(_ image: CGImage, in target: CGColorSpace) -> [Float] {
        var values = [Float](repeating: 0, count: 4)
        values.withUnsafeMutableBytes { buffer in
            guard let context = CGContext(data: buffer.baseAddress, width: 1, height: 1,
                                          bitsPerComponent: 32, bytesPerRow: 16, space: target,
                                          bitmapInfo: CGBitmapInfo.floatComponents.union(.byteOrder32Little)
                                            .union(CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue)).rawValue) else {
                fatalError("Could not inspect HDR pixel")
            }
            context.draw(image, in: CGRect(x: 0, y: 0, width: 1, height: 1))
        }
        return values
    }

    static func main() throws {
        guard OutputColorSpace.sRGB.displayName == "sRGB Gamma 2.4",
              OutputColorSpace.rec709.displayName == "Rec.709 Gamma 2.2" else {
            fatalError("sRGB and Rec.709 gamma labels are missing or incorrect")
        }
        guard ImagePipeline.outputColorSpace(format: "PNG", convertHDRToSDR: false, selected: .sRGB) == .rec2020,
              ImagePipeline.outputColorSpace(format: "PNG", convertHDRToSDR: true, selected: .rec709) == .rec709,
              ImagePipeline.outputColorSpace(format: "JPEG", convertHDRToSDR: false, selected: .displayP3) == .displayP3 else {
            fatalError("Output color space selection did not follow HDR preservation mode")
        }
        print("PASS PNG HDR-preserve mode defaults to Rec.2020; SDR/JPEG use the selected profile")

        let captureSpaces: [(String, Bool, OutputColorSpace, CFString)] = [
            ("PNG", false, .sRGB, CGColorSpace.extendedLinearITUR_2020),
            ("PNG", true, .displayP3, CGColorSpace.extendedLinearDisplayP3),
            ("JPEG", false, .rec2020, CGColorSpace.extendedLinearITUR_2020),
            ("JPEG", true, .rec709, CGColorSpace.extendedLinearSRGB)
        ]
        for (format, toneMap, selected, expected) in captureSpaces {
            let actual = ImagePipeline.captureColorSpaceName(
                format: format, convertHDRToSDR: toneMap, selected: selected
            )
            guard CFEqual(actual, expected) else {
                fatalError("Capture source did not use the selected wide-gamut container for \(selected.rawValue)")
            }
        }
        guard OutputColorSpace.displayP3.displayName == "Display P3 Gamma 2.4",
              OutputColorSpace.rec2020.displayName == "Rec.2020 Gamma 2.4" else {
            fatalError("Wide-gamut gamma labels are missing")
        }
        print("PASS ScreenCaptureKit source spaces follow selected primaries without clipping")

        let sourceSpace = CGColorSpace(name: CGColorSpace.displayP3)!
        let pixels: [UInt8] = [255, 0, 0, 255, 0, 255, 0, 255, 0, 0, 255, 255, 255, 255, 255, 255,
                               128, 24, 210, 255, 240, 180, 20, 255, 20, 180, 240, 255, 80, 80, 80, 255]
        let data = Data(pixels)
        let provider = CGDataProvider(data: data as CFData)!
        let input = CGImage(width: 4, height: 2, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: 16,
                            space: sourceSpace, bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.last.rawValue),
                            provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent)!

        for outputSpace in OutputColorSpace.allCases {
            let converted = try ImagePipeline.convert(input, scale: 0.5, colorSpace: outputSpace)
            precondition(converted.width == 2 && converted.height == 1, "Output scale was not applied")
            guard let actualName = converted.colorSpace?.name,
                  let expectedName = outputSpace.cgColorSpace?.name,
                  CFEqual(actualName, expectedName) else {
                fatalError("Converted bitmap does not carry the selected output profile: \(outputSpace.rawValue)")
            }

            for format in ["PNG", "JPEG"] {
                let encoded = try ImagePipeline.encode(converted, format: format, quality: 0.85)
                guard let source = CGImageSourceCreateWithData(encoded as CFData, nil),
                      let decoded = CGImageSourceCreateImageAtIndex(source, 0, nil),
                      let decodedName = decoded.colorSpace?.name,
                      CFEqual(decodedName, expectedName) else {
                    fatalError("\(format) did not preserve the \(outputSpace.rawValue) profile")
                }
            }
            print("PASS \(outputSpace.rawValue): scaled pixels and PNG/JPEG profiles verified")
        }

        let clipped = try ImagePipeline.convert(input, scale: 1, colorSpace: .sRGB, gamutMapping: .clip)
        let clippedPixels = nativeRGBA(clipped)
        guard Array(clippedPixels[0..<4]) == [255, 0, 0, 255] else {
            FileHandle.standardError.write(Data("P3->sRGB clipped pixels: \(clippedPixels)\n".utf8))
            fatalError("Hard gamut clipping did not clamp P3 red to sRGB 255,0,0")
        }
        let perceptual = try ImagePipeline.convert(input, scale: 1, colorSpace: .sRGB, gamutMapping: .perceptual)
        guard nativeRGBA(perceptual) != clippedPixels else {
            FileHandle.standardError.write(Data("clip=\(clippedPixels)\\nperceptual=\(nativeRGBA(perceptual))\\n".utf8))
            fatalError("Perceptual and hard-clip gamut mapping modes produced identical pixels")
        }
        print("PASS hard clipping clamps P3 red to sRGB 255; perceptual mode remains selectable")

        let hdrSpace = CGColorSpace(name: CGColorSpace.itur_2100_PQ)!
        let hdrValues: [UInt16] = [56_000, 32_000, 12_000, 65_535, 40_000, 20_000, 8_000, 65_535]
        let hdrData = hdrValues.withUnsafeBytes { Data($0) }
        let hdrProvider = CGDataProvider(data: hdrData as CFData)!
        let hdrImage = CGImage(width: 2, height: 1, bitsPerComponent: 16, bitsPerPixel: 64,
                               bytesPerRow: 16, space: hdrSpace,
                               bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.last.rawValue),
                               provider: hdrProvider, decode: nil, shouldInterpolate: false,
                               intent: .defaultIntent)!
        guard ImagePipeline.isHDR(hdrImage) else { fatalError("PQ image was not detected as HDR") }

        let preserved = try ImagePipeline.prepare(hdrImage, scale: 1, colorSpace: .sRGB,
                                                  format: "PNG", convertHDRToSDR: false)
        guard ImagePipeline.isHDR(preserved),
              let preservedName = preserved.colorSpace?.name,
              CFEqual(preservedName, hdrSpace.name) else {
            fatalError("PNG preserve mode did not retain the HDR profile")
        }
        let scaledHDR = try ImagePipeline.prepare(hdrImage, scale: 0.5, colorSpace: .sRGB,
                                                  format: "PNG", convertHDRToSDR: false)
        guard scaledHDR.width == 1, scaledHDR.height == 1,
              ImagePipeline.isHDR(scaledHDR), scaledHDR.bitsPerComponent >= 16 else {
            fatalError("Scaled HDR PNG did not retain HDR precision")
        }
        let hdrPNG = try ImagePipeline.encode(preserved, format: "PNG", quality: 1, preserveHDR: true)
        guard let hdrSource = CGImageSourceCreateWithData(hdrPNG as CFData, nil),
              let decodedHDR = CGImageSourceCreateImageAtIndex(hdrSource, 0, nil),
              ImagePipeline.isHDR(decodedHDR), decodedHDR.bitsPerComponent >= 16 else {
            fatalError("Lossless PNG did not retain HDR profile and precision")
        }
        print("PASS lossless PNG preserves the HDR profile and 16-bit precision")

        let toneMapped = try ImagePipeline.prepare(hdrImage, scale: 1, colorSpace: .sRGB,
                                                   format: "PNG", convertHDRToSDR: true)
        guard !ImagePipeline.isHDR(toneMapped), toneMapped.bitsPerComponent == 8,
              let mappedName = toneMapped.colorSpace?.name,
              CFEqual(mappedName, CGColorSpace.sRGB) else {
            fatalError("HDR-to-SDR setting did not produce the selected SDR output")
        }
        let naiveSDR = try ImagePipeline.convert(hdrImage, scale: 1, colorSpace: .sRGB)
        guard rgba(toneMapped) != rgba(naiveSDR) else {
            fatalError("HDR-to-SDR conversion did not apply a tone map")
        }
        let jpeg = try ImagePipeline.prepare(hdrImage, scale: 1, colorSpace: .sRGB,
                                             format: "JPEG", convertHDRToSDR: false)
        guard !ImagePipeline.isHDR(jpeg) else { fatalError("JPEG output retained HDR despite its SDR-only path") }
        print("PASS HDR-to-SDR maps PNG to the selected SDR space; JPEG is always SDR")

        let extendedSpace = CGColorSpace(name: CGColorSpace.extendedLinearSRGB)!
        let extendedValues: [UInt16] = [0x4000, 0x3800, 0x3C00, 0x3C00]
        let extendedData = extendedValues.withUnsafeBytes { Data($0) }
        let extendedProvider = CGDataProvider(data: extendedData as CFData)!
        let extendedImage = CGImage(width: 1, height: 1, bitsPerComponent: 16, bitsPerPixel: 64,
                                    bytesPerRow: 8, space: extendedSpace,
                                    bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.last.rawValue)
                                        .union(.floatComponents).union(.byteOrder16Little),
                                    provider: extendedProvider, decode: nil, shouldInterpolate: false,
                                    intent: .defaultIntent)!
        guard ImagePipeline.isHDR(extendedImage) else { fatalError("Extended linear screenshot was not detected as HDR") }
        let extendedPNG = try ImagePipeline.encode(extendedImage, format: "PNG", quality: 1, preserveHDR: true)
        guard let extendedSource = CGImageSourceCreateWithData(extendedPNG as CFData, nil),
              let decodedExtended = CGImageSourceCreateImageAtIndex(extendedSource, 0, nil) else {
            fatalError("Could not decode extended-range PNG")
        }
        let decodedLinear = firstPixelLinear(decodedExtended, in: extendedSpace)
        guard ImagePipeline.isHDR(decodedExtended), decodedExtended.bitsPerComponent >= 16,
              decodedLinear[0] > 1.8 else {
            fatalError("PNG encoding clipped extended HDR values: \(decodedLinear)")
        }
        print("PASS extended-linear PNG retains HDR values above SDR white via 16-bit PQ")

        // Some ScreenCaptureKit HDR screenshots use extended-linear pixels but
        // omit contentHeadroom metadata. The mapper must still detect the >1.0
        // samples and compress them when SDR output is requested.
        let extendedToneMapped = try ImagePipeline.prepare(
            extendedImage, scale: 1, colorSpace: .sRGB, format: "PNG", convertHDRToSDR: true
        )
        guard !ImagePipeline.isHDR(extendedToneMapped),
              extendedToneMapped.bitsPerComponent == 8,
              let mappedSpace = extendedToneMapped.colorSpace?.name,
              CFEqual(mappedSpace, CGColorSpace.sRGB) else {
            fatalError("Extended-linear HDR without metadata was not tone-mapped to sRGB")
        }
        print("PASS extended-linear HDR without metadata is tone-mapped to SDR")
    }
}
