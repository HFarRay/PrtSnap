#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
source "$ROOT/toolchain-env.sh"
WORK="$(cd "$ROOT/../../work" && pwd)"
SDK="${MACOS_SDKROOT:-/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk}"
mkdir -p "$WORK/PrtSnap-build"
"$SWIFTC" -parse-as-library -swift-version 6 -O -sdk "$SDK" \
  -target arm64-apple-macosx14.0 -module-cache-path "$WORK/PrtSnap-build/module-cache-v2" \
  "$ROOT/Sources/PrtSnap/EditorUndoHistory.swift" "$ROOT/Tests/EditorUndoHistoryProbe.swift" \
  -o "$WORK/PrtSnap-build/EditorUndoHistoryProbe"
"$WORK/PrtSnap-build/EditorUndoHistoryProbe"
