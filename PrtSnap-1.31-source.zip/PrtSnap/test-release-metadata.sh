#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PLIST="$ROOT/Resources/Info.plist"
DISPLAY_VERSION="$(/usr/libexec/PlistBuddy -c 'Print :PrtSnapDisplayVersion' "$PLIST")"
SHORT_VERSION="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$PLIST")"
BUILD_VERSION="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$PLIST")"

[[ "$DISPLAY_VERSION" == "1.31" ]]
[[ "$SHORT_VERSION" == "1.31" ]]
[[ "$BUILD_VERSION" == "1.31" ]]
grep -qF '## 1.31 - ' "$ROOT/CHANGELOG.md"
grep -qF '("1.31", "多显示器全屏截图范围"' "$ROOT/Sources/PrtSnap/main.swift"
grep -qF '截图设置新增全屏截图范围，可选择截取全部屏幕或只截取光标所在的屏幕。' "$ROOT/CHANGELOG.md"
grep -qF '## 1.3 - ' "$ROOT/CHANGELOG.md"
grep -qF '("1.2", "PrtSnap 正式发布"' "$ROOT/Sources/PrtSnap/main.swift"
grep -qF '修复多显示器全屏截图仅捕获主显示器' "$ROOT/CHANGELOG.md"
grep -qF '("1.1.4514beta3.2", "界面排版优化"' "$ROOT/Sources/PrtSnap/main.swift"
grep -qF '"超出目标色域处理" = "Out-of-Gamut Handling";' "$ROOT/Resources/en.lproj/Localizable.strings"
grep -qF '"超出色域直接裁切" = "Clip Out-of-Gamut Colors";' "$ROOT/Resources/en.lproj/Localizable.strings"
grep -qF '"感知式压缩" = "Perceptual Compression";' "$ROOT/Resources/en.lproj/Localizable.strings"
if grep -Eq 'V[0-9]+\.[0-9]+' "$PLIST" "$ROOT/CHANGELOG.md" "$ROOT/Sources/PrtSnap/main.swift"; then
  printf 'Version labels must not use a V prefix.\n' >&2
  exit 1
fi

printf 'Release metadata probe passed: display %s; bundle %s; build %s\n' \
  "$DISPLAY_VERSION" "$SHORT_VERSION" "$BUILD_VERSION"
