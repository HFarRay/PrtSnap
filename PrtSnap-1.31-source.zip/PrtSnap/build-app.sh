#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
source "$ROOT/toolchain-env.sh"
SDK="${MACOS_SDKROOT:-/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk}"
WORK="$(cd "$ROOT/../../work" && pwd)"
APP="${PRTSNAP_APP_OUTPUT:-$WORK/PrtSnap-build/PrtSnap.app}"
mkdir -p "$WORK/PrtSnap-build" "$APP/Contents/MacOS" "$APP/Contents/Resources"
"$SWIFTC" -parse-as-library -swift-version 6 -O -sdk "$SDK" -target arm64-apple-macosx14.0 \
  -module-cache-path "$WORK/PrtSnap-build/module-cache-v2" Sources/PrtSnap/*.swift -o "$WORK/PrtSnap-build/PrtSnap"
cp "$WORK/PrtSnap-build/PrtSnap" "$APP/Contents/MacOS/PrtSnap"
cp Resources/Info.plist "$APP/Contents/Info.plist"
cp Resources/PkgInfo "$APP/Contents/PkgInfo"
cp Resources/IMG_6133.JPG "$APP/Contents/Resources/IMG_6133.JPG"
cp Resources/IMG_6134.JPG "$APP/Contents/Resources/IMG_6134.JPG"
cp Resources/AboutEasterEgg.jpg "$APP/Contents/Resources/AboutEasterEgg.jpg"
if [[ -d Resources/en.lproj ]]; then
  cp -R Resources/en.lproj "$APP/Contents/Resources/en.lproj"
fi
if [[ -f Resources/AppIcon.icns ]]; then
  cp Resources/AppIcon.icns "$APP/Contents/Resources/AppIcon.icns"
fi
for icon in AppIcon-Light.icns AppIcon-Dark.icns; do
  if [[ -f "Resources/$icon" ]]; then
    cp "Resources/$icon" "$APP/Contents/Resources/$icon"
  fi
done
if [[ -f Resources/PrtSnapIcon.png ]]; then
  cp Resources/PrtSnapIcon.png "$APP/Contents/Resources/PrtSnapIcon.png"
fi
codesign --force --deep --sign - --requirements "$ROOT/Resources/PrtSnapDesignatedRequirement.txt" "$APP"
BUNDLE_ID="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APP/Contents/Info.plist")"
EXPECTED_REQUIREMENT="designated => identifier \"$BUNDLE_ID\""
ACTUAL_REQUIREMENTS="$(codesign -dr - "$APP" 2>&1)"
if [[ "$ACTUAL_REQUIREMENTS" != *"$EXPECTED_REQUIREMENT"* ]]; then
  printf 'Unexpected designated requirement for %s: %s\n' "$BUNDLE_ID" "$ACTUAL_REQUIREMENTS" >&2
  exit 1
fi
codesign --verify --deep --strict "$APP"
echo "Built $APP"
