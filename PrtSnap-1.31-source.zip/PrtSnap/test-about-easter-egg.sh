#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
MAIN="$ROOT/Sources/PrtSnap/main.swift"

[[ -s "$ROOT/Resources/AboutEasterEgg.jpg" ]]
grep -qF 'iconTapCount == 5' "$MAIN"
grep -qF 'iconTapCount >= 10' "$MAIN"
grep -qF 'sensoryFeedback(.impact(weight: .light), trigger: iconTapCount)' "$MAIN"
grep -qF 'AboutEasterEgg", withExtension: "jpg"' "$MAIN"
grep -qF 'Resources/AboutEasterEgg.jpg' "$ROOT/build-app.sh"
grep -qF 'https://github.com/HFarRay/PrtSnap' "$MAIN"
grep -qF 'Label("在 GitHub 上给 PrtSnap 点个 🌟", systemImage: "star")' "$MAIN"
! grep -qF 'https://github.com")' "$MAIN"
! grep -qF '访问 GitHub' "$MAIN" "$ROOT/Resources/en.lproj/Localizable.strings"
grep -qF '回归正常的版本号，优化软件流畅度，提高软件稳定性' "$ROOT/CHANGELOG.md"
grep -qF '添加了一个小彩蛋' "$ROOT/CHANGELOG.md"

printf 'About Easter egg probe passed: photo resource, 5/10 taps, click feedback, GitHub links, and release note.\n'
