#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PLIST="$ROOT/Resources/Info.plist"
BUNDLE_ID="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$PLIST")"
REQUIREMENT="$(tr -d '\n' < "$ROOT/Resources/PrtSnapDesignatedRequirement.txt")"
EXPECTED="designated => identifier \"$BUNDLE_ID\""
[[ "$REQUIREMENT" == "$EXPECTED" ]]
grep -qF 'codesign --force --deep --sign - --requirements "$ROOT/Resources/PrtSnapDesignatedRequirement.txt" "$APP"' "$ROOT/build-app.sh"
grep -qF 'refreshAfterActivation()' "$ROOT/Sources/PrtSnap/PermissionCenter.swift"
grep -qF 'CGRequestScreenCaptureAccess()' "$ROOT/Sources/PrtSnap/PermissionCenter.swift"
grep -qF 'AXIsProcessTrustedWithOptions(options)' "$ROOT/Sources/PrtSnap/PermissionCenter.swift"
grep -qF 'IOHIDRequestAccess(kIOHIDRequestTypeListenEvent)' "$ROOT/Sources/PrtSnap/PermissionCenter.swift"
printf 'Permission identity probe passed: stable designated requirement for %s\n' "$BUNDLE_ID"
