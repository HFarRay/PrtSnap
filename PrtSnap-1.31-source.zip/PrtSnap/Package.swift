// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "PrtSnap",
    platforms: [.macOS(.v14)],
    products: [.executable(name: "PrtSnap", targets: ["PrtSnap"])],
    targets: [.executableTarget(name: "PrtSnap")]
)
