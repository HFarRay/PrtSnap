#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
source "$ROOT/toolchain-env.sh"
SDK="${MACOS_SDKROOT:-/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk}"
WORK="$(cd "$ROOT/../../work" && pwd)"
mkdir -p "$WORK/PrtSnap-build"
"$SWIFTC" -parse-as-library -swift-version 6 -O -sdk "$SDK" -target arm64-apple-macosx14.0 \
  -module-cache-path "$WORK/PrtSnap-build/module-cache-v2" \
  Sources/PrtSnap/ImagePipeline.swift Tests/ColorMappingProbe.swift -o "$WORK/PrtSnap-build/ColorMappingProbe"
"$WORK/PrtSnap-build/ColorMappingProbe"
