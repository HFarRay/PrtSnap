#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
UPDATER="$ROOT/Sources/PrtSnap/AppUpdater.swift"
MAIN="$ROOT/Sources/PrtSnap/main.swift"
MATCHER="$ROOT/Sources/PrtSnap/HotkeyEventMatcher.swift"

grep -qF 'onDrop(of: [UTType.fileURL]' "$MAIN"
grep -qF 'fileImporter(isPresented: $showFileImporter' "$MAIN"
grep -qF 'CGEvent.tapCreate(' "$MAIN"
grep -qF 'return shouldSwallow ? nil : Unmanaged.passUnretained(event)' "$MATCHER"
grep -qE 'designated => identifier .*local\.prtsnap\.app' "$UPDATER"
grep -qF 'codesign", ["--verify", "--deep", "--strict"' "$UPDATER"
grep -qF 'BACKUP_APP=' "$UPDATER"
grep -qF '/bin/mv "$BACKUP_APP" "$TARGET_APP"' "$UPDATER"
grep -qF 'PrtSnapDisplayVersion' "$UPDATER"
printf 'Update import and shortcut event handling probes passed.\n'
