#!/bin/bash
if [[ -z "${SWIFTC:-}" ]]; then
  XCODE_SWIFTC="/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/swiftc"
  if [[ -x "$XCODE_SWIFTC" ]]; then
    SWIFTC="$XCODE_SWIFTC"
  else
    SWIFTC="/Library/Developer/CommandLineTools/usr/bin/swiftc"
  fi
fi

if [[ -z "${MACOS_SDKROOT:-}" ]]; then
  XCODE_SDK="/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk"
  if [[ -d "$XCODE_SDK" ]]; then
    MACOS_SDKROOT="$XCODE_SDK"
  else
    MACOS_SDKROOT="/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk"
  fi
fi

export SWIFTC MACOS_SDKROOT
