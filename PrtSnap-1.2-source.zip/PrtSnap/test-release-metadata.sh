#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PLIST="$ROOT/Resources/Info.plist"
DISPLAY_VERSION="$(/usr/libexec/PlistBuddy -c 'Print :PrtSnapDisplayVersion' "$PLIST")"
SHORT_VERSION="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$PLIST")"
BUILD_VERSION="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$PLIST")"

[[ "$DISPLAY_VERSION" == "1.2" ]]
[[ "$SHORT_VERSION" == "1.2" ]]
[[ "$BUILD_VERSION" == "1.2" ]]
grep -qF '## 1.2 - ' "$ROOT/CHANGELOG.md"
grep -qF '("1.2", "PrtSnap 正式发布"' "$ROOT/Sources/PrtSnap/main.swift"
grep -qF '回归正常的版本号，优化软件流畅度，提高软件稳定性' "$ROOT/CHANGELOG.md"
grep -qF '("1.1.4514beta3.2", "界面排版优化"' "$ROOT/Sources/PrtSnap/main.swift"
grep -qF '"超出目标色域处理" = "Out-of-Gamut Handling";' "$ROOT/Resources/en.lproj/Localizable.strings"
grep -qF '"超出色域直接裁切" = "Clip Out-of-Gamut Colors";' "$ROOT/Resources/en.lproj/Localizable.strings"
grep -qF '"感知式压缩" = "Perceptual Compression";' "$ROOT/Resources/en.lproj/Localizable.strings"
if grep -Eq 'V[0-9]+\.[0-9]+' "$PLIST" "$ROOT/CHANGELOG.md" "$ROOT/Sources/PrtSnap/main.swift"; then
  printf 'Version labels must not use a V prefix.\n' >&2
  exit 1
fi

printf 'Release metadata probe passed: display %s; bundle %s; build %s\n' \
  "$DISPLAY_VERSION" "$SHORT_VERSION" "$BUILD_VERSION"
