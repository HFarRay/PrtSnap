#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUTPUTS="$(cd "$ROOT/.." && pwd)"
RELEASE_VERSION="$(/usr/libexec/PlistBuddy -c 'Print :PrtSnapDisplayVersion' "$ROOT/Resources/Info.plist")"
PACKAGE_VERSION="$RELEASE_VERSION"
DMG="$OUTPUTS/PrtSnap-${PACKAGE_VERSION}.dmg"
ZIP="$OUTPUTS/PrtSnap-${PACKAGE_VERSION}.zip"
STAGE="$(mktemp -d "${TMPDIR:-/tmp}/PrtSnap-dmg-stage.XXXXXX")"
LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"
cleanup() {
  "$LSREGISTER" -u "$STAGE/PrtSnap.app" >/dev/null 2>&1 || true
  rm -rf "$STAGE"
}
trap cleanup EXIT
"$ROOT/test-color-pipeline.sh"
bash "$ROOT/test-shortcut-model.sh"
bash "$ROOT/test-editor-undo.sh"
bash "$ROOT/test-history-retention.sh"
bash "$ROOT/test-icon-appearance.sh"
bash "$ROOT/test-permission-identity.sh"
bash "$ROOT/test-permission-status.sh"
bash "$ROOT/test-updater.sh"
bash "$ROOT/test-hotkey-events.sh"
bash "$ROOT/test-release-metadata.sh"
PRTSNAP_APP_OUTPUT="$STAGE/PrtSnap.app" "$ROOT/build-app.sh"
ln -sfn /Applications "$STAGE/Applications"
hdiutil create -volname "PrtSnap" -srcfolder "$STAGE" -ov -format UDZO "$DMG"
hdiutil verify "$DMG"
bash "$ROOT/test-update-package.sh" "$DMG"
echo "Built $DMG"
zip -j -X "$ZIP" "$DMG" "$ROOT/README.md" "$ROOT/CHANGELOG.md"
unzip -t "$ZIP"
SOURCE_DMG_HASH="$(shasum -a 256 "$DMG" | awk '{print $1}')"
ARCHIVED_DMG_HASH="$(unzip -p "$ZIP" "$(basename "$DMG")" | shasum -a 256 | awk '{print $1}')"
[[ "$ARCHIVED_DMG_HASH" == "$SOURCE_DMG_HASH" ]]
echo "Verified ZIP contains $(basename "$DMG") with SHA-256 $SOURCE_DMG_HASH"
echo "Built $ZIP"
