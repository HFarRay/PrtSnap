import AppKit
import QuickLook
import ScreenCaptureKit
import ServiceManagement
import SwiftUI
import UniformTypeIdentifiers

private enum AppLanguage: String {
    case chinese = "zh-Hans"
    case english = "en"
}

private enum AppLocalization {
    static func string(_ key: String, language: String) -> String {
        guard language == AppLanguage.english.rawValue,
              let url = Bundle.main.url(forResource: "en", withExtension: "lproj"),
              let bundle = Bundle(url: url) else { return key }
        return bundle.localizedString(forKey: key, value: key, table: nil)
    }

    static func menuStatus(_ status: String, language: String) -> String {
        let dynamicPrefixes: [(String, String)] = [
            ("已复制到剪贴板 · ", "Copied to clipboard · "),
            ("截图失败：", "Screenshot failed: "),
            ("历史截图保存失败：", "Could not save screenshot: "),
            ("复制历史截图失败", "Could not copy screenshot"),
            ("已复制 ", "Copied "),
            ("已保存编辑截图 · ", "Saved edited screenshot · "),
            ("编辑截图保存失败：", "Could not save edited screenshot: "),
            ("设置历史截图目录失败：", "Could not set screenshot folder: "),
            ("已导入音效：", "Imported sound: "),
            ("音效导入失败：", "Could not import sound: "),
            ("找不到音效：", "Sound not found: "),
            ("登录项设置失败：", "Could not update login item: ")
        ]
        guard language == AppLanguage.english.rawValue else { return status }
        if status.hasPrefix("已复制 "), let countEnd = status.range(of: " 张截图到剪贴板") {
            let count = status[status.index(status.startIndex, offsetBy: "已复制 ".count)..<countEnd.lowerBound]
            return "Copied \(count) screenshots to the clipboard"
        }
        for (source, translated) in dynamicPrefixes where status.hasPrefix(source) {
            return translated + status.dropFirst(source.count)
        }
        return string(status, language: language)
    }
}

private enum AppearanceMode: String, CaseIterable, Identifiable {
    case system
    case light
    case dark

    var id: String { rawValue }
    var title: String {
        switch self {
        case .system: "跟随系统"
        case .light: "白天"
        case .dark: "黑夜"
        }
    }
    var colorScheme: ColorScheme? {
        switch self {
        case .system: nil
        case .light: .light
        case .dark: .dark
        }
    }
}

@MainActor
private enum AppIconProvider {
    private static func resourceName(mode: String, colorScheme: ColorScheme) -> String {
        let resolvedScheme: ColorScheme
        switch mode {
        case AppearanceMode.dark.rawValue:
            resolvedScheme = .dark
        case AppearanceMode.light.rawValue:
            resolvedScheme = .light
        default:
            resolvedScheme = colorScheme
        }
        return resolvedScheme == .dark ? "AppIcon-Dark" : "AppIcon-Light"
    }

    static func systemColorScheme() -> ColorScheme {
        if let interfaceStyle = UserDefaults.standard.string(forKey: "AppleInterfaceStyle") {
            return SystemAppearanceResolver.fromInterfaceStyle(interfaceStyle)
        }
        return NSApp.effectiveAppearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua ? .dark : .light
    }

    static func image(mode: String, colorScheme: ColorScheme) -> NSImage? {
        guard let url = Bundle.main.url(forResource: resourceName(mode: mode, colorScheme: colorScheme),
                                        withExtension: "icns") else { return nil }
        guard let image = NSImage(contentsOf: url) else { return nil }
        return roundedIcon(image)
    }

    static func apply(mode: String, colorScheme: ColorScheme) {
        guard let image = image(mode: mode, colorScheme: colorScheme) else { return }
        NSApplication.shared.applicationIconImage = image
    }

    private static func roundedIcon(_ image: NSImage) -> NSImage {
        let size = NSSize(width: 1024, height: 1024)
        let bounds = NSRect(origin: .zero, size: size)
        let icon = NSImage(size: size)
        icon.lockFocus()
        NSGraphicsContext.current?.imageInterpolation = .high
        NSBezierPath(roundedRect: bounds,
                     xRadius: size.width * 0.22,
                     yRadius: size.height * 0.22).addClip()
        image.draw(in: bounds, from: .zero, operation: .copy, fraction: 1)
        icon.unlockFocus()
        return icon
    }
}

@MainActor
final class Preferences: ObservableObject {
    @Published var screenShortcut: Shortcut { didSet { save(); HotkeyCenter.shared.refresh(); AppDelegate.shared?.refreshStatusMenu() } }
    @Published var windowShortcut: Shortcut { didSet { save(); HotkeyCenter.shared.refresh(); AppDelegate.shared?.refreshStatusMenu() } }
    @Published var scale: Double { didSet { save() } }
    @Published var quality: Double { didSet { save() } }
    @Published var convertHDRToSDR: Bool { didSet { save() } }
    @Published var mosaicStrength: Double { didSet { save() } }
    @Published var format: String { didSet { save() } }
    @Published var colorSpace: String { didSet { save() } }
    @Published var gamutMappingMode: String { didSet { save() } }
    @Published var appearanceMode: String { didSet { save() } }
    @Published var screenSound: String { didSet { save() } }
    @Published var windowSound: String { didSet { save() } }
    @Published var historyRetention: String {
        didSet {
            save()
            HistoryManager.shared.refresh()
        }
    }
    @Published var launchAtLogin: Bool { didSet { saveLoginItem() } }
    @Published var showDockIcon: Bool {
        didSet {
            defaults.set(showDockIcon, forKey: "showDockIcon")
            AppDelegate.shared?.applyActivationPolicy()
        }
    }
    @Published var appLanguage: String {
        didSet {
            defaults.set(appLanguage, forKey: "appLanguage")
            AppDelegate.shared?.refreshStatusMenu()
        }
    }
    @Published var hideStatusBarIcon: Bool {
        didSet {
            defaults.set(hideStatusBarIcon, forKey: "hideStatusBarIcon")
            AppDelegate.shared?.setStatusItemVisible(!hideStatusBarIcon)
        }
    }
    @Published var status = "就绪" { didSet { AppDelegate.shared?.refreshStatusMenu() } }

    private let defaults = UserDefaults.standard
    private let loginItemQueue = DispatchQueue(label: "local.prtsnap.login-item", qos: .utility)
    private var loginRequestID = 0
    private var suppressLoginItemUpdate = false
    static let shared = Preferences()

    private init() {
        func shortcut(_ key: String, fallback: Shortcut) -> Shortcut {
            guard let data = UserDefaults.standard.data(forKey: key),
                  let value = try? JSONDecoder().decode(Shortcut.self, from: data) else { return fallback }
            return value
        }
        screenShortcut = shortcut("screenShortcut", fallback: Shortcut(keyCodes: [59, 56, 20]))
        windowShortcut = shortcut("windowShortcut", fallback: Shortcut(keyCodes: [59, 58, 56, 20]))
        scale = defaults.object(forKey: "scale") as? Double ?? 1.0
        quality = defaults.object(forKey: "quality") as? Double ?? 0.9
        convertHDRToSDR = defaults.object(forKey: "convertHDRToSDR") as? Bool ?? false
        mosaicStrength = defaults.object(forKey: "mosaicStrength") as? Double ?? 18
        format = defaults.string(forKey: "format") ?? "PNG"
        colorSpace = defaults.string(forKey: "colorSpace") ?? "sRGB"
        gamutMappingMode = defaults.string(forKey: "gamutMappingMode") ?? GamutMappingMode.clip.rawValue
        appearanceMode = defaults.string(forKey: "appearanceMode") ?? AppearanceMode.system.rawValue
        let previousScreenSound = defaults.string(forKey: "screenSound")
        let previousWindowSound = defaults.string(forKey: "windowSound")
        let migrateSoundDefaults = !defaults.bool(forKey: "captureSoundDefaultsV113Migrated")
        let defaultScreenSound = migrateSoundDefaults && (previousScreenSound == nil || previousScreenSound == "Glass")
            ? CaptureSoundPlayer.defaultScreenSound : previousScreenSound ?? CaptureSoundPlayer.defaultScreenSound
        let defaultWindowSound = migrateSoundDefaults && (previousWindowSound == nil || previousWindowSound == "Ping")
            ? CaptureSoundPlayer.defaultWindowSound : previousWindowSound ?? CaptureSoundPlayer.defaultWindowSound
        screenSound = defaultScreenSound
        windowSound = defaultWindowSound
        defaults.set(defaultScreenSound, forKey: "screenSound")
        defaults.set(defaultWindowSound, forKey: "windowSound")
        defaults.set(true, forKey: "captureSoundDefaultsV113Migrated")
        let retention = HistoryRetention.migratedRawValue(defaults.string(forKey: "historyRetention"))
        historyRetention = retention
        defaults.set(retention, forKey: "historyRetention")
        hideStatusBarIcon = defaults.bool(forKey: "hideStatusBarIcon")
        showDockIcon = defaults.bool(forKey: "showDockIcon")
        appLanguage = defaults.string(forKey: "appLanguage") ?? AppLanguage.chinese.rawValue
        let launchedFromMountedVolume = Bundle.main.bundleURL.path.hasPrefix("/Volumes/")
        launchAtLogin = !launchedFromMountedVolume && (defaults.object(forKey: "launchAtLogin") as? Bool ?? true)
    }

    private func save() {
        defaults.set(try? JSONEncoder().encode(screenShortcut), forKey: "screenShortcut")
        defaults.set(try? JSONEncoder().encode(windowShortcut), forKey: "windowShortcut")
        defaults.set(scale, forKey: "scale")
        defaults.set(quality, forKey: "quality")
        defaults.set(convertHDRToSDR, forKey: "convertHDRToSDR")
        defaults.set(mosaicStrength, forKey: "mosaicStrength")
        defaults.set(format, forKey: "format")
        defaults.set(colorSpace, forKey: "colorSpace")
        defaults.set(gamutMappingMode, forKey: "gamutMappingMode")
        defaults.set(appearanceMode, forKey: "appearanceMode")
        defaults.set(screenSound, forKey: "screenSound")
        defaults.set(windowSound, forKey: "windowSound")
        defaults.set(historyRetention, forKey: "historyRetention")
        defaults.set(hideStatusBarIcon, forKey: "hideStatusBarIcon")
    }

    func synchronizeLoginItem() {
        let bundlePath = Bundle.main.bundleURL.standardizedFileURL.path
        guard isInstalledLocation(bundlePath) else { return }
        let needsLocationRefresh = defaults.string(forKey: "loginItemBundlePath") != bundlePath
        requestLoginItemState(launchAtLogin, refreshLocation: launchAtLogin && needsLocationRefresh)
    }

    private func saveLoginItem() {
        defaults.set(launchAtLogin, forKey: "launchAtLogin")
        guard !suppressLoginItemUpdate else { return }
        let bundlePath = Bundle.main.bundleURL.standardizedFileURL.path
        if launchAtLogin && !isInstalledLocation(bundlePath) {
            status = "请先将 PrtSnap 安装到“应用程序”后再启用登录启动"
            setLoginAtLogin(false)
            return
        }
        requestLoginItemState(launchAtLogin)
    }

    private func isInstalledLocation(_ path: String) -> Bool {
        let roots = ["/Applications/", "\(NSHomeDirectory())/Applications/"]
        return roots.contains { path.hasPrefix($0) }
    }

    private func requestLoginItemState(_ enabled: Bool, refreshLocation: Bool = false) {
        loginRequestID += 1
        let requestID = loginRequestID
        let bundlePath = Bundle.main.bundleURL.standardizedFileURL.path
        loginItemQueue.async { [weak self] in
            do {
                let service = SMAppService.mainApp
                let currentlyEnabled = service.status == .enabled
                if enabled {
                    if currentlyEnabled && refreshLocation { try service.unregister() }
                    if !currentlyEnabled || refreshLocation { try service.register() }
                } else if currentlyEnabled {
                    try service.unregister()
                }
                DispatchQueue.main.async { [weak self] in
                    guard let self, self.loginRequestID == requestID else { return }
                    self.defaults.set(enabled, forKey: "launchAtLogin")
                    if enabled { self.defaults.set(bundlePath, forKey: "loginItemBundlePath") }
                    else { self.defaults.removeObject(forKey: "loginItemBundlePath") }
                }
            } catch {
                DispatchQueue.main.async { [weak self] in
                    guard let self, self.loginRequestID == requestID else { return }
                    self.status = "登录项设置失败：\(error.localizedDescription)"
                    self.setLoginAtLogin(SMAppService.mainApp.status == .enabled)
                }
            }
        }
    }

    private func setLoginAtLogin(_ enabled: Bool) {
        suppressLoginItemUpdate = true
        launchAtLogin = enabled
        suppressLoginItemUpdate = false
        defaults.set(enabled, forKey: "launchAtLogin")
    }
}

@MainActor
final class HotkeyCenter {
    static let shared = HotkeyCenter()
    private let eventState = HotkeyEventMatcher { kind in
        Task { @MainActor in CaptureService.shared.capture(kind) }
    }
    private var eventTap: CFMachPort?
    private var runLoopSource: CFRunLoopSource?
    private var isRecordingShortcut = false
    private init() { }

    func install() {
        refresh()
    }

    func refresh() {
        if let runLoopSource {
            CFRunLoopRemoveSource(CFRunLoopGetMain(), runLoopSource, .commonModes)
            self.runLoopSource = nil
        }
        if let eventTap {
            CGEvent.tapEnable(tap: eventTap, enable: false)
            self.eventTap = nil
        }
        let prefs = Preferences.shared
        let shortcuts: [(CaptureKind, Shortcut)] = [(.screen, prefs.screenShortcut), (.window, prefs.windowShortcut)]
        eventState.setBindings(shortcuts.compactMap { kind, shortcut in
            let required = Set(shortcut.keyCodes.map(KeyNames.canonicalKeyCode))
            guard shortcut.isComplete, required.count == shortcut.keyCodes.count else { return nil }
            return HotkeyBinding(kind: kind, keyCodes: required)
        })
        guard !isRecordingShortcut else { return }

        guard PermissionCenter.shared.inputMonitoring, PermissionCenter.shared.accessibility else {
            Preferences.shared.status = "全局快捷键需要输入监控和辅助功能权限"
            return
        }

        let eventMask = (CGEventMask(1) << CGEventType.keyDown.rawValue)
            | (CGEventMask(1) << CGEventType.keyUp.rawValue)
            | (CGEventMask(1) << CGEventType.flagsChanged.rawValue)
        let callback: CGEventTapCallBack = { _, type, event, userInfo in
            guard let userInfo else { return Unmanaged.passUnretained(event) }
            let state = Unmanaged<HotkeyEventMatcher>.fromOpaque(userInfo).takeUnretainedValue()
            return state.handle(type, event: event)
        }
        guard let tap = CGEvent.tapCreate(
            tap: .cgSessionEventTap,
            place: .headInsertEventTap,
            options: .defaultTap,
            eventsOfInterest: eventMask,
            callback: callback,
            userInfo: Unmanaged.passUnretained(eventState).toOpaque()
        ), let source = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, tap, 0) else {
            Preferences.shared.status = "无法拦截快捷键，请检查辅助功能权限"
            return
        }
        eventTap = tap
        runLoopSource = source
        eventState.setEventTap(tap)
        CFRunLoopAddSource(CFRunLoopGetMain(), source, .commonModes)
        CGEvent.tapEnable(tap: tap, enable: true)
    }

    func setShortcutRecording(_ recording: Bool) {
        guard isRecordingShortcut != recording else { return }
        isRecordingShortcut = recording
        refresh()
    }
}

@MainActor
final class CaptureService {
    static let shared = CaptureService()
    private init() {}

    func capture(_ kind: CaptureKind) {
        Task {
            do {
                let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
                let filter: SCContentFilter
                let width: Int
                let height: Int
                if kind == .window {
                    let pid = NSWorkspace.shared.frontmostApplication?.processIdentifier
                    guard let window = content.windows.first(where: { $0.isOnScreen && $0.windowLayer == 0 && $0.owningApplication?.processID == pid }) else {
                        Preferences.shared.status = "未找到当前窗口"
                        return
                    }
                    filter = SCContentFilter(desktopIndependentWindow: window)
                    width = max(1, Int(window.frame.width * 2))
                    height = max(1, Int(window.frame.height * 2))
                } else {
                    guard let display = content.displays.first(where: { $0.displayID == CGMainDisplayID() }) ?? content.displays.first else {
                        Preferences.shared.status = "未找到显示器"
                        return
                    }
                    filter = SCContentFilter(display: display, excludingWindows: [])
                    width = display.width
                    height = display.height
                }
                // The HDR screenshot preset sets the RGhA pixel format and the
                // extended-linear transfer function required by ScreenCaptureKit.
                // Setting only captureDynamicRange leaves the returned CGImage
                // dependent on the display profile, which can silently flatten
                // wide-gamut/highlight values before our output mapping runs.
                let config: SCStreamConfiguration
                if #available(macOS 15.0, *) {
                    config = SCStreamConfiguration(preset: .captureHDRScreenshotCanonicalDisplay)
                } else {
                    config = SCStreamConfiguration()
                }
                config.width = width
                config.height = height
                config.showsCursor = true
                config.capturesAudio = false
                if #available(macOS 15.0, *) {
                    config.captureDynamicRange = .hdrCanonicalDisplay
                }
                let selectedSpace = OutputColorSpace(rawValue: Preferences.shared.colorSpace) ?? .sRGB
                config.colorSpaceName = ImagePipeline.captureColorSpaceName(
                    format: Preferences.shared.format,
                    convertHDRToSDR: Preferences.shared.convertHDRToSDR,
                    selected: selectedSpace
                )
                let image = try await Self.capture(filter: filter, configuration: config)
                try Self.copy(image: image)
                CaptureSoundPlayer.shared.play(kind == .screen ? Preferences.shared.screenSound : Preferences.shared.windowSound)
                Preferences.shared.status = "已复制到剪贴板 · \(Date.now.formatted(date: .omitted, time: .shortened))"
            } catch {
                Preferences.shared.status = "截图失败：\(error.localizedDescription)"
            }
        }
    }

    private static func capture(filter: SCContentFilter, configuration: SCStreamConfiguration) async throws -> CGImage {
        try await withCheckedThrowingContinuation { continuation in
            SCScreenshotManager.captureImage(contentFilter: filter, configuration: configuration) { image, error in
                if let error { continuation.resume(throwing: error) }
                else if let image { continuation.resume(returning: image) }
                else { continuation.resume(throwing: NSError(domain: "PrtSnap", code: 1, userInfo: [NSLocalizedDescriptionKey: "没有返回图像"])) }
            }
        }
    }

    private static func copy(image: CGImage) throws {
        let prefs = Preferences.shared
        let selectedSpace = OutputColorSpace(rawValue: prefs.colorSpace) ?? .sRGB
        let outputSpace = ImagePipeline.outputColorSpace(
            format: prefs.format,
            convertHDRToSDR: prefs.convertHDRToSDR,
            selected: selectedSpace
        )
        let sourceIsHDR = ImagePipeline.isHDR(image)
        let preserveHDR = sourceIsHDR && prefs.format == "PNG" && !prefs.convertHDRToSDR
        let converted = try ImagePipeline.prepare(
            image,
            scale: prefs.scale,
            colorSpace: outputSpace,
            format: prefs.format,
            convertHDRToSDR: prefs.convertHDRToSDR,
            gamutMapping: GamutMappingMode(rawValue: prefs.gamutMappingMode) ?? .clip
        )
        let data = try ImagePipeline.encode(converted, format: prefs.format, quality: prefs.quality, preserveHDR: preserveHDR)
        HistoryManager.shared.record(data: data, format: prefs.format)
        let isPNG = prefs.format == "PNG"
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setData(data, forType: isPNG ? .png : NSPasteboard.PasteboardType("public.jpeg"))
    }
}

struct ShortcutRecorder: View {
    let title: String
    @Binding var shortcut: Shortcut
    @State private var recordingIndex: Int?
    @State private var monitor: Any?
    @State private var modifierPollTimer: Timer?
    @State private var previousModifierFlags: NSEvent.ModifierFlags = []

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(LocalizedStringKey(title)).font(.headline)
                Spacer()
                Button { appendKey() } label: { Label("添加按键", systemImage: "plus") }
                    .buttonStyle(.bordered)
            }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 116), spacing: 8)], alignment: .leading, spacing: 8) {
                ForEach(shortcut.keys.indices, id: \.self) { index in
                    HStack(spacing: 4) {
                        ShortcutKeyCaptureButton(
                            title: recordingIndex == index
                                ? AppLocalization.string("按下按键…", language: Preferences.shared.appLanguage)
                                : AppLocalization.string(shortcut.keys[index].displayValue, language: Preferences.shared.appLanguage),
                            isRecording: recordingIndex == index,
                            onActivate: { beginRecording(at: index) },
                            onKey: { event in record(event, at: index) }
                        )
                        .frame(minWidth: 86, minHeight: 34)
                        .help("单独录入此按键")
                        Button {
                            removeKey(at: index)
                        } label: {
                            Image(systemName: "minus.circle")
                        }
                        .buttonStyle(.plain)
                        .help("移除此按键")
                    }
                }
            }
        }
        .padding(.vertical, 5)
        .onDisappear { stopRecording() }
    }

    private func appendKey() {
        shortcut.keys.append(ShortcutKey(keyCode: nil))
        beginRecording(at: shortcut.keys.count - 1)
    }

    private func removeKey(at index: Int) {
        shortcut.keys.remove(at: index)
        if let recordingIndex, recordingIndex == index { stopRecording() }
        else if let recordingIndex, recordingIndex > index { self.recordingIndex = recordingIndex - 1 }
    }

    private func beginRecording(at index: Int) {
        stopRecording()
        HotkeyCenter.shared.setShortcutRecording(true)
        recordingIndex = index
        let trackedFlags: NSEvent.ModifierFlags = [.command, .option, .shift, .control]
        previousModifierFlags = NSEvent.modifierFlags.intersection(trackedFlags)
        monitor = NSEvent.addLocalMonitorForEvents(matching: [.keyDown, .flagsChanged]) { event in
            record(event, at: index)
            return event
        }
        modifierPollTimer = Timer.scheduledTimer(withTimeInterval: 0.025, repeats: true) { _ in
            MainActor.assumeIsolated {
                guard recordingIndex == index else { return }
                let currentFlags = NSEvent.modifierFlags.intersection(trackedFlags)
                let newlyPressed = currentFlags.subtracting(previousModifierFlags)
                previousModifierFlags = currentFlags
                let keyCode: UInt32?
                if newlyPressed.contains(.command) { keyCode = 55 }
                else if newlyPressed.contains(.option) { keyCode = 58 }
                else if newlyPressed.contains(.shift) { keyCode = 56 }
                else if newlyPressed.contains(.control) { keyCode = 59 }
                else { keyCode = nil }
                if let keyCode {
                    record(keyCode: keyCode, displayValue: KeyNames.name(for: keyCode), at: index)
                }
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
            if recordingIndex == index { stopRecording() }
        }
    }

    private func record(_ event: NSEvent, at index: Int) {
        guard recordingIndex == index, shortcut.keys.indices.contains(index) else { return }
        let code = Self.recordedKeyCode(for: event)
        record(keyCode: code,
               displayValue: KeyNames.displayValue(
                   for: code,
                   characters: event.charactersIgnoringModifiers ?? event.characters
               ),
               at: index)
    }

    private func record(keyCode: UInt32, displayValue: String, at index: Int) {
        guard recordingIndex == index, shortcut.keys.indices.contains(index) else { return }
        var keys = shortcut.keys
        keys[index] = ShortcutKey(keyCode: keyCode, displayValue: displayValue)
        shortcut.keys = keys
        stopRecording()
    }

    private static func recordedKeyCode(for event: NSEvent) -> UInt32 {
        let flags = event.modifierFlags
        var modifiers: ShortcutModifiers = []
        if flags.contains(.command) { modifiers.insert(.command) }
        if flags.contains(.option) { modifiers.insert(.option) }
        if flags.contains(.shift) { modifiers.insert(.shift) }
        if flags.contains(.control) { modifiers.insert(.control) }
        return KeyNames.recordedKeyCode(
            eventKeyCode: UInt32(event.keyCode),
            isModifierEvent: event.type == .flagsChanged,
            modifiers: modifiers
        )
    }

    private func stopRecording() {
        let wasRecording = recordingIndex != nil
        if let monitor { NSEvent.removeMonitor(monitor) }
        monitor = nil
        modifierPollTimer?.invalidate()
        modifierPollTimer = nil
        recordingIndex = nil
        if wasRecording { HotkeyCenter.shared.setShortcutRecording(false) }
    }
}

private struct ShortcutKeyCaptureButton: NSViewRepresentable {
    let title: String
    let isRecording: Bool
    let onActivate: () -> Void
    let onKey: (NSEvent) -> Void

    func makeNSView(context: Context) -> RecorderButton {
        let button = RecorderButton()
        button.bezelStyle = .rounded
        button.controlSize = .regular
        button.font = .systemFont(ofSize: 13)
        button.target = button
        button.action = #selector(RecorderButton.activate)
        return button
    }

    func updateNSView(_ button: RecorderButton, context: Context) {
        button.title = title
        button.isRecording = isRecording
        button.onActivate = onActivate
        button.onKey = onKey
        if isRecording {
            DispatchQueue.main.async { [weak button] in
                guard let button, button.window?.firstResponder !== button else { return }
                button.window?.makeFirstResponder(button)
            }
        }
    }

    final class RecorderButton: NSButton {
        var isRecording = false
        var onActivate: (() -> Void)?
        var onKey: ((NSEvent) -> Void)?

        override var acceptsFirstResponder: Bool { true }

        @objc func activate() {
            onActivate?()
            window?.makeFirstResponder(self)
        }

        override func performKeyEquivalent(with event: NSEvent) -> Bool {
            guard isRecording else { return super.performKeyEquivalent(with: event) }
            onKey?(event)
            return true
        }

        override func keyDown(with event: NSEvent) {
            guard isRecording else { super.keyDown(with: event); return }
            onKey?(event)
        }

        override func flagsChanged(with event: NSEvent) {
            guard isRecording else { super.flagsChanged(with: event); return }
            onKey?(event)
        }
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    static weak var shared: AppDelegate?
    private var statusItem: NSStatusItem?
    private var screenMenuItem: NSMenuItem?
    private var windowMenuItem: NSMenuItem?
    private var statusMenuItem: NSMenuItem?
    private var settingsMenuItem: NSMenuItem?
    private var quitMenuItem: NSMenuItem?
    var openSettingsWindow: (() -> Void)?

    override init() {
        super.init()
        Self.shared = self
    }

    func applicationWillFinishLaunching(_ notification: Notification) {
        let prefs = Preferences.shared
        AppIconProvider.apply(mode: prefs.appearanceMode,
                              colorScheme: AppIconProvider.systemColorScheme())
        applyActivationPolicy()
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        installStatusItem()
        HotkeyCenter.shared.install()
        DispatchQueue.main.async {
            NSApp.activate(ignoringOtherApps: true)
            Preferences.shared.synchronizeLoginItem()
        }
    }

    func applicationDidBecomeActive(_ notification: Notification) {
        PermissionCenter.shared.refreshAfterActivation()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
            HotkeyCenter.shared.refresh()
        }
    }

    func showSettings() {
        openSettingsWindow?()
        NSApp.activate(ignoringOtherApps: true)
    }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows: Bool) -> Bool {
        if !hasVisibleWindows { showSettings() }
        return true
    }

    func setStatusItemVisible(_ visible: Bool) {
        statusItem?.isVisible = visible
        applyActivationPolicy()
    }

    func applyActivationPolicy() {
        let prefs = Preferences.shared
        if prefs.showDockIcon {
            AppIconProvider.apply(mode: prefs.appearanceMode,
                                  colorScheme: AppIconProvider.systemColorScheme())
        }
        NSApp.setActivationPolicy(prefs.showDockIcon ? .regular : .accessory)
    }

    func refreshStatusMenu() {
        let prefs = Preferences.shared
        let language = prefs.appLanguage
        let screenShortcut = AppLocalization.string(prefs.screenShortcut.label, language: language)
        let windowShortcut = AppLocalization.string(prefs.windowShortcut.label, language: language)
        screenMenuItem?.title = "\(AppLocalization.string("截取屏幕", language: language))  ·  \(screenShortcut)"
        windowMenuItem?.title = "\(AppLocalization.string("截取当前窗口", language: language))  ·  \(windowShortcut)"
        statusMenuItem?.title = AppLocalization.menuStatus(prefs.status, language: language)
        settingsMenuItem?.title = AppLocalization.string("打开设置…", language: language)
        quitMenuItem?.title = AppLocalization.string("退出 PrtSnap", language: language)
    }

    private func installStatusItem() {
        guard statusItem == nil else { return }
        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        item.button?.image = NSImage(systemSymbolName: "camera.viewfinder", accessibilityDescription: "PrtSnap")
        item.button?.imagePosition = .imageOnly
        item.button?.toolTip = "PrtSnap"

        let menu = NSMenu()
        let language = Preferences.shared.appLanguage
        let screen = NSMenuItem(title: AppLocalization.string("截取屏幕", language: language), action: #selector(captureScreenFromMenu), keyEquivalent: "")
        screen.target = self
        let window = NSMenuItem(title: AppLocalization.string("截取当前窗口", language: language), action: #selector(captureWindowFromMenu), keyEquivalent: "")
        window.target = self
        let status = NSMenuItem(title: AppLocalization.string("就绪", language: language), action: nil, keyEquivalent: "")
        status.isEnabled = false
        let settings = NSMenuItem(title: AppLocalization.string("打开设置…", language: language), action: #selector(openSettingsFromMenu), keyEquivalent: ",")
        settings.target = self
        let quit = NSMenuItem(title: AppLocalization.string("退出 PrtSnap", language: language), action: #selector(quitFromMenu), keyEquivalent: "q")
        quit.target = self
        menu.addItem(screen)
        menu.addItem(window)
        menu.addItem(.separator())
        menu.addItem(status)
        menu.addItem(settings)
        menu.addItem(.separator())
        menu.addItem(quit)
        item.menu = menu

        statusItem = item
        screenMenuItem = screen
        windowMenuItem = window
        statusMenuItem = status
        settingsMenuItem = settings
        quitMenuItem = quit
        item.isVisible = !Preferences.shared.hideStatusBarIcon
        refreshStatusMenu()
    }

    @objc private func captureScreenFromMenu() {
        CaptureService.shared.capture(.screen)
    }

    @objc private func captureWindowFromMenu() {
        CaptureService.shared.capture(.window)
    }

    @objc private func openSettingsFromMenu() {
        showSettings()
    }

    @objc private func quitFromMenu() {
        NSApplication.shared.terminate(nil)
    }
}

@main
struct PrtSnapApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var prefs = Preferences.shared
    @Environment(\.openWindow) private var openWindow

    var body: some Scene {
        WindowGroup("PrtSnap", id: "settings") {
            SettingsView(prefs: prefs)
                .environment(\.locale, Locale(identifier: prefs.appLanguage))
                .onAppear {
                    AppDelegate.shared?.openSettingsWindow = { openWindow(id: "settings") }
                }
        }
        .defaultSize(width: 920, height: 680)
    }

    init() {
        if CommandLine.arguments.contains("--refresh-login-item") {
            do {
                if SMAppService.mainApp.status == .enabled { try SMAppService.mainApp.unregister() }
                try SMAppService.mainApp.register()
                exit(EXIT_SUCCESS)
            } catch {
                fputs("Login item registration failed: \(error.localizedDescription)\n", stderr)
                exit(EXIT_FAILURE)
            }
        }
    }
}

struct SettingsView: View {
    @ObservedObject var prefs: Preferences
    @ObservedObject private var permissions = PermissionCenter.shared
    @Environment(\.colorScheme) private var colorScheme
    @State private var selectedTab: SettingsSection? = .capture

    private var hasPermissionIssues: Bool {
        !permissions.screenRecording || !permissions.accessibility ||
            !permissions.inputMonitoring || !permissions.notifications
    }

    var body: some View {
        HStack(spacing: 0) {
            VStack(spacing: 0) {
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        sidebarGroup("应用", sections: [.permissions])
                        sidebarGroup("截图", sections: [.capture, .shortcuts, .history])
                        sidebarGroup("更多", sections: [.updates, .donation, .about])
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 14)
                }
                Divider()
                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 8) {
                        languageButton("🇨🇳", language: AppLanguage.chinese.rawValue, help: "简体中文")
                        languageButton("🇺🇸", language: AppLanguage.english.rawValue, help: "English")
                    }
                    Text("The way to switch language inspired by Smartisan🔨")
                        .font(.system(size: 8.5))
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                        .foregroundStyle(.secondary)
                        .help("The way to switch language inspired by Smartisan🔨")
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 10)
                .padding(.vertical, 9)
            }
            .background(.ultraThinMaterial)
            .frame(width: 232)
            Rectangle()
                .fill(Color.primary.opacity(0.1))
                .frame(width: 1)
            let section = selectedTab ?? .capture
            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    GlassIconBadge(symbol: section.symbol)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(LocalizedStringKey(section.title)).font(.title2.weight(.semibold))
                        Text(LocalizedStringKey(section.subtitle)).font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 18)
                Divider()
                page(for: section)
                    .frame(maxWidth: .infinity, maxHeight: .infinity,
                           alignment: .topLeading)
                    .padding(.horizontal, 22)
                    .padding(.top, 16)
                    .padding(.bottom, 16)
            }
        }
        .frame(minWidth: 860, minHeight: 620)
        .environment(\.locale, Locale(identifier: prefs.appLanguage))
        .preferredColorScheme(AppearanceMode(rawValue: prefs.appearanceMode)?.colorScheme)
        .onAppear { AppIconProvider.apply(mode: prefs.appearanceMode, colorScheme: colorScheme) }
        .onChange(of: prefs.appearanceMode) { _, mode in
            AppIconProvider.apply(mode: mode, colorScheme: colorScheme)
        }
        .onChange(of: colorScheme) { _, scheme in
            AppIconProvider.apply(mode: prefs.appearanceMode, colorScheme: scheme)
        }
    }

    private func languageButton(_ flag: String, language: String, help: String) -> some View {
        Button {
            prefs.appLanguage = language
        } label: {
            Text(flag)
                .font(.system(size: 22))
                .frame(width: 38, height: 34)
                .background(prefs.appLanguage == language ? Color.accentColor.opacity(0.16) : .clear,
                            in: RoundedRectangle(cornerRadius: 6, style: .continuous))
                .contentShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
        }
        .buttonStyle(.plain)
        .help(LocalizedStringKey(help))
        .accessibilityLabel(LocalizedStringKey(help))
    }

    private func sidebarGroup(_ title: String, sections: [SettingsSection]) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(LocalizedStringKey(title))
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
                .padding(.horizontal, 10)
                .padding(.bottom, 3)
            ForEach(sections) { section in
                Button {
                    selectedTab = section
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: section.symbol)
                            .frame(width: 18, height: 18)
                            .overlay(alignment: .topTrailing) {
                                if section == .permissions && hasPermissionIssues {
                                    Image(systemName: "exclamationmark")
                                        .font(.system(size: 7, weight: .black))
                                        .foregroundStyle(.white)
                                        .frame(width: 12, height: 12)
                                        .background(.red, in: Circle())
                                        .overlay(Circle().stroke(.background, lineWidth: 1.5))
                                        .offset(x: 5, y: -5)
                                        .allowsHitTesting(false)
                                        .accessibilityHidden(true)
                                }
                            }
                        Text(LocalizedStringKey(section.title))
                            .lineLimit(1)
                        Spacer(minLength: 0)
                    }
                    .font(.system(size: 13, weight: selectedTab == section ? .semibold : .regular))
                    .foregroundStyle(selectedTab == section ? Color.accentColor : Color.primary)
                    .padding(.horizontal, 10)
                    .frame(width: 210, height: 36, alignment: .leading)
                    .background {
                        if selectedTab == section {
                            RoundedRectangle(cornerRadius: 7, style: .continuous)
                                .fill(Color.accentColor.opacity(0.13))
                        }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(LocalizedStringKey(section == .permissions && hasPermissionIssues
                    ? "权限，存在未授权项目"
                    : section.title))
                .frame(width: 210, height: 36, alignment: .leading)
            }
        }
        .frame(width: 210, alignment: .leading)
    }

    @ViewBuilder
    private func page(for section: SettingsSection) -> some View {
        switch section {
        case .capture: CaptureSettingsView(prefs: prefs)
        case .shortcuts: ShortcutSettingsView(prefs: prefs)
        case .history: HistoryView()
        case .permissions: PermissionView()
        case .updates: UpdateView()
        case .donation: DonationView()
        case .about: AboutView(prefs: prefs)
        }
    }
}

private enum SettingsSection: String, Hashable, Identifiable {
    case capture, shortcuts, history, permissions, updates, donation, about

    var id: String { rawValue }
    var title: String {
        switch self {
        case .capture: "截图设置"
        case .shortcuts: "快捷键"
        case .history: "历史截图"
        case .permissions: "权限"
        case .updates: "检查更新"
        case .donation: "Donate"
        case .about: "关于 PrtSnap"
        }
    }
    var symbol: String {
        switch self {
        case .capture: "slider.horizontal.3"
        case .shortcuts: "command"
        case .history: "clock.arrow.circlepath"
        case .permissions: "lock.shield"
        case .updates: "arrow.down.circle"
        case .donation: "heart"
        case .about: "info.circle"
        }
    }
    var subtitle: String {
        switch self {
        case .capture: "输出格式、色彩与提示音"
        case .shortcuts: "全屏和窗口截图按键"
        case .history: "搜索与管理截图"
        case .permissions: "系统访问状态"
        case .updates: "导入 DMG 安装更新"
        case .donation: "支持 PrtSnap"
        case .about: "版本与更新记录"
        }
    }
}

private struct GlassIconBadge: View {
    let symbol: String

    var body: some View {
        if #available(macOS 26.0, *) {
            Image(systemName: symbol)
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(.tint)
                .frame(width: 42, height: 42)
                .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        } else {
            Image(systemName: symbol)
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(.tint)
                .frame(width: 42, height: 42)
                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
    }
}

private struct SettingsSectionBlock<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(LocalizedStringKey(title)).font(.headline)
            VStack(spacing: 0) { content }
        }
    }
}

private struct SettingsRow<Content: View>: View {
    let title: String
    let detail: String?
    @ViewBuilder let content: Content

    init(_ title: String, detail: String? = nil, @ViewBuilder content: () -> Content) {
        self.title = title
        self.detail = detail
        self.content = content()
    }

    var body: some View {
        HStack(spacing: 18) {
            VStack(alignment: .leading, spacing: 3) {
                Text(LocalizedStringKey(title))
                if let detail { Text(LocalizedStringKey(detail)).font(.caption).foregroundStyle(.secondary) }
            }
            Spacer(minLength: 16)
            content.layoutPriority(1)
        }
        .padding(.vertical, 9)
    }
}

struct CaptureSettingsView: View {
    @ObservedObject var prefs: Preferences

    private var outputColorSpace: OutputColorSpace {
        ImagePipeline.outputColorSpace(
            format: prefs.format,
            convertHDRToSDR: prefs.convertHDRToSDR,
            selected: OutputColorSpace(rawValue: prefs.colorSpace) ?? .sRGB
        )
    }

    private var canChooseOutputColorSpace: Bool {
        prefs.format != "PNG" || prefs.convertHDRToSDR
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                SettingsSectionBlock(title: "输出") {
                    SettingsRow("图像格式") {
                        Picker("图像格式", selection: $prefs.format) {
                            Text("PNG 无损").tag("PNG")
                            Text("JPEG").tag("JPEG")
                        }
                        .labelsHidden()
                        .frame(width: 190)
                    }
                    Divider()
                    SettingsRow("尺寸") {
                        Picker("尺寸", selection: $prefs.scale) {
                            Text("100% 原始大小").tag(1.0)
                            Text("75%").tag(0.75)
                            Text("50%").tag(0.5)
                            Text("25%").tag(0.25)
                        }
                        .labelsHidden()
                        .frame(width: 190)
                    }
                    Divider()
                    SettingsRow("质量", detail: prefs.format == "PNG" ? "PNG 始终无损；质量仅对 JPEG 生效。" : "JPEG 质量会影响文件大小和细节保留。") {
                        HStack(spacing: 12) {
                            Slider(value: $prefs.quality, in: 0.4...1.0, step: 0.05)
                                .frame(width: 210)
                            Text("\(Int(prefs.quality * 100))%")
                                .monospacedDigit().frame(width: 42, alignment: .trailing)
                        }
                    }
                }

                SettingsSectionBlock(title: "截图色彩映射") {
                    SettingsRow("检测到 HDR 时下变换为 SDR", detail: prefs.format == "PNG"
                        ? "开启后将 HDR 截图映射为所选 SDR 色彩空间；关闭时保留 HDR 色彩信息。"
                        : "JPEG 仅支持 SDR 输出，会自动下变换；此选项仅在 PNG 无损模式下生效。") {
                        Toggle("检测到 HDR 时下变换为 SDR", isOn: $prefs.convertHDRToSDR)
                            .labelsHidden()
                            .toggleStyle(.switch)
                            .disabled(prefs.format != "PNG")
                            .accessibilityLabel("检测到 HDR 时下变换为 SDR")
                    }
                    Divider()
                    SettingsRow("输出色彩空间", detail: canChooseOutputColorSpace
                        ? "SDR 图像映射到目标 profile；PNG HDR 保留时写入 16 位 PQ profile。"
                        : "PNG 未下变换时自动使用 Rec.2020；启用 SDR 下变换后可选择其他输出色彩空间。") {
                        Picker("输出色彩空间", selection: Binding(
                            get: { outputColorSpace.rawValue },
                            set: { prefs.colorSpace = $0 }
                        )) {
                            ForEach(OutputColorSpace.allCases) { space in Text(space.displayName).tag(space.rawValue) }
                        }
                        .labelsHidden()
                        .frame(width: 190)
                        .disabled(!canChooseOutputColorSpace)
                    }
                    Divider()
                    SettingsRow("超出目标色域处理", detail: "裁切会将超出目标色域的通道限制在边界；感知式压缩会保留更多色彩层次。") {
                        Picker("超出目标色域处理", selection: $prefs.gamutMappingMode) {
                            ForEach(GamutMappingMode.allCases) { mode in
                                Text(LocalizedStringKey(mode.displayName)).tag(mode.rawValue)
                            }
                        }
                        .labelsHidden()
                        .frame(width: 190)
                    }
                }

                CaptureSoundSettingsSection(prefs: prefs)
            }
            .frame(maxWidth: .infinity, alignment: .topLeading)
            .padding(.vertical, 8)
        }
        .scrollIndicators(.hidden)
    }
}

struct ShortcutSettingsView: View {
    @ObservedObject var prefs: Preferences
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("快捷键").font(.title3.bold())
                    Text("每个按键独立录入，可按需添加任意数量。全局触发需要输入监控和辅助功能权限。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                ShortcutRecorder(title: "截取屏幕", shortcut: $prefs.screenShortcut)
                ShortcutRecorder(title: "截取当前窗口", shortcut: $prefs.windowShortcut)
            }
            .padding(.vertical, 12)
        }
        .padding(.horizontal, 8)
    }
}

private struct HistoryCardFramesKey: PreferenceKey {
    static let defaultValue: [URL: CGRect] = [:]
    static func reduce(value: inout [URL: CGRect], nextValue: () -> [URL: CGRect]) {
        value.merge(nextValue(), uniquingKeysWith: { _, new in new })
    }
}

private struct HistoryModifierMonitor: NSViewRepresentable {
    var onMouseDown: (NSEvent.ModifierFlags) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(onMouseDown: onMouseDown) }

    func makeNSView(context: Context) -> ModifierMonitorView {
        let view = ModifierMonitorView()
        view.onMouseDown = { [weak coordinator = context.coordinator] flags in coordinator?.onMouseDown(flags) }
        return view
    }

    func updateNSView(_ view: ModifierMonitorView, context: Context) {
        context.coordinator.onMouseDown = onMouseDown
    }

    static func dismantleNSView(_ nsView: ModifierMonitorView, coordinator: Coordinator) {
        nsView.removeMonitor()
    }

    final class Coordinator {
        var onMouseDown: (NSEvent.ModifierFlags) -> Void
        init(onMouseDown: @escaping (NSEvent.ModifierFlags) -> Void) { self.onMouseDown = onMouseDown }
    }

    final class ModifierMonitorView: NSView {
        var onMouseDown: ((NSEvent.ModifierFlags) -> Void)?
        private var monitor: Any?

        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            guard window != nil, monitor == nil else { return }
            monitor = NSEvent.addLocalMonitorForEvents(matching: .leftMouseDown) { [weak self] event in
                self?.onMouseDown?(event.modifierFlags)
                return event
            }
        }

        override func hitTest(_ point: NSPoint) -> NSView? { nil }

        func removeMonitor() {
            if let monitor { NSEvent.removeMonitor(monitor) }
            monitor = nil
        }
    }
}

struct HistoryView: View {
    @ObservedObject private var history = HistoryManager.shared
    @ObservedObject private var prefs = Preferences.shared
    private let columns = [GridItem(.adaptive(minimum: 224, maximum: 360), spacing: 14)]
    @State private var previewURL: URL?
    @State private var selectionMode = false
    @State private var selectedIDs: Set<URL> = []
    @State private var rangeAnchor: URL?
    @State private var selectionModifiers: NSEvent.ModifierFlags = []
    @State private var cardFrames: [URL: CGRect] = [:]
    @State private var marqueeOrigin: CGPoint?
    @State private var marqueeRect: CGRect?
    @State private var marqueeModifiers: NSEvent.ModifierFlags = []
    @State private var confirmBulkDelete = false

    private var selectedItems: [HistoryItem] {
        history.items.filter { selectedIDs.contains($0.id) }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                Text("历史截图").font(.headline)
                Text("\(history.items.count)").font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                Spacer(minLength: 6)
            }

            SettingsRow("自动删除", detail: "更改仅影响之后保存的截图；每张图片按生成时的期限计时。") {
                Picker("自动删除", selection: $prefs.historyRetention) {
                    ForEach(HistoryRetention.allCases) { retention in Text(LocalizedStringKey(retention.rawValue)).tag(retention.rawValue) }
                }
                .labelsHidden()
                .frame(width: 190)
            }

            SettingsRow("保存位置", detail: "之后的截图保存到此处；已有文件留在原目录。") {
                HStack(spacing: 8) {
                    Text(history.directory.path.replacingOccurrences(of: NSHomeDirectory(), with: "~"))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                        .frame(maxWidth: 190, alignment: .trailing)
                        .help(history.directory.path)
                    Button("选择…", systemImage: "folder") { chooseHistoryDirectory() }
                    Button {
                        history.restoreDefaultDirectory()
                    } label: {
                        Image(systemName: "arrow.uturn.backward")
                            .frame(width: 28, height: 28)
                    }
                    .buttonStyle(.borderless)
                    .help("恢复默认目录")
                    .accessibilityLabel("恢复默认目录")
                    .disabled(history.isDefaultDirectory)
                }
            }

            HStack(spacing: 7) {
                if selectionMode {
                    iconButton("checkmark.square", help: "全选所有历史截图") {
                        selectedIDs = Set(history.items.map(\.id))
                        rangeAnchor = history.items.first?.id
                    }
                    .disabled(history.items.isEmpty)
                    if !selectedItems.isEmpty {
                        Text(prefs.appLanguage == AppLanguage.english.rawValue
                             ? "\(selectedItems.count) selected"
                             : "已选 \(selectedItems.count)")
                            .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                        iconButton("doc.on.doc", help: "复制所选截图") { history.copyToPasteboard(selectedItems) }
                        ShareLink(items: selectedItems.map(\.id)) {
                            Image(systemName: "square.and.arrow.up").frame(width: 30, height: 30)
                        }
                        .buttonStyle(.borderless).help("共享所选截图")
                        iconButton("trash", help: "删除所选截图", role: .destructive) { confirmBulkDelete = true }
                    }
                }
                Spacer(minLength: 4)
                iconButton(selectionMode ? "checkmark.circle.fill" : "checkmark.circle", help: selectionMode ? "退出多选" : "多选") {
                    selectionMode.toggle()
                    if !selectionMode { selectedIDs.removeAll(); rangeAnchor = nil }
                }
                iconButton("folder", help: "打开历史截图文件夹") { history.revealFolder() }
            }

            if history.items.isEmpty {
                ContentUnavailableView("暂无历史截图", systemImage: "photo.on.rectangle.angled", description: Text("截图会保存在 \(history.directory.path)。"))
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            } else {
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 12) {
                        ForEach(history.items) { item in
                            historyCard(item)
                                .background {
                                    GeometryReader { proxy in
                                        Color.clear.preference(key: HistoryCardFramesKey.self,
                                            value: [item.id: proxy.frame(in: .named("historyViewport"))])
                                    }
                                }
                        }
                    }
                    .padding(.vertical, 2)
                    .padding(.horizontal, 1)
                }
                .coordinateSpace(name: "historyViewport")
                .onPreferenceChange(HistoryCardFramesKey.self) { cardFrames = $0 }
                .simultaneousGesture(
                    DragGesture(minimumDistance: 6, coordinateSpace: .named("historyViewport"))
                        .onChanged { value in
                            guard selectionMode else { return }
                            if marqueeOrigin == nil {
                                marqueeOrigin = value.startLocation
                                marqueeModifiers = selectionModifiers
                            }
                            guard let start = marqueeOrigin else { return }
                            marqueeRect = CGRect(x: min(start.x, value.location.x), y: min(start.y, value.location.y),
                                                 width: abs(value.location.x - start.x), height: abs(value.location.y - start.y))
                        }
                        .onEnded { _ in
                            guard selectionMode, let rect = marqueeRect else { marqueeOrigin = nil; marqueeRect = nil; return }
                            if !marqueeModifiers.contains(.command) && !marqueeModifiers.contains(.shift) {
                                selectedIDs.removeAll()
                            }
                            for item in history.items where cardFrames[item.id]?.intersects(rect) == true {
                                selectedIDs.insert(item.id)
                            }
                            marqueeOrigin = nil
                            marqueeRect = nil
                        }
                )
                .overlay(alignment: .topLeading) {
                    if let rect = marqueeRect {
                        Rectangle().fill(Color.accentColor.opacity(0.12))
                            .overlay(Rectangle().stroke(Color.accentColor, lineWidth: 1))
                            .frame(width: rect.width, height: rect.height)
                            .offset(x: rect.minX, y: rect.minY)
                            .allowsHitTesting(false)
                    }
                }
            }
        }
        .background(HistoryModifierMonitor { selectionModifiers = $0 }.frame(width: 0, height: 0))
        .onAppear { history.refresh() }
        .quickLookPreview($previewURL)
        .confirmationDialog("删除所选历史截图？", isPresented: $confirmBulkDelete, titleVisibility: .visible) {
            Button("删除截图", role: .destructive) {
                history.delete(selectedItems)
                selectedIDs.removeAll()
                selectionMode = false
            }
            Button("取消", role: .cancel) {}
        } message: {
            Text("此操作会从 PrtSnap 历史记录中删除所选文件。")
        }
    }

    private func chooseHistoryDirectory() {
        let panel = NSOpenPanel()
        panel.title = AppLocalization.string("选择历史截图保存位置", language: prefs.appLanguage)
        panel.prompt = AppLocalization.string("选择", language: prefs.appLanguage)
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.canCreateDirectories = true
        panel.allowsMultipleSelection = false
        panel.directoryURL = history.directory
        panel.begin { response in
            guard response == .OK, let url = panel.url else { return }
            do {
                try history.setDirectory(url)
            } catch {
                prefs.status = "设置历史截图目录失败：\(error.localizedDescription)"
            }
        }
    }

    @ViewBuilder
    private func historyCard(_ item: HistoryItem) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack(alignment: .topTrailing) {
                Group {
                    if let image = item.image {
                        Image(nsImage: image).resizable().scaledToFit()
                    } else {
                        Image(systemName: "photo").foregroundStyle(.secondary)
                    }
                }
                .frame(maxWidth: .infinity).frame(height: 138)
                .background(.quaternary.opacity(0.65))
                .onTapGesture(count: 2) {
                    if !selectionMode { previewURL = item.id }
                }
                if selectionMode {
                    Image(systemName: selectedIDs.contains(item.id) ? "checkmark.circle.fill" : "circle")
                        .font(.title3).symbolRenderingMode(.palette)
                        .foregroundStyle(.white, selectedIDs.contains(item.id) ? Color.accentColor : Color.black.opacity(0.5))
                        .padding(7)
                }
            }
            Text(item.filename).font(.caption).lineLimit(1).truncationMode(.middle)
            if !selectionMode {
                HStack(spacing: 5) {
                    iconButton("doc.on.doc", help: "复制到剪贴板") { history.copyToPasteboard(item) }
                    ShareLink(item: item.id) {
                        Image(systemName: "square.and.arrow.up").frame(width: 30, height: 30)
                    }
                    .buttonStyle(.borderless).help("共享截图")
                    Spacer(minLength: 2)
                    iconButton("trash", help: "删除截图", role: .destructive) { history.delete(item) }
                }
            }
        }
        .padding(8)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(selectedIDs.contains(item.id) ? Color.accentColor.opacity(0.16) : Color.primary.opacity(0.035),
                    in: RoundedRectangle(cornerRadius: 8))
        .contentShape(RoundedRectangle(cornerRadius: 8))
        .onTapGesture {
            if selectionMode || selectionModifiers.contains(.command) || selectionModifiers.contains(.shift) {
                selectionMode = true
                select(item, modifiers: selectionModifiers)
            }
        }
        .onTapGesture(count: 2) {
            if !selectionMode { previewURL = item.id }
        }
        .contextMenu {
            Button { history.copyToPasteboard(item) } label: { Label("复制到剪贴板", systemImage: "doc.on.doc") }
            ShareLink(item: item.id) { Label("共享截图", systemImage: "square.and.arrow.up") }
            Divider()
            Button(role: .destructive) { history.delete(item) } label: { Label("删除", systemImage: "trash") }
        }
    }

    private func select(_ item: HistoryItem, modifiers: NSEvent.ModifierFlags) {
        let command = modifiers.contains(.command)
        let shift = modifiers.contains(.shift)
        if shift, let anchor = rangeAnchor,
           let start = history.items.firstIndex(where: { $0.id == anchor }),
           let end = history.items.firstIndex(where: { $0.id == item.id }) {
            if !command { selectedIDs.removeAll() }
            let lower = min(start, end), upper = max(start, end)
            for candidate in history.items[lower...upper] { selectedIDs.insert(candidate.id) }
        } else if command {
            if selectedIDs.contains(item.id) { selectedIDs.remove(item.id) }
            else { selectedIDs.insert(item.id) }
            rangeAnchor = item.id
        } else {
            selectedIDs = [item.id]
            rangeAnchor = item.id
        }
    }

    private func iconButton(_ symbol: String, help: String, role: ButtonRole? = nil, action: @escaping () -> Void) -> some View {
        Button(role: role, action: action) {
            Image(systemName: symbol).frame(width: 30, height: 30)
        }
        .buttonStyle(.borderless)
        .help(LocalizedStringKey(help))
        .accessibilityLabel(LocalizedStringKey(help))
    }
}

struct DonationView: View {
    private let methods: [(title: String, resource: String)] = [
        ("微信支付", "IMG_6133"),
        ("支付宝", "IMG_6134")
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                VStack(spacing: 5) {
                    Image(systemName: "heart.fill").font(.system(size: 26)).foregroundStyle(.pink)
                    Text("支持 PrtSnap").font(.title3.bold())
                    Text("感谢你支持这个小工具继续改进。")
                        .font(.callout).foregroundStyle(.secondary)
                }
                HStack(alignment: .top, spacing: 18) {
                    ForEach(methods, id: \.resource) { method in
                        VStack(spacing: 8) {
                            Text(LocalizedStringKey(method.title)).font(.headline)
                            if let url = Bundle.main.url(forResource: method.resource, withExtension: "JPG"),
                               let image = NSImage(contentsOf: url) {
                                Image(nsImage: image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(maxHeight: 390)
                                    .clipShape(RoundedRectangle(cornerRadius: 6))
                            } else {
                                ContentUnavailableView("收款图片未打包", systemImage: "qrcode")
                            }
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                .padding(.horizontal, 12)
            }
            .padding(.vertical, 20)
        }
    }
}

struct CaptureSoundSettingsSection: View {
    @ObservedObject var prefs: Preferences
    @State private var showSoundImporter = false
    @State private var importTarget: CaptureKind?

    var body: some View {
        SettingsSectionBlock(title: "截图提示音") {
            SettingsRow("全屏截图") {
                HStack(spacing: 4) {
                    Button("试听") { CaptureSoundPlayer.shared.play(prefs.screenSound) }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                        .fixedSize()
                        .help("试听全屏截图提示音")
                    importButton(for: .screen)
                    Picker("全屏截图", selection: $prefs.screenSound) {
                        ForEach(CaptureSoundPlayer.choices, id: \.self) { name in
                            Text(LocalizedStringKey(CaptureSoundPlayer.title(for: name))).tag(name)
                        }
                    }
                    .labelsHidden()
                    .frame(width: 190)
                }
                .fixedSize(horizontal: true, vertical: false)
            }
            Divider()
            SettingsRow("窗口截图") {
                HStack(spacing: 4) {
                    Button("试听") { CaptureSoundPlayer.shared.play(prefs.windowSound) }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                        .fixedSize()
                        .help("试听窗口截图提示音")
                    importButton(for: .window)
                    Picker("窗口截图", selection: $prefs.windowSound) {
                        ForEach(CaptureSoundPlayer.choices, id: \.self) { name in
                            Text(LocalizedStringKey(CaptureSoundPlayer.title(for: name))).tag(name)
                        }
                    }
                    .labelsHidden()
                    .frame(width: 190)
                }
                .fixedSize(horizontal: true, vertical: false)
            }
            HStack {
                Spacer()
                Button("恢复默认", systemImage: "arrow.uturn.backward") {
                    prefs.screenSound = CaptureSoundPlayer.defaultScreenSound
                    prefs.windowSound = CaptureSoundPlayer.defaultWindowSound
                }
            }
            .padding(.top, 5)
        }
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .fileImporter(isPresented: $showSoundImporter, allowedContentTypes: [.audio]) { result in
            guard let target = importTarget else { return }
            importTarget = nil
            do {
                let url = try result.get()
                let sound = try CaptureSoundPlayer.shared.importSound(from: url)
                if target == .screen { prefs.screenSound = sound }
                else { prefs.windowSound = sound }
                prefs.status = "已导入音效：\(CaptureSoundPlayer.title(for: sound))"
            } catch {
                if let cocoaError = error as? CocoaError, cocoaError.code == .userCancelled { return }
                prefs.status = "音效导入失败：\(error.localizedDescription)"
            }
        }
    }

    private func importButton(for target: CaptureKind) -> some View {
        Button {
            importTarget = target
            showSoundImporter = true
        } label: {
            Image(systemName: "folder.badge.plus").frame(width: 30, height: 30)
        }
        .buttonStyle(.borderless)
        .help(LocalizedStringKey(target == .screen ? "为全屏截图导入音效" : "为窗口截图导入音效"))
        .accessibilityLabel(LocalizedStringKey(target == .screen ? "为全屏截图导入音效" : "为窗口截图导入音效"))
    }
}

struct AboutView: View {
    @ObservedObject var prefs: Preferences
    @Environment(\.colorScheme) private var colorScheme

    private let releases: [(version: String, title: String, entries: [String])] = [
        ("1.1.4514", "PrtSnap 正式发布", [
            "正式发布 1.1.4514，整合 beta3 系列的色域处理选项、HDR 映射校正与界面布局优化。",
            "此版本优化系统的流畅度，提高系统的安全性和稳定性。"
        ]),
        ("1.1.4514beta3.2", "界面排版优化", [
            "关于页品牌标题旁新增 Developed by HFar · Powered by Codex 署名。",
            "精简权限、HDR 和自动删除说明，隐藏历史截图搜索框并移除刷新按钮。",
            "此版本优化系统的流畅度，提高系统的安全性和稳定性。"
        ]),
        ("1.1.4514beta3.1", "色域选项英文翻译", [
            "为超出目标色域处理标题、两种处理方式及说明补齐英文翻译。",
            "此版本优化系统的流畅度，提高系统的安全性和稳定性。"
        ]),
        ("1.1.4514beta3", "色域映射方式可选", [
            "新增超出目标色域处理选项，可选择感知式压缩或超出目标色域直接裁切。",
            "感知式压缩使用 ColorSync 扩展浮点转换并按目标色域的 Lab 色度压缩，避免直接裁切造成颜色溢出。",
            "此版本优化系统的流畅度，提高系统的安全性和稳定性。"
        ]),
        ("1.1.4514beta2.1", "更新日志规范", [
            "统一后续版本更新日志的结尾说明。",
            "此版本优化系统的流畅度，提高系统的安全性和稳定性。"
        ]),
        ("1.1.4514beta2", "HDR 色彩映射修复", [
            "使用 ScreenCaptureKit HDR 截图 preset，保留扩展线性像素与正确色彩空间。",
            "修复 P3、Rec.709、sRGB 和 Rec.2020 输出的实际像素映射与 ICC profile 写入。",
            "修复缺少 contentHeadroom 元数据时 HDR 到 SDR 下变换不生效的问题。"
        ]),
        ("1.1.4514beta", "快捷键与更新体验", [
            "新增检查更新页，可拖入 DMG 并校验固定签名身份后安装更新，保持 macOS 权限身份稳定。",
            "全局快捷键命中后拦截原始按键事件，避免系统提示音与截图成功提示音重叠。",
            "固定应用的代码签名身份；旧版权限按编译哈希识别，首次迁移如系统提示需重新授权一次，后续更新将保留授权。",
            "权限请求使用系统 API；从系统设置返回后延迟复查录屏、辅助功能和输入监控状态。"
        ]),
        ("1.1.4514alpha", "权限更新稳定性修复", [
            "固定应用的代码签名身份；旧版权限按编译哈希识别，首次迁移如系统提示需重新授权一次，后续更新将保留授权。",
            "权限请求使用系统 API；从系统设置返回后延迟复查录屏、辅助功能和输入监控状态。"
        ]),
        ("1.1.4514homo", "PrtSnap 正式发布", [
            "此版本优化系统的流畅度，提高系统的安全性和稳定性。"
        ]),
        ("1.1.4.4", "语言与 Dock 设置", [
            "关于页新增应用运行期间显示 Dock 图标的开关。",
            "设置窗口与状态栏菜单支持简体中文和英文，并可通过侧栏国旗即时切换。",
            "Dock 图标在启动时匹配系统外观，运行时切换图标保留圆角；放大语言切换按钮和彩蛋文字并改为上下两行。"
        ]),
        ("1.1.4.3", "图标与全屏布局优化", [
            "新增白天与黑夜两套应用图标，并随应用外观或系统外观切换。",
            "截图设置、权限和关于页面在全屏时扩展到可用宽度，并按快捷键和历史截图页面的方式顶部排布。"
        ]),
        ("1.1.4.2", "权限与设置布局调整", [
            "权限页改为无滚动的一屏布局，授权状态与系统设置操作横向排布并增加项目间距。",
            "历史截图页保留与其他选项卡一致的顶部间距，空状态提示在内容区居中显示。",
            "提示音行调整为试听、导入、下拉框顺序，操作控件紧邻下拉框并保持与输出设置对齐。",
            "提示音试听采用可见的系统按钮样式，避免控件尺寸导致按钮文字被裁切。",
            "移除页面顶部的全局状态胶囊；权限异常通过侧栏权限图标角标提示。"
        ]),
        ("1.1.4.1", "设置布局调整", [
            "HDR 下变换选项移入截图色彩映射区，并置于输出色彩空间之前。",
            "历史截图页移除顶部多余留白；权限页移至侧栏首位并放宽控件间距。",
            "截图提示音设置合并至截图设置页。"
        ]),
        ("1.1.4", "截图色彩、历史保存与提示音调整", [
            "HDR PNG 保留模式自动使用 Rec.2020；SDR 下变换模式仍可选择输出色彩空间。",
            "自动删除期限固定到每张截图生成时，调整选项不会追溯删除旧图片。",
            "历史截图可选择保存目录并恢复默认目录。",
            "提示音设置移除默认说明文字，并新增恢复 Frog 与 Submarine 的操作。"
        ]),
        ("1.1.3", "历史截图、外观与设置整理", [
            "快捷键录入支持直接按下 Command、Option、Shift 或 Control 单键。",
            "历史截图支持多选全选、双击预览与系统共享面板；隐藏图片编辑入口。",
            "外观、登录启动和菜单栏图标选项集中到关于页；设置行采用左右分栏布局。",
            "自动删除期限移至历史截图页并使用数字标注；兼容迁移旧版偏好。",
            "全屏与窗口提示音默认使用 Frog 和 Submarine，并支持导入自定义音频。",
            "HDR 截图可在 PNG 下变换为 SDR，或保留 HDR；JPEG 自动输出 SDR。",
            "色彩空间选项标注 sRGB Gamma 2.4 与 Rec.709 Gamma 2.2。"
        ]),
        ("1.1.2", "编辑器与交互修复", [
            "调整设置侧栏的按钮命中区域；隐藏菜单栏图标时不显示 Dock 图标，并可从应用图标重新打开窗口。",
            "屏幕录制权限使用 macOS 的实际授权预检；历史截图改用固定尺寸图标控件并支持框选、Command/Shift 多选。",
            "截图编辑新增画笔属性、涂抹马赛克、矩形/圆形/箭头、可搜索 Emoji 和图片/微信文件夹贴纸导入。",
            "文本框支持浮动排版工具、字体样式、颜色、字距/行距及对象移动、缩放、旋转；撤销/重做最多 100 步。",
            "参考 MIT 项目 MScreenshot 的标注对象设计，没有直接复制其应用代码。"
        ]),
        ("1.1.1", "稳定性与界面升级", [
            "状态栏菜单改用原生 AppKit 菜单，设置窗口改用标准 SwiftUI 窗口场景，修复启动和菜单交互卡顿。",
            "设置侧栏使用显式可交互按钮，并在 macOS 26+ 以 Liquid Glass 材质显示选中项。",
            "登录启动在后台串行同步并迁移到安装位置，避免启动阻塞、递归更新和临时路径自启动。",
            "DMG 使用独立临时暂存目录，独立 app 默认输出到 work 构建目录，降低 Launchpad 重复注册。"
        ]),
        ("1.1", "截图设置与历史管理", [
            "快捷键支持任意数量的独立按键输入框，显示实际键值，并可分别配置屏幕与窗口截图。",
            "可设置输出尺寸、JPEG 质量，以及正确映射到 sRGB、Rec.709、Display P3 或 Rec.2020。",
            "历史截图支持 OCR 文字与时间搜索、多选复制/共享/删除、右键复制及自动清理期限。",
            "截图编辑加入画笔、Emoji 贴纸、文字和可调强度的马赛克。",
            "增加全屏与窗口截图独立提示音、登录启动、隐藏菜单栏图标与权限状态设置。",
            "增加 Donate 捐赠页及本关于页面，集中记录版本更新内容。"
        ]),
        ("1.0", "PrtSnap 初始版本", [
            "提供全屏和当前窗口截图，并将图像写入剪贴板。",
            "建立原生 macOS 设置窗口、基础截图选项和历史截图保存。"
        ])
    ]

    private var currentVersion: String {
        Bundle.main.infoDictionary?["PrtSnapDisplayVersion"] as? String
            ?? Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String
            ?? "1.1.4514"
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                SettingsSectionBlock(title: "外观") {
                    SettingsRow("外观模式", detail: "选择浅色、深色，或跟随 macOS 外观设置。") {
                        Picker("外观模式", selection: $prefs.appearanceMode) {
                            ForEach(AppearanceMode.allCases) { mode in
                                Text(LocalizedStringKey(mode.title)).tag(mode.rawValue)
                            }
                        }
                        .labelsHidden()
                        .pickerStyle(.segmented)
                        .frame(width: 300)
                    }
                }
                SettingsSectionBlock(title: "启动与状态栏") {
                    SettingsRow("登录时自动启动 PrtSnap") {
                        Toggle("登录时自动启动 PrtSnap", isOn: $prefs.launchAtLogin)
                            .labelsHidden()
                            .toggleStyle(.switch)
                            .tint(.accentColor)
                    }
                    Divider()
                    SettingsRow("隐藏菜单栏图标", detail: prefs.hideStatusBarIcon
                        ? (prefs.showDockIcon
                            ? "关闭窗口不会退出应用；可从 Dock 中的 PrtSnap 图标重新打开设置。"
                            : "关闭窗口不会退出应用；可从 Launchpad 或 Finder 的 PrtSnap 应用图标重新打开设置。")
                        : "关闭窗口不会退出应用；可从菜单栏相机图标重新打开设置。") {
                        Toggle("隐藏菜单栏图标", isOn: $prefs.hideStatusBarIcon)
                            .labelsHidden()
                            .toggleStyle(.switch)
                            .tint(.accentColor)
                    }
                    Divider()
                    SettingsRow("运行时显示 Dock 图标", detail: "控制 PrtSnap 运行期间是否显示在 Dock 中。") {
                        Toggle("运行时显示 Dock 图标", isOn: $prefs.showDockIcon)
                            .labelsHidden()
                            .toggleStyle(.switch)
                            .tint(.accentColor)
                    }
                }
                HStack(spacing: 16) {
                    Group {
                        if let icon = AppIconProvider.image(mode: prefs.appearanceMode, colorScheme: colorScheme) {
                            Image(nsImage: icon).resizable().scaledToFit()
                        } else {
                            Image(systemName: "camera.viewfinder").resizable().scaledToFit()
                        }
                    }
                    .frame(width: 72, height: 72)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    VStack(alignment: .leading, spacing: 5) {
                        HStack(alignment: .firstTextBaseline, spacing: 8) {
                            Text("PrtSnap").font(.title2.bold())
                            Text("Developed by HFar · Powered by Codex")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                        Text("版本 \(currentVersion)").font(.callout).foregroundStyle(.secondary)
                    }
                }
                ForEach(Array(releases.enumerated()), id: \.offset) { _, release in
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(alignment: .firstTextBaseline) {
                            Text(release.version).font(.headline.monospacedDigit())
                            Text(LocalizedStringKey(release.title)).foregroundStyle(.secondary)
                        }
                        ForEach(release.entries, id: \.self) { entry in
                            HStack(alignment: .firstTextBaseline, spacing: 8) {
                                Circle().fill(.secondary).frame(width: 4, height: 4).padding(.bottom, 3)
                                Text(LocalizedStringKey(entry)).fixedSize(horizontal: false, vertical: true)
                            }
                            .font(.callout)
                        }
                    }
                    .padding(.vertical, 12)
                    if release.version != releases.last?.version { Divider() }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 18)
            .padding(.horizontal, 14)
        }
    }
}

struct UpdateView: View {
    @State private var isDropTargeted = false
    @State private var isWorking = false
    @State private var showFileImporter = false
    @State private var preparedUpdate: PreparedAppUpdate?
    @State private var statusMessage: String?
    @State private var errorMessage: String?

    private var currentVersion: String {
        Bundle.main.infoDictionary?["PrtSnapDisplayVersion"] as? String
            ?? Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String
            ?? ""
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                SettingsSectionBlock(title: "当前版本") {
                    SettingsRow("PrtSnap 版本") {
                        Text(currentVersion).font(.callout.monospacedDigit()).foregroundStyle(.secondary)
                    }
                }

                SettingsSectionBlock(title: "从 DMG 更新") {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("将 PrtSnap 更新 DMG 拖到下方区域。应用会检查 Bundle ID、签名身份和签名完整性，再提供安装选项。")
                            .font(.callout)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)

                        VStack(spacing: 10) {
                            Image(systemName: isDropTargeted ? "arrow.down.to.line.circle.fill" : "externaldrive.badge.plus")
                                .font(.system(size: 30, weight: .regular))
                                .foregroundStyle(isDropTargeted ? Color.accentColor : Color.secondary)
                            Text("拖拽 DMG 文件到这里")
                                .font(.headline)
                            Text("或选择一个 DMG 文件")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Button("选择 DMG…", systemImage: "folder") {
                                showFileImporter = true
                            }
                            .disabled(isWorking)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 176)
                        .background(isDropTargeted ? Color.accentColor.opacity(0.08) : Color.primary.opacity(0.025),
                                    in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                        .overlay {
                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .strokeBorder(isDropTargeted ? Color.accentColor : Color.primary.opacity(0.16),
                                              style: StrokeStyle(lineWidth: isDropTargeted ? 2 : 1, dash: [7, 5]))
                        }
                        .contentShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                        .onDrop(of: [UTType.fileURL], isTargeted: $isDropTargeted, perform: acceptDrop)

                        if isWorking {
                            HStack(spacing: 8) {
                                ProgressView().controlSize(.small)
                                Text("正在验证更新包…").font(.callout).foregroundStyle(.secondary)
                            }
                        }

                        if let update = preparedUpdate {
                            Divider()
                            HStack(spacing: 10) {
                                Image(systemName: "checkmark.seal.fill").foregroundStyle(.green)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text("已验证 PrtSnap 更新包").font(.callout.weight(.medium))
                                    Text("版本 \(update.displayVersion)").font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer(minLength: 10)
                                Button("取消") { discardPreparedUpdate() }
                                    .disabled(isWorking)
                                Button("安装并重新启动", systemImage: "arrow.clockwise") {
                                    install(update)
                                }
                                .buttonStyle(.borderedProminent)
                                .disabled(isWorking)
                            }
                        }

                        if let statusMessage {
                            Label(LocalizedStringKey(statusMessage), systemImage: "info.circle")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        if let errorMessage {
                            Label(errorMessage, systemImage: "exclamationmark.triangle.fill")
                                .font(.caption)
                                .foregroundStyle(.red)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    .padding(.vertical, 8)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 18)
            .padding(.horizontal, 14)
        }
        .fileImporter(isPresented: $showFileImporter,
                      allowedContentTypes: [UTType(filenameExtension: "dmg") ?? .data]) { result in
            switch result {
            case .success(let url): prepareUpdate(from: url)
            case .failure(let error): errorMessage = error.localizedDescription
            }
        }
    }

    private func acceptDrop(_ providers: [NSItemProvider]) -> Bool {
        guard let provider = providers.first else { return false }
        _ = provider.loadObject(ofClass: NSURL.self) { object, error in
            let url: URL?
            if let object = object as? URL { url = object }
            else if let object = object as? NSURL { url = object as URL }
            else { url = nil }
            let description = error?.localizedDescription ?? "无法读取拖入的文件。"
            DispatchQueue.main.async {
                if let url { prepareUpdate(from: url) }
                else { errorMessage = description }
            }
        }
        return true
    }

    private func prepareUpdate(from url: URL) {
        guard !isWorking else { return }
        discardPreparedUpdate()
        errorMessage = nil
        statusMessage = nil
        isWorking = true
        let hasSecurityScope = url.startAccessingSecurityScopedResource()
        Task {
            defer {
                if hasSecurityScope { url.stopAccessingSecurityScopedResource() }
                isWorking = false
            }
            do {
                let update = try await Task.detached(priority: .userInitiated) {
                    try AppUpdater.prepareUpdate(from: url)
                }.value
                preparedUpdate = update
                statusMessage = "更新包已校验，可以安装。"
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func install(_ update: PreparedAppUpdate) {
        guard !isWorking else { return }
        isWorking = true
        errorMessage = nil
        statusMessage = nil
        let currentAppURL = Bundle.main.bundleURL
        Task {
            defer { isWorking = false }
            do {
                try await Task.detached(priority: .userInitiated) {
                    try AppUpdater.scheduleInstall(update, replacing: currentAppURL)
                }.value
                statusMessage = "更新已准备好，PrtSnap 即将关闭并在安装后重新打开。"
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    NSApplication.shared.terminate(nil)
                }
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func discardPreparedUpdate() {
        if let preparedUpdate { AppUpdater.discard(preparedUpdate) }
        preparedUpdate = nil
        statusMessage = nil
    }
}

struct PermissionView: View {
    @ObservedObject private var permissions = PermissionCenter.shared

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .center, spacing: 18) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("权限状态").font(.headline)
                    Text("状态按 macOS 实际授权结果显示。可前往系统设置调整，返回 PrtSnap 后会自动刷新。")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 8)
                Button("刷新状态", systemImage: "arrow.clockwise") {
                    permissions.refreshAfterActivation()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
                        HotkeyCenter.shared.refresh()
                    }
                }
            }
            SettingsSectionBlock(title: "隐私权限") {
                PermissionRow(kind: .screenRecording, enabled: permissions.screenRecording) { permissions.request(.screenRecording) }
                Divider().padding(.leading, 58)
                PermissionRow(kind: .accessibility, enabled: permissions.accessibility) { permissions.request(.accessibility) }
                Divider().padding(.leading, 58)
                PermissionRow(kind: .inputMonitoring, enabled: permissions.inputMonitoring) { permissions.request(.inputMonitoring) }
                Divider().padding(.leading, 58)
                PermissionRow(kind: .notifications, enabled: permissions.notifications) { permissions.request(.notifications) }
            }
            Text("最近检查：\(permissions.lastUpdated.formatted(date: .omitted, time: .shortened))")
                .font(.caption)
                .foregroundStyle(.tertiary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .padding(.vertical, 8)
        .onAppear { permissions.refreshAfterActivation() }
    }
}

struct PermissionRow: View {
    let kind: PermissionKind
    let enabled: Bool
    let action: () -> Void

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: enabled ? "checkmark.shield.fill" : "exclamationmark.shield")
                .font(.system(size: 19, weight: .medium))
                .foregroundStyle(enabled ? .green : .orange)
                .frame(width: 42, height: 42)
                .background(.quaternary, in: Circle())
            VStack(alignment: .leading, spacing: 6) {
                Text(LocalizedStringKey(kind.title)).font(.body.weight(.medium))
                Text(LocalizedStringKey(kind.detail))
                    .font(.callout)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .layoutPriority(1)
            Spacer(minLength: 10)
            HStack(spacing: 12) {
                    Label(LocalizedStringKey(enabled ? "已授权" : "未授权"),
                          systemImage: enabled ? "checkmark.circle.fill" : "xmark.circle")
                    .font(.callout.weight(.medium))
                    .foregroundStyle(enabled ? .green : .secondary)
                    .fixedSize()
                Button("系统设置", systemImage: "gearshape", action: action)
                    .buttonStyle(.bordered)
                    .controlSize(.regular)
            }
            .fixedSize(horizontal: true, vertical: false)
            .layoutPriority(2)
        }
        .frame(minHeight: 72)
        .padding(.vertical, 8)
    }
}
