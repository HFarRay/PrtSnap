#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
source "$ROOT/toolchain-env.sh"
SDK="$MACOS_SDKROOT"
WORK="$(cd "$ROOT/../../work" && pwd)"
DMG="${1:?Pass a PrtSnap DMG path}"
mkdir -p "$WORK/PrtSnap-build"
"$SWIFTC" -parse-as-library -swift-version 6 -O -sdk "$SDK" \
  -target arm64-apple-macosx14.0 -module-cache-path "$WORK/PrtSnap-build/module-cache-v2" \
  "$ROOT/Sources/PrtSnap/AppUpdater.swift" "$ROOT/Tests/AppUpdaterProbe.swift" \
  -o "$WORK/PrtSnap-build/AppUpdaterProbe"
"$WORK/PrtSnap-build/AppUpdaterProbe" "$DMG"
